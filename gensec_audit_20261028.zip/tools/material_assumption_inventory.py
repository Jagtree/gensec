# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
# This file is part of GenSec.  AGPL-3.0-or-later.
# ---------------------------------------------------------------------------
r"""
Material-assumption inventory — where the engine assumes "concrete".

Why this exists
---------------
GenSec's fibre kernel is indifferent to the material *in principle*: it
integrates a stress law over an area and never asks what the law
describes.  In practice that indifference has never been measured, and
an unmeasured property is a belief.  The day timber or steel enters,
every point where the engine assumes a bulk zone is concrete — an
:math:`f_{ck}`, a cracking branch, a casting datum, a creep coefficient
— is a point that has to be paid for.

This phase does not redesign anything.  It **measures** where the
assumption lives, so that the number becomes a debt with a size instead
of a worry with a name, and so that it cannot grow in silence.

The measurement is deliberately crude in one respect and exact in
another.  It is crude about *intent*: it cannot tell a normative symbol
used as a variable from one named in prose.  It is exact about
*location*: an AST walk, not a regular expression over lines, so a name
inside a string or a comment is never counted as code.  The two are
separated in the output, because "``sls.py`` names EN 1992-1-1 in a
docstring" and "``sls.py`` branches on ``f_ctm``" are different facts
with different remedies.

What is counted
---------------
Four categories, each measured rather than listed from memory:

``symbol``
    A normative symbol — ``fck``, ``fcm``, ``fctm``, ``alpha_cc``,
    ``phi``, and the rest of the vocabulary below — appearing **as an
    identifier or attribute** in a module that does not own the document
    it belongs to.  Concrete's :math:`f_{ck}` in a neutral module is a
    material assumption wearing a normative name.

``clause``
    A normative document named in a module that is not that document's
    module.  Counted separately for code (a string literal compared, a
    key looked up) and for prose (a docstring or comment), because only
    the first is behaviour.

``concrete_type``
    A site that annotates, isinstance-checks or constructs
    :class:`~gensec.materials.concrete.Concrete` or
    :class:`~gensec.materials.service_concrete.ServiceConcrete` where
    :class:`~gensec.materials.base.Material` would carry the same
    weight.  These are the sites that will reject a timber zone by type
    rather than by capability.

``branch``
    A conditional whose test mentions cracking, a tensile-failure
    branch, or a casting datum: behaviour that presupposes a material
    which cracks and which is placed wet.  Timber and steel have
    neither.

Which modules own which document
--------------------------------
A module owns a normative document if its name declares it.  Everything
else is **neutral**, and a normative symbol in a neutral module is a
site on the register.  This is the "each normative document is
watertight" rule made countable: ``Concrete`` is an aggregator, not a
deriver, and normative parameters enter GenSec only through the module
of the document that owns them.

What a number here means
------------------------
Nothing on this register is a defect.  A site is a place where the
engine would have to be told something new before a material without a
cracking branch and without a casting datum could pass through it.  The
tool's job is to hand the list to a human with a count attached, exactly
as ``getattr_inventory`` and ``element_class_inventory`` do, and to
refuse a **new** site that arrives without a written reason.

Usage
-----
::

    python tools/material_assumption_inventory.py            # report
    python tools/material_assumption_inventory.py --gate     # exit 1
    python tools/material_assumption_inventory.py --baseline # rewrite

The gate compares against ``tools/material_assumption_baseline.txt`` and
fails on any site absent from it, and on any reason in
``material_assumption_reasons.REASONS`` that names a site which no longer
exists — a stale reason is a claim about code that is not there.

Why the baseline is not keyed by line number
--------------------------------------------
The first draft of this tool keyed each site by ``path:line``, which is
how ``element_class_inventory`` reports.  Its null control caught the
consequence immediately: adding a **comment** to ``sls.py`` shifted every
line below it, so the gate reported dozens of new sites and exited 1 on
a tree in which nothing had changed.  A gate that fires on a comment is
noise, and a noisy gate is switched off.

The register is therefore keyed by ``(category, module, name)`` with a
**count**.  That is stable under any edit that does not change what the
module assumes, and it still catches the thing the gate exists for: one
more ``fck`` in a neutral module raises a count, and a first ``fck``
adds a key.  Line numbers are still printed in the report, where they
help a human, and are absent from the baseline, where they only move.
"""
import argparse
import ast
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src", "gensec")
BASELINE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "material_assumption_baseline.txt")

_HEADER = (
    "# Material-assumption baseline.  Regenerated with --baseline when\n"
    "# sites are added or removed deliberately.  Do not hand-edit: the\n"
    "# gate refuses a line it did not produce.\n"
    "# Each line: <category>  <module>  <name>  <count>\n"
    "# Line numbers are deliberately absent: they move when a comment\n"
    "# is added, and a gate that fires on a comment is switched off.\n"
)

#: Normative symbols.  Each belongs to a document; naming it outside
#: that document's module is the thing being counted.
SYMBOLS = frozenset({
    "fck", "f_ck", "fcm", "f_cm", "fctm", "f_ctm", "fctk", "f_ctk",
    "fcd", "fctd", "alpha_cc", "alpha_ct", "gamma_c",
    "eps_c1", "eps_cu1", "eps_c2", "eps_cu2", "eps_c3", "eps_cu3",
    "epsilon_c1", "epsilon_cu1",
    "phi", "phi_inf", "eps_cs", "eps_ca", "eps_cd",
    "fyk", "fyd", "fpk", "f_p01d",
})

#: Documents.  A module owns one if its filename declares it.
DOCUMENTS = {
    "EN 1992": "ec2", "EN1992": "ec2", "Eurocode 2": "ec2", "EC2": "ec2",
    "EN 10025": "en10025",
    "NTC 18": "ntc", "NTC18": "ntc", "NTC 2018": "ntc",
    "ACI 318": "aci", "ACI318": "aci", "ACI 209": "aci",
}

#: Filename fragments that declare ownership of a document.
OWNERSHIP = {
    "ec2": ("ec2_",), "ntc": ("ntc",), "aci": ("aci",),
    "en10025": ("en10025",),
}

#: Concrete-specific classes.  A site naming one of these is a site that
#: rejects a non-concrete zone by type rather than by capability.
CONCRETE_TYPES = frozenset({"Concrete", "ServiceConcrete"})

#: Vocabulary that presupposes a material which cracks, or one that is
#: placed wet and therefore has an age and a casting datum.
BRANCH_WORDS = frozenset({
    "cracked", "uncracked", "cracking", "crack", "fct_eff",
    "cast", "casting", "pour", "poured", "wet", "curing",
})


def _owns(path, doc):
    """Whether the module at *path* owns document *doc*."""
    base = os.path.basename(path).lower()
    return any(frag in base for frag in OWNERSHIP.get(doc, ()))


def _rel(path):
    """Path relative to the repository root, with forward slashes."""
    return os.path.relpath(path, ROOT).replace(os.sep, "/")


class _Walker(ast.NodeVisitor):
    r"""
    Collect the four categories from one module's AST.

    Only *code* nodes are visited, so a name that appears solely inside
    a docstring or a comment is never counted here.  Prose is counted
    separately, by the caller, and reported apart.

    Parameters
    ----------
    path : str
        Absolute path of the module, used for ownership and reporting.
    """

    def __init__(self, path):
        self.path = path
        self.rel = _rel(path)
        self.sites = []

    def _add(self, category, node, name):
        self.sites.append((category, self.rel, name, node.lineno))

    # -- symbols ------------------------------------------------------
    def visit_Name(self, node):
        if node.id in SYMBOLS:
            self._add("symbol", node, node.id)
        elif node.id in CONCRETE_TYPES:
            self._add("concrete_type", node, node.id)
        elif node.id.lower() in BRANCH_WORDS:
            self._add("branch", node, node.id)
        self.generic_visit(node)

    def visit_Attribute(self, node):
        if node.attr in SYMBOLS:
            self._add("symbol", node, node.attr)
        elif node.attr in CONCRETE_TYPES:
            self._add("concrete_type", node, node.attr)
        elif node.attr.lower() in BRANCH_WORDS:
            self._add("branch", node, node.attr)
        self.generic_visit(node)

    def visit_arg(self, node):
        if node.arg in SYMBOLS:
            self._add("symbol", node, node.arg)
        elif node.arg.lower() in BRANCH_WORDS:
            self._add("branch", node, node.arg)
        self.generic_visit(node)

    # -- clauses named in code, not in prose --------------------------
    def visit_Constant(self, node):
        if not isinstance(node.value, str):
            return
        for text, doc in DOCUMENTS.items():
            if text in node.value and not _owns(self.path, doc):
                self._add("clause", node, doc)
                break


def _prose_hits(path, text):
    """Count normative documents named in comments and docstrings."""
    n = 0
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("#"):
            continue
        for name, doc in DOCUMENTS.items():
            if name in stripped and not _owns(path, doc):
                n += 1
                break
    return n


def collect():
    r"""
    Walk ``src/gensec`` and return every site on the register.

    Returns
    -------
    tuple
        ``(sites, prose)`` where *sites* is a sorted list of
        ``(category, module, name, line)`` tuples -- the line is for the
        report only and never reaches the baseline -- and *prose* maps a
        module path to the number of normative documents it names in
        comments only.
    """
    sites, prose = [], {}
    for root, _dirs, files in os.walk(SRC):
        if "__pycache__" in root:
            continue
        for fn in sorted(files):
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            with open(path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
            try:
                tree = ast.parse(text)
            except SyntaxError:                 # pragma: no cover
                continue
            w = _Walker(path)
            w.visit(tree)
            sites.extend(w.sites)
            n = _prose_hits(path, text)
            if n:
                prose[_rel(path)] = n
    return sorted(set(sites)), prose


def _counts(sites):
    r"""
    Collapse sites to ``{(category, module, name): count}``.

    The line number is dropped here and nowhere else: it is what makes
    a register move when a comment is added.

    Parameters
    ----------
    sites : list of tuple

    Returns
    -------
    dict
    """
    out = {}
    for cat, mod, name, _line in sites:
        key = (cat, mod, name)
        out[key] = out.get(key, 0) + 1
    return out


def _load_baseline():
    """Read the baseline, or ``None`` if there is none."""
    if not os.path.exists(BASELINE):
        return None
    out = {}
    with open(BASELINE, encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            parts = [p for p in line.rstrip("\n").split("  ") if p]
            if len(parts) >= 4:
                out[(parts[0].strip(), parts[1].strip(),
                     parts[2].strip())] = int(parts[3])
    return out


def _write_baseline(sites):
    """Write the baseline file from *sites*."""
    with open(BASELINE, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(_HEADER)
        for (cat, mod, name), n in sorted(_counts(sites).items()):
            fh.write(f"{cat}  {mod}  {name}  {n}\n")


def _report(sites, prose):
    """Print the register, grouped by category and by module."""
    by_cat = {}
    for cat, mod, name, line in sites:
        by_cat.setdefault(cat, []).append((f"{mod}:{line}", name))
    print("=" * 70)
    print("MATERIAL-ASSUMPTION INVENTORY")
    print("=" * 70)
    for cat in ("symbol", "clause", "concrete_type", "branch"):
        rows = by_cat.get(cat, [])
        print(f"\n{cat}: {len(rows)} site(s)")
        per_mod = {}
        for loc, name in rows:
            per_mod.setdefault(loc.split(":")[0], []).append(name)
        for mod, names in sorted(per_mod.items(),
                                 key=lambda t: -len(t[1])):
            uniq = ", ".join(sorted(set(names))[:6])
            print(f"  {len(names):>4}  {mod}")
            print(f"        {uniq}")
    engine = [s for s in sites
              if not s[1].startswith("src/gensec/materials/")]
    print("\n" + "-" * 70)
    print(f"total sites            : {len(sites)}")
    print(f"  in materials/        : {len(sites) - len(engine)}")
    print(f"  in the engine        : {len(engine)}")
    print(f"modules naming a document in prose only: {len(prose)}")
    return engine


def main(argv=None):
    """Entry point."""
    ap = argparse.ArgumentParser(
        description="Where the engine assumes a bulk zone is concrete.")
    ap.add_argument("--gate", action="store_true",
                    help="exit 1 on a site absent from the baseline")
    ap.add_argument("--baseline", action="store_true",
                    help="rewrite the baseline from the current tree")
    args = ap.parse_args(argv)

    sites, prose = collect()

    if args.baseline:
        if args.gate:
            print("--baseline and --gate are mutually exclusive.")
            return 2
        _write_baseline(sites)
        print(f"baseline written: {len(sites)} site(s) -> "
              f"{_rel(BASELINE)}")
        return 0

    engine = _report(sites, prose)

    if not args.gate:
        return 0

    base = _load_baseline()
    if base is None:
        print("\ngate: no baseline.  Run --baseline once, deliberately.")
        return 1
    now = _counts(sites)
    new = sorted(k for k in now
                 if now[k] > base.get(k, 0))
    gone = sorted(k for k in base if now.get(k, 0) < base[k])
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import material_assumption_reasons as R
    except ImportError:                         # pragma: no cover
        print("\ngate: material_assumption_reasons.py is missing.")
        return 1
    unexplained = [k for k in new if "|".join(k) not in R.REASONS]
    stale = sorted(k for k in R.REASONS
                   if tuple(k.split("|")) not in now)
    if unexplained:
        print(f"\ngate: {len(unexplained)} site(s) beyond the baseline "
              f"with no written reason.  Add one, keyed "
              f"'category|module|name', to "
              f"material_assumption_reasons.REASONS:")
        for cat, mod, name in unexplained:
            print(f"  {cat:<14} {mod}  {name}  "
                  f"{base.get((cat, mod, name), 0)} -> "
                  f"{now[(cat, mod, name)]}")
        return 1
    if stale:
        print(f"\ngate: {len(stale)} reason(s) name a site that no "
              f"longer exists.  A stale reason is a claim about code "
              f"that is not there:")
        for k in stale:
            print(f"  {k}")
        return 1
    print(f"\ngate: no unexplained drift.  {len(sites)} site(s) over "
          f"{len(now)} keys, {len(engine)} of them outside materials/, "
          f"{len(new)} beyond baseline (all with a written reason), "
          f"{len(gone)} below it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
