r"""
The reasons behind ``element_class_baseline.txt`` — N-9, closed.

Why this file exists
--------------------
``element_class_inventory.py`` *measures* which functions name one or two
of the three element classes and never the third.  It cannot judge them:
a partial signature is a site that owes an explanation, and an
explanation is a human act.  Phase 17 wrote those explanations into a
prose handoff (``17_2``) where they could not be checked, and absolved 77
sites *by category* while leaving 114 unread.

The prose form has two failure modes this file removes.  A reason written
in a document drifts away from the code silently; and a category
absolution — "every renderer is partial" — says something true about a
family without saying anything about a member of it, which is exactly the
mistake ``17_0 §7`` was written to forbid ("a conclusion that generalises
from a case to a class must be measured on the class").  Here every
signature carries its own reason, the gate refuses a signature without
one, and the two live in the same tree as the code they describe.

The taxonomy of reasons
-----------------------
Each reason opens with a tag naming *what kind of thing* absolves the
site.  The tags are not decoration: they are the claim being made, and a
site whose tag does not fit is a site that has not been read.

===============  =====================================================
tag              the claim
===============  =====================================================
``SUBJECT``      the element class **is** the subject of the function;
                 the other classes are not omitted, they are off-topic
``UNION``        the function walks the *union* element index
                 (``rebar`` then ``tendon``, one array), so it covers
                 both classes without naming either — the lexical scan
                 reads the word, the code reads the index
``SLOT``         same, for the ``MaterialMap`` slot vocabulary, where
                 ``elem`` deliberately spans rebar and tendon
                 (``_slot_inventory`` builds it from ``rebars +
                 tendons``)
``GEOMETRY``     builds or queries one element family's geometry
``MATERIAL``     a constitutive or normative rule owned by one material
                 class
``PARSER``       parses the declared block of one element kind
``RENDER``       one artist per element family; the join is the figure
``REPORT``       serialises one section of a report; the join is the
                 caller
``CONFIG``       a configuration or tolerance name, not a consumer
``ENTRY``        entry point forwarding to the solver
``DELEGATE``     forwards the element walk to something that does
                 enumerate all three
``INERT``        the omission cannot change the result, and the reason
                 why is stated
``DEFECT``       **not absolved** — a real blindness, with its ledger id
===============  =====================================================

Usage
-----
This module is data plus one function.  ``element_class_inventory.py``
imports :func:`reason_for` to write and to check the baseline.

Notes
-----
A reason is prose, but it is prose under a gate: if the inventory grows a
partial site with no entry here, ``--baseline`` refuses to write it and
``--gate`` refuses to pass.  That is the whole mechanism — an unexplained
partial site cannot reach a green tree.
"""

from __future__ import annotations

from typing import Dict, Optional

#: Reason per site, keyed by ``"<relpath>:<qualname>"``.  The signature is
#: deliberately **not** part of the key: a site whose signature changes
#: has changed what it enumerates, and its reason must be re-read, which
#: is what the gate's drift report forces.
REASONS: Dict[str, str] = {}


def _add(entries: Dict[str, str]) -> None:
    for k, v in entries.items():
        if k in REASONS:
            raise KeyError(f"duplicate reason for {k!r}")
        REASONS[k] = v


# ======================================================================
#  SOLVER — read line by line in Phase 18.  This is the family in which
#  Phase 16 found N-1 and N-2 and Phase 18 found N-13, N-14, N-15, N-16,
#  so nothing here is absolved by category.
# ======================================================================

_add({
 "solver/analysis.py:AnalysisEngine._analyze_staged":
   "DELEGATE: enumerates stages and demands, not elements.  The element "
   "walk is inside StagedDomainManager.resolve_stages and the solver's "
   "integrate/limit machinery; 'tendon' appears only because the "
   "deactivation actions are prestress actions.",

 "solver/capacity.py:NMDiagram._mega_batch_integrate":
   "DELEGATE: reshapes strain-plane templates and calls "
   "FiberSolver.integrate_batch.  It never touches an element; the "
   "element walk is one level down, and that walk enumerates all three.",
 "solver/capacity.py:NMDiagram.generate_mx_my":
   "DELEGATE: builds a curvature fan and hands it to the solver.  Its "
   "only geometric input is _all_lx/_all_ly, cached in __init__ — which "
   "is where the tendon lever arms are missing (N-16), not here.",
 "solver/capacity.py:NMDiagram._ductility_at_direction":
   "DELEGATE: reads eps from strain_field and tests it against "
   "_eps_yd_min.  Yield is a REBAR concept by construction (a strand "
   "has no yield plateau in the EC2 inclined diagram), so the ductility "
   "ratio is defined on rebar; the ultimate end is the solver's "
   "element_limit_groups, which does enumerate all three.",
 "solver/capacity.py:NMDiagram._cracking_strain_field":
   "SUBJECT: first cracking is a property of the CONCRETE zone map.  "
   "Steel does not crack; a tendon's contribution to cracking is "
   "through the plane, already resolved before this is called.",
 "solver/capacity.py:NMDiagram._scan_chi":
   "DELEGATE: the ultimate/yield event detection was given one home in "
   "Phase 16 (FiberSolver.element_limit_groups), which this calls.  The "
   "scan's own vocabulary is bulk (crush pivot) and tendon (the "
   "envelope); rebar is absent from the text, present through the "
   "delegate.",
 "solver/capacity.py:NMDiagram.generate_polar_curvature":
   "DELEGATE: same shape as generate_mx_my.  Geometric extent comes "
   "from _all_lx/_all_ly (N-16); the limit test comes from the solver.",
 "solver/capacity.py:max_configs_for":
   "CONFIG: a memory budget expressed in (configuration x fibre) "
   "elements.  'Fibre' is the unit of the arithmetic, not an element "
   "class the function reads: it counts them and never asks what any "
   "of them is made of, so rebar and tendon are not omitted but "
   "off-topic.  A section's fibre count already spans all three.",
 "solver/capacity.py:_integrate_chunked":
   "DELEGATE: slices a batch and calls FiberSolver.integrate_batch "
   "once per slice.  It never touches an element; the element walk is "
   "one level down, and that walk enumerates all three.  The word "
   "'fibre' appears only in the size arithmetic that fixes the slice.",

 "solver/integrator.py:FiberSolver._build_rebar_groups":
   "SUBJECT: builds the rebar groups.  _build_bulk_groups and "
   "_build_tendon_groups are its two siblings; one function per class "
   "is the design, and a single function naming all three would be "
   "three functions in a trench coat.",
 "solver/integrator.py:FiberSolver._build_bulk_groups":
   "SUBJECT: the bulk sibling of _build_rebar_groups.",
 "solver/integrator.py:FiberSolver._bulk_offset":
   "SUBJECT: the bulk member of the three-way offset family "
   "(_bulk_offset / _rebar_offset / _tendon_offset), all three of which "
   "exist and are called from the integrator's three force branches.",
 "solver/integrator.py:FiberSolver.bulk_strain_offset":
   "SUBJECT: the public face of _bulk_offset.  Phase 15's F-M3 made "
   "this the single accessor the ULTIMATE CRITERIA read for bulk; the "
   "rebar and tendon criteria read their own.",
 "solver/integrator.py:FiberSolver._rebar_offset":
   "SUBJECT: the rebar member of the same three-way family.",
 "solver/integrator.py:FiberSolver._tendon_offset":
   "SUBJECT: the tendon member of the same three-way family.",
 "solver/integrator.py:FiberSolver.strain_field":
   "SUBJECT: returns the (bulk, rebar) pair, which is what every caller "
   "of it wants; the tendon strain is _tendon_section_strain, separate "
   "because a tendon's law is evaluated on eps_sec + eps_init and the "
   "two must not be conflated.  The split is the N-1 lesson applied, "
   "not the N-1 defect repeated.",
 "solver/integrator.py:FiberSolver._tendon_section_strain":
   "SUBJECT: the tendon counterpart of strain_field, deliberately "
   "separate for the reason stated there.",
 "solver/integrator.py:FiberSolver._yield_strain_of_rebar":
   "SUBJECT (REBAR): resolves the yield strain of one rebar by "
   "finding the group that owns its index. Partial by construction "
   "and correctly so -- it answers about a single named element, not "
   "about the section. Its tendon twin is the next entry, and the two "
   "are kept apart rather than merged because a tendon's yield strain "
   "comes off f_p01d/Ep while a rebar's comes off fyd/Es, and one "
   "function reading both would be one home for two facts.",
 "solver/integrator.py:FiberSolver._yield_strain_of_tendon":
   "SUBJECT (TENDON): the tendon twin of the entry above, same "
   "standing and same reason for staying separate.",
 "solver/integrator.py:FiberSolver._tendon_forces":
   "SUBJECT: the tendon force branch.  It names bulk because an "
   "EMBEDDED tendon's net force subtracts the displaced bulk stress "
   "(the sign convention of 13_0); rebar is off-topic here.",
 "solver/integrator.py:FiberSolver._is_uniaxial":
   "INERT: the test is whether the lever-arm extent is DEGENERATE "
   "(range < 1e-6, i.e. the section is a line).  Adding elements can "
   "only increase an extent, never collapse one, and the bulk mesh of "
   "any 2-D section already has non-zero extent in both directions.  "
   "No tendon can change the verdict, in either direction.",
 "solver/integrator.py:FiberSolver._solve_uniaxial":
   "DELEGATE: a Newton/fallback ladder over (eps0, chi_x).  Every "
   "element walk is inside integrate/_nr_uniaxial.  It names bulk only "
   "for the crush clip on the eps0 guess.",
 "solver/integrator.py:FiberSolver._solve_uniaxial_y":
   "DELEGATE: the My twin of _solve_uniaxial, same reason.",
})

# ======================================================================
#  STAGED — losses, posttension, sls, timeline, timeline_run
# ======================================================================

_add({
 "solver/losses.py:_check_linearity":
   "SUBJECT: EN 1992-1-1 §3.1.4 linearity of CREEP is a concrete "
   "property, tested on the concrete stress of one zone.  Steel has no "
   "creep-linearity limit in EC2.",
 "solver/losses.py:_zone_material":
   "SUBJECT: returns the bulk material of a zone index.  A two-line "
   "accessor over the zone material list.",
 "solver/losses.py:_tendon_steel":
   "SUBJECT: extracts the relaxation parameters (f_pk, class, rho_1000) "
   "that only a prestressing steel has.",
 "solver/losses.py:_fpk_by_name":
   "SUBJECT: resolves f_pk by tendon name; f_pk is a prestressing-steel "
   "quantity.",
 "solver/losses.py:expand_losses":
   "DELEGATE: the time walk.  It enumerates zones (creep/shrinkage) and "
   "tendons (relaxation) because those are the two carriers of "
   "time-dependent loss; ordinary rebar has none in EC2, which is a "
   "normative fact and not an omission.",
 "solver/losses.py:_apply_bulk_delta":
   "SUBJECT: applies a per-zone plane delta to the state.  Element "
   "eps_init is moved by the caller, through the union index.",

 "solver/posttension.py:PosttensionSequenceResult.effective_actions":
   "SUBJECT: converts each tendon's effective stress into a "
   "PrestressAction.  Bulk and rebar have no jacking force.",
 "solver/posttension.py:PosttensionSequenceResult.total_effective_action":
   "SUBJECT: sums the above.",
 "solver/posttension.py:_resolve_Ep":
   "SUBJECT: resolves the tendon modulus.  Ep is a tendon property.",
 "solver/posttension.py:_bonded_state":
   "UNION: builds the grouted state.  It names rebar only to compute "
   "the union offset (n_rebars + j) that ADDRESSES the tendons; the "
   "word 'rebar' here is the index arithmetic that reaches the tendon, "
   "which is the opposite of blindness to it.",
 "solver/posttension.py:grout_selfconsistent":
   "UNION: the fixed-point wrapper around grout().  Same union-offset "
   "arithmetic; bulk enters only as the resisting view.",
 "solver/posttension.py:solve_posttension_sequence":
   "SUBJECT: the sequential jacking driver.  Its subject is the tendon "
   "set; bulk and rebar enter through the section it solves, not "
   "through an enumeration it owns.  Carries the ratified scope "
   "boundary of Phase 18 in its Notes.  Reads B-T from Phase 25 and "
   "not --T: the declared plane of an existing member is an imposed "
   "strain on the BULK, so the driver names bulk_plane and the scanner "
   "sees the word.  The subject did not move -- it is still the tendon "
   "set -- and rebar is still absent, which is the honest reading.",
 "solver/posttension.py:solve_posttension_sequence._plane_at_tendons":
   "SUBJECT: evaluates the solved plane at the tendon coordinates.",
 "solver/posttension.py:solve_posttension_sequence._build_view":
   "DELEGATE: hands the bonded set, the per-tendon eps_init and the "
   "declared bulk plane to _stressing_view and, when a modmap is "
   "given, to sls_view.  It enumerates nothing itself; it names bulk "
   "because the declared plane is a bulk quantity, and tendons only "
   "as indices it forwards.  One construction point for the view, so "
   "no step can build a different one.",
 "solver/posttension.py:solve_posttension_sequence._run_sequence":
   "SUBJECT: walks the stressing order, which is an order over "
   "tendons.  B-T from Phase 25 for the same reason as its parent: "
   "the sweep carries the declared bulk plane into every view it "
   "builds.  Rebar enters through the section, never through an "
   "enumeration here.",
 "solver/posttension.py:solve_posttension_sequence._run_sequence._solver_for":
   "DELEGATE: one FiberSolver per distinct bonded set, cached inside "
   "the sweep.  Inside and not outside it, from Phase 25: a view now "
   "carries the eps_init of the tendons bonded at that step, and for "
   "a tendon injected mid-sequence that value changes between the "
   "sweeps of scheme='coupled'.  Names bulk only as the plane it "
   "forwards.",
 "solver/posttension.py:grout":
   "UNION: reconciles eps_init at grouting.  Same union-offset "
   "arithmetic as _bonded_state.",
 "solver/prestress_transfer.py:sequential_posttension_loss":
   "UNION: the closed-form transformed-section twin of the fiber "
   "driver, and the driver's acceptance test.  It takes rebars= AND "
   "tendons= as explicit arguments — it enumerates both classes; the "
   "scanner reads no 'bulk' word because the concrete enters as the "
   "scalar triple (Ac, Sc, Ic).",

 "solver/sls.py:DatumPolicy.__init__":
   "SLOT: holds the per-ZONE providers and ages.  Element moduli come "
   "from elem_material over the union slots, not from here.",
 "solver/sls.py:DatumPolicy.bulk_material":
   "SUBJECT: the bulk half of the two-method policy protocol "
   "(bulk_material / elem_material); the elem half spans rebar and "
   "tendon.",
 "solver/sls.py:DatumPolicy.explain":
   "SUBJECT: explains a bulk-zone modulus resolution.",
 "solver/sls.py:MaterialMap.__post_init__":
   "SLOT: validates the two arrays, 'bulk' (per zone) and 'elem' (per "
   "UNION element).  'elem' spans rebar and tendon by construction — "
   "_slot_inventory builds it from rebars + tendons — so a class-name "
   "in this code would be a class-name the design deliberately removed "
   "(12_0d, MaterialMap keyed by zone slot, not by material identity).",
 "solver/sls.py:MaterialMap.n_zones":
   "SLOT: one-line accessor on the bulk array.",
 "solver/sls.py:MaterialMap.require_cover":
   "SLOT: checks that the map covers n_zones AND n_union — the second "
   "argument is exactly the tendon-inclusive count.",
 "solver/sls.py:_expand_key":
   "SLOT: expands an override key over slots_bulk and slots_elem, the "
   "latter spanning both element classes.",
 "solver/sls.py:_expand_overrides":
   "SLOT: same, for the whole override mapping.",
 "materials/verification_limits.py:StressLimits.__post_init__":
   "SUBJECT: validates a set of stress thresholds.  'k_c' and "
   "'custom_zone_strengths' are properties of a bulk ZONE's concrete; "
   "the rebar and tendon thresholds beside them are plain scalars "
   "that need no class-aware handling.",
 "materials/verification_limits.py:StressLimits._validate_k_c":
   "SUBJECT: validates one coefficient.  The quantity is the "
   "concrete's, so bulk is the only class the question has.",
 "materials/verification_limits.py:StressLimits._validate_custom_zone_strengths":
   "SUBJECT: validates declared strengths keyed by bulk-zone name.  A "
   "rebar or a tendon is not a zone and has no entry here; its "
   "strength lives on its own material.",
 "materials/verification_limits.py:StressLimits.strength_for":
   "SUBJECT: resolves the strength of one bulk ZONE, custom or "
   "material.  The question is about a zone.",
 "materials/verification_limits.py:ec2_stress_limits":
   "SUBJECT: builds a limit set from EC2 coefficients.  It names the "
   "bulk coefficient because that is the one the norm expresses as a "
   "fraction of f_ck; the steel and tendon limits it also builds are "
   "products the caller supplies f_yk and f_pk for, so both element "
   "classes are served without either being resolved here.",
 "solver/sls.py:_zone_declared_materials":
   "SUBJECT: returns the declared material of every bulk ZONE.  It "
   "names bulk and nothing else because that is the whole question: "
   "element materials are carried by the elements and reached through "
   "the union slots, never through this list.",
 "solver/sls.py:covered_zone_slots":
   "SUBJECT: returns which ZONE slots an override set covers; the "
   "question asked is about zones.",
 "solver/sls.py:resolve_moduli":
   "SLOT: resolves both slot families in one loop over "
   "((slots_bulk, policy.bulk_material), (slots_elem, "
   "policy.elem_material)).  Both classes are covered, neither is "
   "named.",
 "solver/sls.py:_strain_entering_set":
   "SUBJECT: the affine STRAIN field of the CONCRETE zones entering "
   "the resisting set.  Element strains are read from the plane, not "
   "from this field.",
 "solver/sls.py:_active_zone_labels":
   "SUBJECT: names of the active bulk zones, for messages.",
 "solver/sls.py:_strain_increment":
   "SUBJECT: increments the same per-zone concrete strain field.",
 "solver/sls.py:_decompression_probe":
   "SUBJECT: EN 1992-1-1 §7.3.1 decompression is a CONCRETE stress "
   "check, probed at an offset c_dec from the tendon.  It takes the "
   "tendon coordinates as (x_t, y_t) arguments — the tendon is the "
   "probe's origin, and what is evaluated there is the concrete.",
 "solver/sls.py:_zone_regions":
   "GEOMETRY: builds the polygon of each bulk zone.  A rebar or tendon "
   "is a point area and has no region.",
 "solver/sls.py:_extreme_fibre":
   "SUBJECT: the extreme CONCRETE fibre, by definition over zone "
   "polygons.  Steel stress limits are checked on the elements, "
   "elsewhere.",
 "solver/sls.py:_extreme_fibre_by_zone":
   "SUBJECT: the per-zone form of the same.",

 "solver/timeline.py:ConstructionTimeline.__init__":
   "CONFIG: stores events, points, loss models and tolerances.  No "
   "element is touched.",
 "solver/timeline.py:ConstructionTimeline.has_time_axis":
   "CONFIG: three-line predicate on the rheology switch.",
 "solver/timeline.py:ConstructionTimeline.from_document":
   "PARSER: forwards the document's blocks to from_block.",
 "solver/timeline.py:ConstructionTimeline.from_block":
   "PARSER: parses the event stream.  Event payloads are references "
   "(zone names, tendon names); the element objects do not exist yet.",
 "solver/timeline.py:ConstructionTimeline.validate":
   "SUBJECT: validates the two REFERENCE vocabularies an event can "
   "carry — zone names and tendon names.  There is no event kind that "
   "references a rebar, so there is no rebar vocabulary to validate.",
 "solver/timeline.py:ConstructionTimeline.resolve":
   "DELEGATE: the resolution walk.  It enumerates zones (casting "
   "datums) and tendons (stressing/grouting); rebars are never staged "
   "independently — they belong to their parent zone and enter with "
   "it, which is the staging model, not an omission.",
 "solver/timeline.py:ConstructionTimeline._zone_loss_model":
   "SUBJECT: which rheological model governs a bulk zone.",
 "solver/timeline.py:ConstructionTimeline._zone_providers":
   "SUBJECT: builds the per-zone provider map, with drying geometry "
   "(A_c, u) — a concrete quantity.",
 "solver/timeline.py:ConstructionTimeline._datum_view":
   "DELEGATE: materialises the service view at a datum.  The element "
   "walk is inside materialize_view, over the union index.",
 "solver/timeline.py:ConstructionTimeline._datum_moduli":
   "SLOT: calls resolve_moduli, which covers both slot families.",
 "solver/timeline.py:ConstructionTimeline._auto_datum":
   "SUBJECT: solves the locked-in plane of a zone being cast.  A datum "
   "is a property of a bulk zone; elements carry eps_init instead.",
 "solver/timeline.py:ConstructionTimeline._reconcile_grout":
   "SUBJECT: reconciles eps_init at a grout event, per tendon, against "
   "the zone's datum plane.  RATIFIED in Phase 18 (option 3): the "
   "chronology is inert at exactly 0.0 because the base demand is "
   "debit-free, and the case where that inertness would be a lie — a "
   "load between two jacks on an ungrouted tendon — is now refused by "
   "_check_load_between_jacks instead of silently answered.",
 "solver/timeline.py:ConstructionTimeline._record_driver":
   "SUBJECT: transcribes the post-tensioning driver's per-tendon "
   "stages into the ledger.",
 "solver/timeline.py:ConstructionTimeline.compile_combination":
   "DELEGATE: selects the event prefix for an anchor and calls the "
   "guards and _emit_prefix_stages.  It names no element.",
 "solver/timeline.py:ConstructionTimeline._emit_prefix_stages":
   "UNION: builds the stage list.  Its element bookkeeping is "
   "_nonbase_elements | _posttension_union_indices, both UNION indices "
   "spanning rebar and tendon.",
 "solver/timeline.py:ConstructionTimeline._stress_actions":
   "SUBJECT: a stress event acts on tendons.",
 "solver/timeline.py:ConstructionTimeline._grout_stage":
   "SUBJECT: a grout event acts on tendons.",
 "solver/timeline.py:ConstructionTimeline._check_interleave":
   "SUBJECT: refuses a 'stress' after a 'grout' of the SAME TENDON.  "
   "The guard's subject is the tendon's own state machine.",
 "solver/timeline.py:_validate_losses_spec":
   "PARSER: validates the interval's per-zone losses block.",
 "solver/timeline.py:_resolve_zone":
   "SUBJECT: resolves a zone reference to an index.",
 "solver/timeline.py:_tendon_name_index":
   "SUBJECT: the tendon name vocabulary.",
 "solver/timeline.py:_event_tendon_refs":
   "SUBJECT: reads the 'tendons'/'tendon' key of an event payload.",
 "solver/timeline.py:_tendon_info":
   "SUBJECT: geometry and material of one tendon by name.",
 "solver/timeline.py:_tendon_parent_zone":
   "SUBJECT: which bulk zone a tendon belongs to.  Names both classes "
   "it relates and no third one exists in the relation.",
 "solver/timeline.py:_tendon_union_index":
   "UNION: converts a tendon name into its union index, n_rebars + k.  "
   "Naming rebar is the arithmetic that reaches the tendon.",
 "solver/timeline.py:_tendon_local_index":
   "SUBJECT: the local (per-class) index of a tendon.",
 "solver/timeline.py:_posttension_union_indices":
   "SUBJECT: the union indices of the tendons that are ever grouted.",
 "solver/timeline.py:_classify_pre_post":
   "SUBJECT: pre- versus post-tensioning is decided by whether a "
   "tendon's PARENT ZONE is cast when it is stressed.  The two classes "
   "it names are the two the relation is between.",
 "solver/timeline.py:_n_zones":
   "SUBJECT: zone count of a staged manager.",
 "solver/timeline.py:_zone_elements":
   "UNION: returns the union indices belonging to a zone — it walks "
   "rebars and tendons together and returns one index set.  The "
   "scanner reads 'zone'; the code reads both classes.",
 "solver/timeline_run.py:run_timeline":
   "ENTRY: the timeline entry point.  It forwards to resolve and "
   "compile_combination and prints; it enumerates nothing itself.",
 "solver/timeline_run.py:run_sls":
   "DRIVER: walks the combinations of a document to the SLS engine.  "
   "It names 'tendon' only through a stage's prestress actions, which "
   "only tendons carry; it enumerates no element class itself.",
})

# ======================================================================
#  UNCLASSIFIED — check, prestress_ledger, prestress_transfer,
#  section_state
# ======================================================================

_add({
 "solver/check.py:VerificationEngine.__init__":
   "CONFIG: reads the output flags and stores the two diagram objects.",
 "solver/check.py:VerificationEngine._check_staged":
   "DELEGATE: walks stages and computes eta_path.  Element limits come "
   "from the solver's element_limit_groups, which enumerates all three; "
   "'tendon' appears here only through the prestress actions the "
   "stages carry.",

 "solver/prestress_ledger.py:TendonRecord.__init__":
   "SUBJECT: the ledger's record IS a tendon record.  A rebar has no "
   "jacking state machine to record.",
 "solver/prestress_ledger.py:TendonRecord.__repr__":
   "SUBJECT: repr of the above.",
 "solver/prestress_ledger.py:PrestressLedger.__init__":
   "SUBJECT: the ledger.  It names 'zones' because it also records "
   "per-zone facts of each step alongside the per-tendon ones; that is "
   "a second dictionary, not a walk over element classes.",
 "solver/prestress_ledger.py:PrestressLedger.record_state":
   "SUBJECT: records a tendon's state transition.",
 "solver/prestress_ledger.py:PrestressLedger.record_emission":
   "SUBJECT: records an action emitted for a tendon.",
 "solver/prestress_ledger.py:PrestressLedger.record_substep":
   "SUBJECT: records a per-tendon substep of a driver.",
 "solver/prestress_ledger.py:PrestressLedger.record_zone":
   "SUBJECT: the per-zone cell of the same ledger; the sibling of "
   "record_state, not a partial version of it.",
 "solver/prestress_ledger.py:PrestressLedger.cancel":
   "SUBJECT: cancels the live actions of one tendon.",
 "solver/prestress_ledger.py:PrestressLedger.at":
   "SUBJECT: one-line lookup by (event, tendon).",
 "solver/prestress_ledger.py:PrestressLedger.state_of":
   "SUBJECT: the state of one tendon at an event.",
 "solver/prestress_ledger.py:PrestressLedger.live_actions":
   "SUBJECT: how many actions of one tendon are live.",
 "solver/prestress_ledger.py:PrestressLedger.assert_single_side":
   "SUBJECT: the invariant that a tendon is accounted for on ONE side "
   "(section element or demand action) at a time.  The invariant is "
   "about tendons; no other class can be on two sides.",
 "solver/prestress_ledger.py:PrestressLedger.items":
   "SUBJECT: flattens the ledger into fingerprint keys.  Both its "
   "dictionaries (tendon records, zone cells) are emitted; the walk is "
   "over the ledger's own structure, not over element classes.",
 "solver/prestress_ledger.py:PrestressLedger.__repr__":
   "SUBJECT: repr of the above.",

 "solver/prestress_transfer.py:solve_pretension_transfer":
   "UNION: the pretension release solve.  Bulk and tendon are named "
   "explicitly; rebar enters through the section's own union arrays "
   "that the solver integrates, not through an enumeration here.",

 "solver/section_state.py:SectionState.capacity_digest":
   "UNION: hashes geometry plus the ACTIVE AND BONDED union elements "
   "(np.nonzero(self.active & self.bonded)), with quantised eps_init.  "
   "That index set spans rebar and tendon; neither word appears "
   "because neither is needed.",
 "solver/section_state.py:SectionState.copy_advanced":
   "UNION: copies the union arrays (active, bonded, eps_init) plus the "
   "zone arrays.  Class-agnostic by construction.",
 "solver/section_state.py:SectionState.with_bulk_eps":
   "SUBJECT: sets the bulk prestrain scalar.  The element counterpart "
   "is with_eps_init, over the union index.",
 "solver/section_state.py:SectionState.with_bulk_activated":
   "SUBJECT: activates bulk zones with their locked-in planes.  The "
   "element counterpart is with_grouted.",
 "solver/section_state.py:SectionState.with_bulk_plane_delta":
   "SUBJECT: moves the locked-in plane of bulk zones.",
 "solver/section_state.py:PrestressAction.from_force":
   "SUBJECT: a demand-side prestress couple.  Only a tendon has one.",
 "solver/section_state.py:PrestressAction.from_force_uls":
   "SUBJECT: the ULS form of the same, with the declared "
   "delta_sigma_p of an UNBONDED tendon and the sigma_pd cap.",
 "solver/section_state.py:_staging_parents":
   "UNION: builds the parent-zone array for the WHOLE union, rebars "
   "then tendons, in that order (n_reb + n_ten).  It enumerates both "
   "element classes explicitly.",
 "solver/section_state.py:_apply_bulk_staging":
   "SUBJECT: masks and offsets the bulk fibres of a view.  Element "
   "staging is the union arrays, applied by the caller.",
 "solver/section_state.py:StagedDomainManager.__init__":
   "CONFIG: stores the base section and the generation kwargs.",
 "solver/section_state.py:StagedDomainManager.resolve_stages":
   "DELEGATE: walks the stage list and applies section_ops.  The "
   "element walk is inside the SectionState methods, over the union.",
})

# ======================================================================
#  Absolved by structural category in 17_2, restated per site so that a
#  member of a family carries its own reason rather than inheriting one.
# ======================================================================

_add({
 "api.py:_Session.build": "ENTRY: builds the session's section and solver and forwards.",
 "api.py:_section_info": "REPORT: serialises the geometry summary; the tendon block is emitted by the timeline dump.",
 "cli.py:_run": "ENTRY: command dispatch.",
 "cli.py:_print_analysis_table": "REPORT: prints the analysis table; the per-class rows come from the decomposition it is handed.",

 "geometry/fiber.py:RebarLayer.__post_init__": "SUBJECT: validates a rebar layer.",
 "geometry/fiber.py:Tendon.__post_init__": "SUBJECT: validates a tendon.",
 "geometry/geometry.py:GenericSection._mesh_grid": "GEOMETRY: meshes the bulk polygon.",
 "geometry/geometry.py:GenericSection._mesh_triangular": "GEOMETRY: the Delaunay alternative to _mesh_grid.",
 "geometry/geometry.py:GenericSection._normalize_bulk_zones": "GEOMETRY: normalises the declared bulk zone overlays.",
 "geometry/geometry.py:GenericSection.n_zones": "GEOMETRY: bulk zone count.",
 "geometry/geometry.py:GenericSection.zone_index": "GEOMETRY: zone lookup by name.",
 "geometry/geometry.py:GenericSection._material_index": "GEOMETRY: maps a fibre to its zone material.",
 "geometry/geometry.py:GenericSection.get_material_for_fiber": "GEOMETRY: the public form of _material_index.",
 "geometry/geometry.py:GenericSection.get_all_bulk_materials": "GEOMETRY: the bulk material list.",
 "geometry/geometry.py:GenericSection._setup_rebars": "GEOMETRY: builds the rebar arrays; _setup_tendons is its sibling.",
 "geometry/geometry.py:GenericSection._setup_tendons": "GEOMETRY: builds the tendon arrays; _setup_rebars is its sibling.",
 "geometry/geometry.py:GenericSection._resolve_tendon_parents": "GEOMETRY: assigns each tendon its parent zone; the relation is bulk-to-tendon and has no rebar side.",
 "geometry/geometry.py:GenericSection.compute_ideal_properties": "HOMOGEN: ideal gross properties homogenise bulk and rebar; a tendon's contribution is the duct/strand area handled by the prestress path (ideal_gross_properties.rst).",
 "geometry/geometry.py:GenericSection.mesh_summary": "REPORT: mesh statistics, a bulk quantity.",
 "geometry/geometry.py:GenericSection.__repr__": "REPORT: repr.",
 "geometry/properties.py:_extreme_distances_along_direction": "GEOMETRY: extreme distances of the rebar set along a direction.",
 "geometry/properties.py:_plastic_modulus_along_direction": "GEOMETRY: plastic modulus of the homogenised bulk+rebar section.",
 "geometry/properties.py:_plastic_modulus_along_direction.area_below": "GEOMETRY: inner helper, bulk area below a line.",
 "geometry/properties.py:compute_section_properties": "HOMOGEN: the same homogenisation as compute_ideal_properties.",

 "io_yaml.py:_construct_material": "PARSER: builds one material from its declared block.",
 "materials/concrete.py:Concrete.reference_modulus":
   "SUBJECT (BULK): the conventional secant modulus of the bulk "
   "concrete. It names no rebar and no tendon because it is a property "
   "of one material and not a walk over the section. Since Phase 21 it "
   "does not derive the value either -- it asks the NormativeCode the "
   "material was declared under, and declines when none was declared. "
   "F-P21-1: EN 1992-1-1 Table 3.1 and ACI 318-19 19.2.2.1 read the "
   "same f_ck and disagree by 33.9 % at C25.",
 "io_yaml.py:_parse_zone_rheology": "PARSER: the zone_rheology block.",
 "io_yaml.py:_parse_rebars": "PARSER: the rebars block; _parse_tendons is its sibling.",
 "io_yaml.py:_parse_tendons": "PARSER: the tendons block; _parse_rebars is its sibling.",
 "io_yaml.py:_parse_combination": "PARSER: a combination block; 'tendon' appears through prestress action refs.",
 "io_yaml.py:_parse_sls_moduli": "PARSER: the sls.moduli sub-block; the axis is the bulk zone, so no element class is named.",
 "io_yaml.py:_parse_stress_limits": "PARSER: the sls.limits sub-block; fyk/fpk are limit inputs, not element references.",
 "io_yaml.py:_parse_bulk_prestrain": "PARSER: the bulk prestrain block.",
 "io_yaml.py:_resolve_prestress_actions": "PARSER: resolves declared prestress actions, which only tendons have.",
 "io_yaml.py:_tendon_name_map": "PARSER: the tendon name vocabulary of a document.",
 "io_yaml.py:_resolve_single_prestress_action": "PARSER: the singular form of _resolve_prestress_actions.",
 "io_yaml.py:_parse_section_ops_spec": "PARSER: the section_ops block, whose operands are zones.",
 "io_yaml.py:_union_name_map": "UNION: builds the union name map from rebars + tendons; it enumerates both element classes and no bulk zone has a union index.",
 "io_yaml.py:_parse_output_flags": "CONFIG: the output flags block.",

 "materials/concrete.py:Concrete.stress_array": "MATERIAL: the concrete constitutive law.",
 "materials/concrete.py:Concrete.tangent_array": "MATERIAL: its tangent.",
 "materials/ec2_bridge.py:concrete_from_ec2": "MATERIAL: EC2 concrete factory.",
 "materials/ec2_bridge.py:concrete_from_class": "MATERIAL: EC2 concrete factory by strength class.",
 "materials/ec2_bridge.py:service_concrete_from_ec2": "MATERIAL: EC2 service-law factory; reads (3.14) constants at an age and derives none of them.",
 "materials/ec2_bridge.py:prestress_from_class": "MATERIAL: EC2 prestressing steel factory by class.",
 "materials/prestress_properties.py:fbpren.__init__": "MATERIAL: the EC2 prestressing-steel property bridge.",

 "output/export.py:export_fiber_results_csv": "REPORT: one CSV per element family; the join is the file set.",
 "output/export.py:export_analysis_csv": "REPORT: the analysis CSV.",
 "output/geometry_plot.py:plot_section_properties": "RENDER: draws the homogenised properties panel.",
 "output/geometry_plot.py:print_section_properties": "REPORT: prints the same.",
 "output/plots.py:_draw_cast_zones": "RENDER: the bulk-zone artist.",
 "output/plots.py:_cast_legend_entry": "RENDER: its legend entry.",
 "output/plots.py:_draw_neutral_axis": "RENDER: the neutral axis, a property of the plane.",
 "output/plots.py:plot_section_state": "RENDER: composes the per-family artists.",
 "output/plots.py:plot_section": "RENDER: the bulk outline; elements are drawn by their own artists.",
 "output/plots.py:_draw_geometry_panel": "RENDER: the geometry panel.",
 "output/plots.py:_draw_field_panel": "RENDER: the field panel.",
 "output/plots.py:plot_moment_curvature": "RENDER: an M-chi curve carries no element class.",
 "output/plots.py:plot_demand_heatmap": "RENDER: a demand heatmap carries no element class.",
 "output/plots.py:plot_polar_ductility": "RENDER: the polar ductility figure.",
 "output/plots.py:plot_stress_profile": "RENDER: the stress profile panel.",
 "output/report.py:print_section_info": "REPORT: geometry summary.",
 "output/report.py:print_fiber_results": "REPORT: the fibre table.",
 "output/report.py:print_sls_results": "REPORT: the SLS table, whose subject is concrete stress.",
 "output/timeline_dump.py:_zone_entries": "REPORT: the zone section of the dump; _tendon_entries and _rebar_entries are its siblings.",
 "output/timeline_dump.py:_tendon_entries": "REPORT: the tendon section of the dump.",
 "output/timeline_dump.py:_rebar_entries": "REPORT: the rebar section of the dump.",
 "output/timeline_dump.py:_rebar_zone": "REPORT: which zone a rebar is dumped under.",
 "output/timeline_dump.py:_emission_entries": "REPORT: the prestress emission section of the dump.",
 "output/timeline_projections.py:cast_steps_from_dump": "REPORT: reads the cast steps out of a dump.",
 "output/timeline_projections.py:project_zones_csv": "REPORT: the zone projection; project_tendons_csv is its sibling.",
 "output/timeline_projections.py:project_tendons_csv": "REPORT: the tendon projection.",
 "output/timeline_projections.py:project_steps_csv": "REPORT: the step projection.",
 "output/timeline_projections.py:project_timeline_figure": "RENDER: composes the projections into a figure.",

 "solver/losses.py:_zone_drying_geometry": "SUBJECT: (A_c, u) of a bulk zone — a concrete drying quantity.",
 "solver/posttension.py:IntraSequenceUndeclared.__init__": "SUBJECT: the Phase 22 undeclared-role refusal; its subject is the tendon set that is in neither `order` nor `pending`.",
 "solver/posttension.py:LoadBetweenJacksNotModelled.__init__": "SUBJECT: the Phase 18 scope boundary; its subject is the ungrouted tendon set.",
 "solver/posttension.py:PreexistingStateUndeclared.__init__": "SUBJECT: the Phase 24 declaration boundary; its subject is the tendon set declared already bonded, not an element walk. Succeeds PreexistingBondedNotModelled.__init__, which named the same subject under the Phase 22 reading (unmodelled physics) rather than the Phase 24 one (undeclared input).",
 "solver/posttension.py:PreexistingState.locked_in_strain": "SUBJECT: the declared retrofit's own tendons, keyed by the indices of `sigma_pe`. It forms eps_init = sigma_pe/Ep - eps_c from the declaration alone, for the instant before any sequence has run, and never walks the union element array or reaches a section.",
 "solver/timeline.py:ConstructionTimeline._build_preexisting": "SUBJECT: the tendon NAMES the retrofit event declares, translated to tendon-array indices. It is the single crossing between the document's vocabulary and the driver's; the element classes it never touches are the union array's, because a pre-existing cable is identified by name and by nothing else.",
 "solver/timeline.py:_parse_retrofit_event": "SUBJECT: the keys of a YAML `retrofit` payload, validated against RETROFIT_KEYS / RETROFIT_CONCRETE_KEYS / RETROFIT_TENDON_KEYS. Pure document validation, before any section exists: there is no element to classify at this point and the tendon names are checked against the section later, in _build_preexisting.",
 "solver/posttension.py:PreexistingState.__post_init__": "SUBJECT: validates the declared retrofit; its subject is the declared {tendon: stress} and {tendon: age} mappings, keyed by tendon index. It never walks the union element array and never reaches a section.",
 "solver/posttension.py:_effective_action": "SUBJECT: one tendon, by index, from a result that already carries per-tendon arrays. The per-tendon core factored out of PosttensionSequenceResult.effective_actions so that grout() can form actions on a retrofit result, where the aggregate method refuses.",
 "solver/posttension.py:_tendon_geometry": "SUBJECT: (x, y, Ap) of the tendon set.",
 "solver/section_state.py:geometry_signature": "GEOMETRY: hashes the mesh and the union element coordinates.",
 "solver/section_state.py:StagedDomainManager._collect_union_materials": "UNION: collects the content tokens of the union elements, rebars then tendons.",
 "solver/timeline.py:ConstructionTimeline._rheology_snapshot": "REPORT: the per-zone rheology snapshot.",
 "solver/timeline.py:ConstructionTimeline._zone_rheology_entry": "SUBJECT: the declared rheology entry of one zone.",
 "solver/timeline.py:ConstructionTimeline._check_load_between_jacks": "SUBJECT: the Phase 18 guard; its subject is the stressed-not-grouted tendon set.",
 "tolerances.py:Tolerances.grout_readback_rel": "CONFIG: a tolerance name.  The lexical scan matches the word 'grout', not a walk over elements.",
})


def reason_for(key: str) -> Optional[str]:
    r"""
    The recorded reason for a partial site, or ``None``.

    Parameters
    ----------
    key : str
        ``"<relpath>:<qualname>"``, exactly as
        ``element_class_inventory`` builds it.

    Returns
    -------
    str or None
        The reason, whitespace-collapsed to one line; ``None`` if the
        site has never been read.
    """
    val = REASONS.get(key)
    return None if val is None else " ".join(val.split())


# ======================================================================
#  ARCHIVE — reasons for sites that are NO LONGER partial.
#
#  The rule, decided in Phase 20 and stated here because it is the
#  kind of rule that decays if it lives only in a handoff:
#
#    A reason whose site stops being partial is MOVED here, with the
#    phase that repaired it.  It is never deleted and never left in
#    REASONS.
#
#  Why not delete.  The reason for a repaired site is the record of
#  the repair -- N-13, N-14, N-15 and N-16 are each a measured
#  sentence about what the code used to get wrong, and the ledger
#  entries that describe them are prose in handoff/ that no gate
#  reads.  Deleting the reason would leave the repair described only
#  in a document, which is the drift this whole file exists to stop.
#
#  Why not leave them in REASONS.  Phase 19 shipped three of them
#  there, and --gate printed all three on every invocation as
#  "recorded reason(s) describe sites that are no longer partial".
#  That list only grows: three now, ten in a few phases, and a gate
#  whose green output is mostly a changelog is a gate people stop
#  reading.  The count is the signal; the text is the archive.
#
#  The gate enforces the move: a key in REASONS that names a site the
#  inventory no longer reports as partial fails --gate, with the
#  instruction to move it here.
# ======================================================================

REPAIRED: Dict[str, str] = {
 "solver/sls.py:_affine_entering_set [B--, to Phase 27]":
   "Phase 28: RENAMED to _strain_entering_set when D27-1 moved the "
   "accumulation from stress to strain.  The subject is unchanged -- "
   "it is still the entering concrete zones -- so the reason moved "
   "with the name.  Archived so a reader of the Phase-27 ledger finds "
   "the transition rather than a hole.",
 "solver/sls.py:_affine_increment [B--, to Phase 27]":
   "Phase 28: RENAMED to _strain_increment, same transition and same "
   "subject.  The modulus left the expression because it belonged "
   "there only while the field carried stress.",
 "solver/posttension.py:solve_posttension_sequence [--T, to Phase 24]":
   "Phase 25: the signature moved from --T to B-T when D1c put the "
   "declared plane of the existing concrete into the resisting view as "
   "an imposed bulk strain.  A RECLASSIFICATION, not a deletion: the "
   "site is still there and its subject is unchanged.  Archived so a "
   "reader of the Phase-24 ledger finds the transition rather than a "
   "hole.",
 "solver/posttension.py:solve_posttension_sequence._run_sequence "
 "[--T, to Phase 24]":
   "Phase 25: same reclassification as its parent, and for the same "
   "reason -- the sweep carries the declared bulk plane.  The old "
   "signature is archived, not retired.",
 "solver/posttension.py:PreexistingBondedNotModelled.__init__": "Phase 24: the class was renamed to PreexistingStateUndeclared and retyped to ValueError when the retrofit stopped being unmodelled physics and became a declarable input. The subject did not change -- it is still the declared tendon set -- so the reason moved with the name rather than being retired. Kept here so a reader of an older ledger finds the site rather than a hole.",
 "io_yaml.py:_build_material":  # no longer partial since Phase 21
   "DELEGATE: since Phase 21 this is the stamping wrapper. It resolves "
   "the model's normative declaration into a NormativeCode and stamps "
   "it on whatever _construct_material returns; the element walk it "
   "used to carry moved there with the body. One application point "
   "for the declaration rather than one per return, so no "
   "construction path can forget it.",
 "solver/analysis.py:_build_material_name_map":  # repaired in Phase 18 (N-13)
   "DEFECT (N-13, REPAIRED in Phase 18): walked bulk and rebar only "
   "while _decompose's tendon branch read the map; every tendon "
   "component fell back to type(mat).__name__.  Now walks tendons too; "
   "the signature stays partial only because the map is keyed by "
   "id(material) and the word 'rebar' dominates the scan.",
 "solver/capacity.py:NMDiagram.__init__":  # repaired in Phase 18 (N-14) and Phase 19 (N-16)
   "DEFECT (N-14 REPAIRED in Phase 18, N-16 REPAIRED in Phase 19): two "
   "section-wide quantities in one constructor, each assembled from "
   "two of the three element classes.  N-14 was the strain-plane sweep "
   "ENVELOPE (the numerator of chi_max): built from bulk and rebar "
   "while its own accessor's docstring promised 'all materials', so on "
   "a strand-only slab the tensile end collapsed to 0.0.  N-16 was the "
   "lever-arm HULL _all_lx/_all_ly (the denominator): built the same "
   "way, so a non-embedded tendon outside the fibre hull was absent "
   "from the projected depth every sweep divides by.  Measured on "
   "examples/example_external_tendon.yaml: span 594 mm against a true "
   "747 mm, an excess ceiling of 1.257576 exactly, and the first "
   "curvature at which a limit was SEEN exceeded overshot the true "
   "crossing by +5.24 % against +0.42 % after the repair (N = "
   "-1000 kN).  Both now enumerate all three classes, each tendon "
   "shifted by its locked-in eps_init where the quantity is a strain.",
 "solver/integrator.py:FiberSolver._solve_pure_axial":  # repaired in Phase 19 (N-15)
   "DEFECT (N-15, REPAIRED in Phase 19): eps_hi = max(0, rebar "
   "eps_max) — the bisection bracket was built from bulk and rebar "
   "only, so on a tendon-carrying section the tensile end of the "
   "bracket was short.  Now includes each tendon's limit shifted by "
   "its locked-in eps_init, the same form N-14 uses for the sweep "
   "envelope.  Measured on a 1200x200 strand-only slab (700 mm2 at "
   "eps_pe = 0.0060): peak N reachable by the old range 819.0 kN "
   "against a true axial tensile capacity of 1112.3 kN, i.e. 26.37 % "
   "of the real capacity with no bracket, and targets at 90/95/99 % "
   "all returning non-convergent.  The registered figure of 13.6 % is "
   "not reproduced and not disputed: the band is a function of the "
   "geometry and 18_0 records no geometry for it.  The claim that "
   "solve_equilibrium's uniaxial routing SCREENED this is measured "
   "FALSE — the outer solve returns non-convergent on both trees for "
   "the same targets.  The routing is now a stated contract anyway, "
   "because the routine must be answerable on its own.",
}



def repaired_reason_for(key: str) -> Optional[str]:
    r"""
    The archived reason for a site that is no longer partial.

    Parameters
    ----------
    key : str
        ``"<relpath>:<qualname>"``.

    Returns
    -------
    str or None
        The archived reason, whitespace-collapsed to one line, or
        ``None`` when the key was never archived.
    """
    val = REPAIRED.get(key)
    return None if val is None else " ".join(val.split())
# GENSEC-COMPLETE phase=35 utc=2026-09-09T20:49:46Z sha256=33a3a567044ef4c5b8884ac1c9481c5f09d2fa1cbe1951255bddac95cce327a9 body_lines=798
