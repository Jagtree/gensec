#!/usr/bin/env python3
r"""
Generate ``patchers/run_phase21_codes.py`` from the tested tree.

The generator reads the files Phase 21 moved **from disk, as bytes**,
measures each one's line-ending convention at byte level **once**, and
emits a standalone patcher carrying the verified content.  The emitted
patcher's machinery (``_looks_like_root``, ``_verified``, ``_kind``,
``_write_route``, ``_commit``, ``main``) is lifted verbatim from
``run_phase19_hull.py``, so N-10's all-or-nothing commit travels
unchanged instead of being retyped.

``measure_line_ending`` refuses to emit a mixed file rather than
declaring one convention for it.  That behaviour is taken from
``make_phase20_patcher.py``, which is kept in the tree as provenance:
a lone ``\r`` is an error, not a line ending, and a file that mixes
CRLF and LF cannot be transported under a single declaration.
"""

from __future__ import annotations

import base64
import hashlib
import textwrap
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase20_axial.py"
OUT = ROOT / "patchers" / "run_phase21_codes.py"

#: The payload, in the order a reader should meet it: the repair, the
#: instruments, the gates' own records, the fixtures, the example, the
#: documents.  Completeness is **measured** after generation by
#: comparing the tree this produces against the tree the suite ran
#: green on -- never assumed.
FILES = [
    "src/gensec/materials/base.py",
    "src/gensec/materials/codes.py",
    "src/gensec/materials/concrete.py",
    "src/gensec/io_yaml.py",
    "src/gensec/solver/integrator.py",
    "src/gensec/solver/timeline.py",
    "tools/element_class_inventory.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/getattr_inventory.py",
    "tools/getattr_reasons.py",
    "tools/selfcheck_inventory.py",
    "tests/run_phase4_yaml_validation.py",
    "tests/test_phase12_ledger.py",
    "tests/test_phase12_p3_closure.py",
    "tests/test_phase12_p3_red.py",
    "tests/test_phase13_dump.py",
    "tests/test_phase18_scope.py",
    "tests/test_phase19_hull.py",
    "tests/test_phase21_codes.py",
    "tests/test_phase8_task1.py",
    "examples/P60-60_1_update.yaml",
    "examples/Pannello_187x30.yaml",
    "examples/Pannello_30x187.yaml",
    "examples/biaxial_column.yaml",
    "examples/example_aci318.yaml",
    "examples/example_annulus.yaml",
    "examples/example_biaxial_column.yaml",
    "examples/example_composite_losses.yaml",
    "examples/example_composite_losses_fb_gap.yaml",
    "examples/example_composite_timeline.yaml",
    "examples/example_composite_topping.yaml",
    "examples/example_custom.yaml",
    "examples/example_external_tendon.yaml",
    "examples/example_input.yaml",
    "examples/example_prestress.yaml",
    "examples/example_staged_construction.yaml",
    "examples/example_staged_cracking.yaml",
    "examples/example_strand_only_slab.yaml",
    "examples/example_tee.yaml",
    "examples/example_v2_1.yaml",
    "examples/test_exotic.yaml",
    "examples/vcaslu_1.yaml",
    "examples/yaml_reference_example.yaml",
    "docs/yaml_reference.rst",
    "handoff/00_BOOTSTRAP.md",
    "handoff/21_0-GENSEC_LEDGER_21.md",
    "handoff/21_1-GENSEC_PHASE21_RECAP.md",
]




DOCSTRING = r'''r"""
GenSec Phase 21 — F-P21-1: the input declares the normative code, and
everything code-dependent is derived from it.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64``
of exactly what was on disk in the tree the Phase 21 suite ran green
on, line endings included.

The rule, which the project always stated and never wired: *the input
declares the code, and everything is derived from it; or the input
declares that the material is custom, and then GenSec derives
nothing.*  There is no third option and in particular no implicit one.

* ``src/gensec/materials/codes.py`` — **new**.  The registry of
  ``NormativeCode``: ``ec2``, ``ntc18`` (a subclass of the Eurocode,
  because §11.2.10.3 adopts its formulation so the value coincides and
  only the citation differs), ``aci318-19``, ``custom`` and
  ``undeclared``.  Plus ``CodeReferenceModulus``, the genuinely
  agnostic rule: it derives nothing and asks the code stamped on each
  material, so one model can mix a precast beam under EN 1992-1-1 with
  a topping under ACI 318-19;
* ``src/gensec/materials/base.py`` — ``NormativeChoiceNotDeclared``,
  beside ``OutOfDeclaredDomain`` in the scope-boundary half of the
  exception taxonomy.  A ``NotImplementedError``, so the resolver's
  existing ``except`` catches it and a Eurocode build sees nothing;
* ``src/gensec/materials/concrete.py`` — the material no longer
  derives its own modulus.  Measured: it returned EN 1992-1-1's
  35 220.5 MPa for a ``Concrete(fck=40)`` that named no code, and an
  ACI rule installed by the caller **lost to it** — 35 220.5 instead
  of 29 725.4.  A default that cannot be overridden is not a default;
* ``src/gensec/io_yaml.py`` — the loader reads ``code:`` at the top
  level and per material, and stamps the resolved ``NormativeCode``
  on every material at one application point rather than one per
  ``return``.  A material type that names a code counts as a
  declaration, which is why no existing input file changes;
* ``src/gensec/solver/timeline.py`` — ``code=`` on the timeline, read
  by ``from_document`` from the one home for top-level keys;
* ``examples/example_aci318.yaml`` — the first distributed model that
  is **not** a Eurocode model.  Until now they all were, so a
  container that had quietly become Eurocode-shaped would have looked
  identical from outside;
* the two inventories, their reason tables and the baseline — both
  gates went red on their own against this phase's code and the
  archive rule decided in Phase 20 applied unchanged;
* ``tests/test_phase21_codes.py`` (six discriminating reds on the
  pristine Phase 20 tree, zero ``ImportError``, zero
  ``AttributeError``) and ``tests/test_phase12_p3_closure.py``, two of
  whose tests pinned the defect and were rewritten.

Measured: **0 numbers move** on all three fingerprints; the 152 new
numeric keys are the ACI example and are ``ADDED``.  Nothing an EC2
build could reach has been taken away.

Usage
-----
::

    python3 patchers/run_phase21_codes.py --selfcheck
    python3 patchers/run_phase21_codes.py --repair
"""'''


def measure_line_ending(data: bytes) -> str:
    r"""
    The line-ending convention of *data*, measured at byte level.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
        ``'CRLF'``, ``'LF'``, or ``'none'`` for a file with no line
        break at all.

    Raises
    ------
    ValueError
        If the file mixes conventions or carries a lone ``\r``.  A
        mixed file cannot be transported with a single declaration,
        and declaring one anyway is the failure mode this measurement
        exists to prevent.
    """
    crlf = data.count(b"\r\n")
    bare_lf = data.count(b"\n") - crlf
    bare_cr = data.count(b"\r") - crlf
    if bare_cr:
        raise ValueError(f"lone CR present: {bare_cr}")
    if crlf and bare_lf:
        raise ValueError(f"mixed: {crlf} CRLF and {bare_lf} bare LF")
    if crlf:
        return "CRLF"
    if bare_lf:
        return "LF"
    return "none"


def encode(data: bytes) -> str:
    r"""
    ``zlib`` + ``base64``, wrapped as a Python implicit concatenation.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
    """
    blob = base64.b64encode(zlib.compress(data, 9)).decode("ascii")
    chunks = textwrap.wrap(blob, 100)
    return "\n".join(f'        "{c}"' for c in chunks)


def main() -> int:
    r"""
    Emit the Phase 21 patcher.

    Returns
    -------
    int
        ``0`` on success, ``2`` when a payload file is missing.
    """
    src = SRC.read_text(encoding="utf-8")
    machinery = src[src.index("def _looks_like_root(root):"):
                    src.index("def main(argv=None):")]
    tail = src[src.index("def main(argv=None):"):]
    tail = tail.replace("Phase 19", "Phase 21")
    tail = tail.replace(
        '    print("GenSec Phase 19 patcher — the scan hull, the axial "\n'
        '          "bracket, the gate on vacuous selfchecks")',
        '    print("GenSec Phase 21 patcher — the declared normative "\n'
        '          "code, and everything derived from it")')

    payload, digests, endings = [], [], []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"MISSING {rel}")
            return 2
        data = path.read_bytes()
        le = measure_line_ending(data)
        payload.append(f'    "{rel}":\n{encode(data)},')
        digests.append(
            f'    "{rel}":\n        "{hashlib.sha256(data).hexdigest()}",')
        endings.append(f'    "{rel}": "{le}",')
        print(f"  {rel:<46} {len(data):>8} bytes  {le}")

    out = [
        DOCSTRING,
        "\nfrom __future__ import annotations\n",
        "import base64",
        "import hashlib",
        "import os",
        "import sys",
        "import zlib",
        "from pathlib import Path\n",
        "ROOT = Path(__file__).resolve().parent.parent\n",
        "#: ``{relative path: zlib+base64 of the verified bytes}``.",
        "PAYLOAD = {",
        "\n".join(payload),
        "}\n",
        "#: ``{relative path: sha256 of the verified bytes}``.",
        "DIGESTS = {",
        "\n".join(digests),
        "}\n",
        "#: ``{relative path: line-ending convention as MEASURED, at byte",
        "#: level, once, before generating}``.  Recorded so a reader can",
        "#: check the transport without decoding it.  No file in this",
        "#: payload is mixed; the generator refuses to emit one that is.",
        "LINE_ENDINGS = {",
        "\n".join(endings),
        "}\n\n",
        machinery,
        tail,
    ]
    OUT.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"\nwrote {OUT} ({OUT.stat().st_size} bytes), "
          f"{len(FILES)} file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
