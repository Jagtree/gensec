r"""
Build ``patchers/run_phase32_zone_limits_and_top_level.py``.

The mechanism is lifted verbatim from the Phase-30 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across four phases, and a
rewrite would put a verified thing back on trial for no gain.

Run from the repository root::

    python3 tools/make_phase32_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase30_coordinate_and_silences.py"
OUT = ROOT / "patchers" / "run_phase32_zone_limits_and_top_level.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    "src/gensec/io_yaml.py",
    "src/gensec/materials/verification_limits.py",
    "src/gensec/solver/sls.py",
    "tests/test_phase32_top_level_keys.py",
    "tests/test_phase32_zone_limits.py",
    "tests/run_phase7_sls_validation.py",
    "tests/run_phase8_task3_validation.py",
    "tests/run_phase31_multizone_bench_falsification.py",
    "tests/run_phase32_patcher_falsification.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase27_service_path.py",
    "tests/test_phase28_strain_accumulation.py",
    "tests/test_phase29_extreme_fibre_check.py",
    "tests/test_phase30_check_block.py",
    "tests/test_phase31_task_zero.py",
    "tools/numeric_fingerprint.py",
    "tools/completion_marker.py",
    "tools/getattr_reasons.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/material_assumption_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase32_patcher.py",
    ".fingerprints/32_00_numeric_PRE.txt",
    ".fingerprints/32_00_datum_PRE.txt",
    ".fingerprints/32_00_domain_PRE.txt",
    ".fingerprints/32_01_numeric_POST.txt",
    ".fingerprints/32_01_datum_POST.txt",
    ".fingerprints/32_01_domain_POST.txt",
    "handoff/32_0-GENSEC_LEDGER_32.md",
    "handoff/32_1-GENSEC_PHASE32_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 32 - the limit on the zone, and a silent top level.

What this transports
--------------------
**Task A.**  ``load_yaml`` read thirteen top-level keys with scattered
``data.get(...)`` calls and dropped everything else without a word,
while ``section.material_zones`` one level down already refused an
unknown key by name.  Three injections into a distributed example, all
three accepted in silence: an invented scalar, an invented mapping, and
``custom_zone_strengths`` -- the name ratified in Phase 31 for the
per-zone strengths this same patcher delivers.  Writing a ratified
block name in a document was indistinguishable from writing a typo.
The valid set now lives once, in ``VALID_TOP_LEVEL_KEYS``, and the
refusal names both the offending key and what was allowed instead.  The
denominator was measured before the refusal was written, by wrapping
``load_yaml`` and running the whole suite plus the sixteen validators:
200 loads, 56 distinct documents, ZERO unknown keys.  Nothing breaks
because nothing was relying on the silence.

**Task B.**  ``StressLimits.sigma_c_comp`` was ONE concrete limit for
the whole stage, compared against the largest compression anywhere in
the section.  On a composite that is not an imprecise limit but a false
pass: measured on a two-zone bench (base C45, topping C30, Mx = -350
kNm) the topping reached 22.5753 MPa, passed against the base's 27.0,
and the stage was reported verified while that zone stood at 125 % of
what its own material prescribes.  The limit is now derived per zone as
k_c * f_ck(zone), one check per present zone, each carrying its
provenance, its f_ck and its coefficient.  ``sigma_c_comp`` is deleted,
not kept beside the new path with a precedence rule -- the move 30_2 s4
forbids by name.  ``fck`` leaves ``ec2_stress_limits`` with it: it
existed only to form the product.  ``kind='transfer'`` now refuses
without declared strengths, because f_ck(t) is not the material's
28-day value and deriving it from that would be a silent normative
fallback in the UNSAFE direction.  Rebar and tendon thresholds do not
move: an element is not a zone.

The per-zone and section-wide extremes stop being rounded to six
decimals in the record.  The verdict is taken on those numbers, and
Phase 30 settled the rule in ``_check_entry``: the record publishes
what the verdict was taken on.  80 of the 92 fingerprint movements are
this, all at a relative magnitude <= 1.6e-07.

**Task C.**  The whole C5 loss arc -- creep, shrinkage, relaxation, the
tendon loss they add up to -- had ZERO keys in the numeric fingerprint,
on any bench and on any example.  Its validator answered pass or fail;
nothing answered moved by how much.  A synthetic bench adds 19 physics
keys over the three loss intervals, 2 recording the physical
discriminant phi(topping) > phi(base) as an inequality rather than a
value, and 1 pinning the interval count so that a history which stopped
producing losses would show as absent keys rather than silence.
Purely additive, measured: 6022 shared, 0 moved, 22 added.

**Also, Z-13.**  ``completion_marker --stamp`` had ``phase = 30`` as a
hardcoded default, written when the tool was built and never revisited.
The field it fills is PROVENANCE, and a default on a provenance field
asserts something false the moment the phase number moves: measured, it
labelled twenty Phase-32 files as Phase-30 work, inside the phase whose
own ledger records three earlier instances of a declaration its object
contradicts.  ``--phase`` is now mandatory and the twenty markers were
rewritten.

**Also.**  ``completion_marker`` counted ``src/gensec.egg-info``, so
the "in flight" total it publishes was 291 on a bare clone and 296 on
the same clone after an editable install; the denominator is now
invariant.  ``00_BOOTSTRAP.md`` s4 declared a suite total two phases
stale and s5/s5.1 described Phase 30 in full.

Idempotent, all-or-nothing, CRLF preserved per file.  ``--selfcheck``
compares bytes.  See handoff/32_0-GENSEC_LEDGER_32.md.
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
# GENSEC-COMPLETE phase=32 utc=2026-09-05T14:45:36Z sha256=eafb8f00f120effe9d250058d5c13ff644b5c9302edd9ab3fe6431fd797a2f26 body_lines=211
