r"""
Build ``patchers/run_phase25_increment_form.py``.

The mechanism is **not** rewritten: the head (imports, ``ROOT``,
``PATH_ALIASES``, ``_resolve``) and the whole tail (``_verified``,
``main`` and its ``--selfcheck`` / ``--repair`` modes) are lifted
verbatim from the Phase-24 patcher.  One home for one fact: a
second implementation of atomic transport would be a second thing to
be wrong.  Only three regions are authored here — the header
docstring, ``PAYLOAD`` and ``DIGESTS``.

Usage
-----
::

    python3 tools/make_phase25_patcher.py
"""

import base64
import hashlib
import pathlib
import sys
import textwrap
import zlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase24_declared_retrofit.py"
OUT = ROOT / "patchers" / "run_phase25_increment_form.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there.
FILES = [
    "src/gensec/solver/posttension.py",
    "tests/test_phase25_increment_form.py",
    "tools/numeric_fingerprint.py",
    "tools/datum_fingerprint.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase25_patcher.py",
    "docs/construction_timeline.rst",
    "claude_scratch/probe_d1c_magnitude.py",
    "claude_scratch/probe_d1c_blindness.py",
    ".fingerprints/25_00_numeric_PRE.txt",
    ".fingerprints/25_00_datum_PRE.txt",
    ".fingerprints/25_00_domain_PRE.txt",
    ".fingerprints/25_01_numeric_POST.txt",
    ".fingerprints/25_01_datum_POST.txt",
    ".fingerprints/25_01_domain_POST.txt",
    "handoff/25_0-GENSEC_LEDGER_25.md",
    "handoff/25_1-GENSEC_PHASE25_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]

HEADER = r'''r"""
GenSec Phase 25 — D1c: the form of the increment.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64`` of
exactly what was on disk in the tree the Phase 25 suite ran green on,
line endings included.  A patcher that re-derived content would be a
second implementation of the repair, and two implementations disagree.

The rule this phase wired: *a driver that assumes a premise must either
check it or declare it, and this one now needs neither because it no
longer assumes it.*  ``solve_posttension_sequence`` used to solve every
jack's action **alone, from zero strain**, and sum the planes it read
back.  That is exact when the section is linear elastic and only then.
It now applies each demand increment to the section **as it exists at
that step, from the strain state already accumulated**, and says so in
``increment_form``.

* ``src/gensec/solver/posttension.py`` — ``_advance`` replaces
  ``_solve``; ``_stressing_view`` gains ``eps_init`` (per-tendon, for
  the tendons that resist) and ``bulk_plane`` (the strain the existing
  concrete is already in, refused when the base state already carries a
  creep/shrinkage eigenstrain in the same array — their sum is neither
  of them).  The solver cache moves **inside** the sweep, because a
  view now carries initial strains that change between the sweeps of
  ``scheme='coupled'``.  Two new declared fields:
  ``increment_form='incremental_on_state'`` and
  ``declared_state_demand``, the sollecitazione the declared state
  implies — the base point of the sequence, and the only coherence
  check against the original design GenSec can offer.  It does not
  refuse on it: it does not know what is right;
* ``tools/numeric_fingerprint.py``, ``tools/datum_fingerprint.py`` —
  ``_EC2ServiceLaw``, an adapter over
  :func:`~gensec.materials.ec2_properties.en2sargin` (the formula keeps
  its one home), plus ``_cumulative_reference`` and two probes.  Both
  instruments were measured **blind** to this defect first: across 31
  ``FiberSolver`` builds inside the driver, over every distributed
  example that reaches it, the relative spread of the bulk tangent was
  **0.0** — every timeline path linearises the view through
  ``sls_view``.  An INERT from a blind instrument is silence, not
  proof.  The extension moved **0** of the 5095 + 411 shared keys;
* ``tools/element_class_reasons.py``, ``tools/element_class_baseline.txt``
  — two new partial sites with reasons, two reclassified ``--T`` to
  ``B-T`` because the driver now names the bulk.  The gate was proven
  able to fail on two deliberate corruptions before its green was read;
* ``tools/selfcheck_inventory.py`` — ``HEALTH_LIST``, F-B14;
* ``tests/test_phase25_increment_form.py`` — **new**, 22 fixtures.  Run
  on a pristine clone of ``77e958c`` before any source change: **10
  red, 12 green**, every red an ``AssertionError``, not one
  ``ImportError`` or ``AttributeError``.  Two independent references
  are written out in the file, and the fibre one is checked against the
  transformed-section one **before** it is used;
* ``docs/construction_timeline.rst`` — the note that said the exact
  form "is not implemented" is replaced by what was implemented, and by
  the measurement of why the obvious candidate is not it;
* ``.fingerprints/25_0*`` — PRE captured on a pristine clone with the
  extended instruments only, POST on the repaired tree, both
  reproducible byte-for-byte;
* ``handoff/`` — ledger, recap, and ``00_BOOTSTRAP.md``, which Phase 24
  had updated only in its §4.1 table and which still told a cold
  restart to expect 969 tests and a Phase-22 patcher.

What moved, and what did not
----------------------------
26 numeric keys of 5159, 5 datum of 418, 0 domain of 31.  Of the 26,
**25 are ``d1c.*``** and one is
``example_staged_injection.axial.fastpath_entries`` (3 -> 2), a path
counter and not a physical quantity: an integer has no decimals to hide
behind.  Every other value of that example is immobile, as it must be —
it runs on a linearised view.

The discriminator: **``d1c.linear.*``, 27 keys, 0 moved, largest
relative movement exactly 0.**  On a declaredly linear section not one
bit moves, so the movements elsewhere are the model and not an
implementation error.  ``d1c.divergence.nonlinear.max_rel_sigma`` goes
from **0.0212 to 0**: the driver now agrees with an independent
reference to machine precision.

Usage
-----
::

    python3 patchers/run_phase25_increment_form.py --selfcheck
    python3 patchers/run_phase25_increment_form.py --repair
"""'''


def _b64(raw: bytes) -> str:
    r"""``zlib`` + ``base64``, wrapped as a Python string literal."""
    blob = base64.b64encode(zlib.compress(raw, 9)).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 120))


def main() -> int:
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("from __future__ import annotations")
    i_pay = src.index('#: ``{relative path: zlib+base64 of the verified bytes}``.')
    # The tail starts at the first helper AFTER the two data blocks,
    # not at ``_verified``: ``_looks_like_root`` sits between them and
    # a slice that began lower dropped it, producing a patcher that
    # imported fine and raised ``NameError`` only when run.  Measured,
    # not guessed -- the first generated patcher did exactly that.
    i_ver = src.index("def _looks_like_root(root):")
    head = src[i_head:i_pay]
    tail = src[i_ver:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig, ends = [], [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}":\n{_b64(raw)},')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.sha256(raw).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1
        ends.append(f'    "{rel}": "{"CRLF" if crlf else "LF"}",')

    out = (
        HEADER + "\n\n"
        + head
        + "#: ``{relative path: zlib+base64 of the verified bytes}``.\n"
        + "PAYLOAD = {\n" + "\n".join(pay) + "\n}\n\n\n"
        + "#: ``{relative path: sha256 of the verified bytes}``.  The\n"
          "#: digest is what ``--selfcheck`` compares; the payload is\n"
          "#: what ``--repair`` writes.  Two records of one fact, so a\n"
          "#: transcription error in either is a mismatch and not a\n"
          "#: silent pass.\n"
        + "DIGESTS = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + "#: ``{relative path: 'CRLF' | 'LF'}``, measured on the bytes\n"
          "#: of each file at build time.  Reported by ``--selfcheck``\n"
          "#: so that a mismatch reads as an ending problem and not as\n"
          "#: a mysterious content problem.\n"
        + "LINE_ENDINGS = {\n" + "\n".join(ends) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
