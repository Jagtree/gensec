r"""
Build ``patchers/run_phase38_remove_block_and_annex.py``.

What is copied, and what is authored here
-----------------------------------------
The Phase-37 generator lifted *everything* from its predecessor except
the two data blocks, and argued the point: the apply/selfcheck machinery
had been falsified across six phases, and a rewrite would put a verified
thing back on trial for no gain.  That argument still holds for every
part of the machinery this phase does not change, and those parts are
still copied byte for byte:

* the import block and ``ROOT`` (taken from the Phase-37 patcher);
* ``_verify_payload``, unchanged.

It does **not** hold for ``selfcheck``, ``apply`` and ``main``.  Phase 38
adds a third declaration -- ``REMOVE`` -- and those three functions are
exactly the ones that must read it.  A copied ``selfcheck`` that ignored
``REMOVE`` would be the silent fallback this project rejects: a green
that does not cover the thing just declared.  They are therefore
authored below, in :data:`TAIL`, and the falsifier
``tests/run_phase38_patcher_falsification.py`` exercises the new branch
with two corruptions of its own.

Why ``REMOVE`` exists
---------------------
Measured in Phase 37 (``37_0`` section 10.5) and reproduced in Phase 38
before a line was written: applying the Phase-37 patcher to a copy of the
Phase-36 tree writes the 53 files, changes nothing on a second run, and
leaves a tree that differs from the delivered one by **one tracked
entry** -- ``tests/run_phase36_patcher_falsification.py``, which Phase 37
*replaced* and which a content-only payload cannot take away.

The consequence is not cosmetic.  That tree carries nineteen validators
instead of eighteen, and the nineteenth exits 1 with a false positive on
its own null control, because it is pinned to a payload seven of whose
files have since moved (F-B14, E37-4).  A permanently red validator
annuls the gate it belongs to, so **the tree rebuilt from the patcher
alone fails the check the delivered tree passes**.

Why not ``_patchkit._retired``
------------------------------
Measured before writing, because the phase brief asks for it, and the
answer is no on three counts:

1. ``retire(relpath, sentinel)`` declares a **string that must be absent
   inside a file**.  It never removes a path; nothing in ``_patchkit``
   deletes anything.
2. Its check does ``continue`` when the file is missing.  Absence is the
   normal state after a removal, and a mechanism that says nothing about
   it cannot be the home of a removal.
3. The transport patchers (Phases 33 to 37) do not import ``_patchkit``
   at all.  They are self-contained, and ``tools/selfcheck_inventory.py``
   classifies them on the ``PAYLOAD`` branch (``mechanism="bytes"``),
   which never reads ``_retired``.

``REMOVE`` therefore belongs beside ``PAYLOAD`` and ``DIGEST``, in the
transport patcher, and that is where it is put.

Run from the repository root::

    python3 tools/make_phase38_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase37_no_defaults_and_observation.py"
OUT = ROOT / "patchers" / "run_phase38_remove_block_and_annex.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    # --- the transport mechanism and its falsifier ------------------
    "tools/make_phase38_patcher.py",
    "tools/selfcheck_inventory.py",
    "tests/run_phase38_patcher_falsification.py",
    "tests/test_phase31_task_zero.py",
    # --- the output block stops swallowing unknown keys -------------
    "src/gensec/io_yaml.py",
    "tests/test_phase38_output_block_keys.py",
    "tests/test_server.py",
    "examples/example_tee.yaml",
    "examples/example_aci318.yaml",
    # --- _presets.py removed, consequences propagated ---------------
    "tools/observation_reasons.py",
    "tools/observation_baseline.txt",
    "tests/test_phase36_unknown_keys.py",
    # --- the handoff -------------------------------------------------
    "handoff/00_BOOTSTRAP.md",
    "handoff/38_0-GENSEC_LEDGER_38.md",
    "handoff/38_1-GENSEC_PHASE38_RECAP.md",
    "handoff/38_2-GENSEC_DEBT_CLASSIFICATION.md",
    # --- fingerprints, both ends ------------------------------------
    ".fingerprints/38_00_numeric_PRE.txt",
    ".fingerprints/38_00_datum_PRE.txt",
    ".fingerprints/38_00_domain_PRE.txt",
    ".fingerprints/38_01_numeric_POST.txt",
    ".fingerprints/38_01_datum_POST.txt",
    ".fingerprints/38_01_domain_POST.txt",
]

REMOVE = [
    "tests/run_phase37_patcher_falsification.py",
    "src/gensec/_presets.py",
]


HEADER = r'''r"""
GenSec Phase 38 - the payload learns to remove, and the national annex.

What this transports
--------------------

1. **A declared ``REMOVE`` block (37_0 section 10.5).**  The payload
   mechanism wrote files and took none away, so an operator rebuilding
   the tree from the patcher alone ended up with one tracked entry too
   many -- the previous phase's falsifier, which every phase replaces.
   That tree carries nineteen validators instead of eighteen and the
   nineteenth is red by construction, so the rebuilt tree failed the
   check the delivered tree passed.  ``REMOVE`` is an explicit list of
   paths, counted in the load, checked by ``--selfcheck``, applied by
   ``--apply``, and idempotent: a path already absent is the normal
   state on the second run and is reported as such, never in silence.

Reading the counts
------------------
``--selfcheck`` reports **load entries**, which is the number of
contents transported plus the number of removals declared.  The two
sub-counts are printed separately because they are different facts:
a content is verified by comparing bytes, a removal by asking whether a
path is there.
"""
'''


#: Authored here, not copied: these three functions are the ones that
#: read :data:`REMOVE`, and a copy would ignore it.  ``_verify_payload``
#: above them is copied unchanged from the Phase-37 patcher.
TAIL = r'''def _removal_state() -> Dict[str, bool]:
    """
    Report, for each declared removal, whether the path is still there.

    Returns
    -------
    dict
        ``{relpath: present}``.  ``True`` means the path exists on disk
        and this phase declares that it should not.
    """
    return {rel: os.path.exists(os.path.join(ROOT, rel))
            for rel in REMOVE}


def selfcheck() -> int:
    """
    Compare every declared file against its payload, and every declared
    removal against the tree.

    The load has two halves and they are verified by different
    questions.  A transported content is right when its bytes equal the
    payload; a declared removal is right when the path is **absent**.
    Both are reported, and the totals are printed apart, because a
    single number covering both would let one half hide inside the
    other.

    Returns
    -------
    int
        ``0`` when every transported file equals its payload exactly
        **and** no declared removal is still on disk, ``1`` otherwise.
        Nothing is written.
    """
    _verify_payload()
    bad: List[str] = []
    absent: List[str] = []
    for rel in sorted(PAYLOAD):
        dst = os.path.join(ROOT, rel)
        if not os.path.exists(dst):
            absent.append(rel)
            print(f"  BYTES  {rel}: absent")
            continue
        with open(dst, "rb") as fh:
            got = fh.read()
        if got == PAYLOAD[rel]:
            print(f"  ok     {rel}: {len(got)} bytes identical")
        else:
            bad.append(rel)
            kind = ("line endings only"
                    if got.replace(b"\r\n", b"\n")
                    == PAYLOAD[rel].replace(b"\r\n", b"\n")
                    else "content")
            print(f"  BYTES  {rel}: {kind} differ "
                  f"({len(got)} on disk, {len(PAYLOAD[rel])} declared)")
    still: List[str] = []
    for rel in sorted(REMOVE):
        if _removal_state()[rel]:
            still.append(rel)
            print(f"  REMOVE {rel}: still present, and this phase "
                  f"declares it removed")
        else:
            print(f"  ok     {rel}: absent as declared")
    n_pay, n_rm = len(PAYLOAD), len(REMOVE)
    print(f"\n{n_pay + n_rm} load entr(ies): "
          f"{n_pay - len(bad) - len(absent)} of {n_pay} byte-identical, "
          f"{len(bad)} differ, {len(absent)} absent; "
          f"{n_rm - len(still)} of {n_rm} removed as declared, "
          f"{len(still)} still present.")
    return 0 if not bad and not absent and not still else 1


def apply(dry_run: bool = False) -> int:
    """
    Write every payload and take away every declared removal.

    Contents are staged as ``<n>.p38tmp`` beside their targets and
    committed with :func:`os.replace` only once all have been staged
    without error.  Removals happen **after** that commit: a removal
    cannot be staged and rolled back the way a write can, so it is done
    when nothing else can still fail.

    A declared removal whose path is already gone is **not an error**.
    It is the ordinary state of the second ``--apply``, and of any tree
    that never carried the file, and it is printed as such -- idempotent
    and said out loud, because an idempotent step that reports nothing
    is indistinguishable from a step that did not run.

    Parameters
    ----------
    dry_run : bool, optional
        Report what would be done and touch nothing.

    Returns
    -------
    int
    """
    _verify_payload()
    staged: List[tuple] = []
    changed = 0
    try:
        for rel in sorted(PAYLOAD):
            dst = os.path.join(ROOT, rel)
            want = PAYLOAD[rel]
            cur = None
            if os.path.exists(dst):
                with open(dst, "rb") as fh:
                    cur = fh.read()
            if cur == want:
                print(f"  ok     {rel}: already current")
                continue
            changed += 1
            if dry_run:
                print(f"  would  {rel}: "
                      f"{'create' if cur is None else 'rewrite'}")
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + ".p38tmp"
            with open(tmp, "wb") as fh:
                fh.write(want)
            staged.append((tmp, dst))
    except Exception:
        for tmp, _ in staged:
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise
    for tmp, dst in staged:
        os.replace(tmp, dst)
        print(f"  wrote  {os.path.relpath(dst, ROOT)}")

    removed = 0
    for rel in sorted(REMOVE):
        if not _removal_state()[rel]:
            print(f"  ok     {rel}: already absent")
            continue
        removed += 1
        if dry_run:
            print(f"  would  {rel}: remove")
            continue
        os.remove(os.path.join(ROOT, rel))
        print(f"  removed {rel}")

    print(f"\n{changed} file(s) "
          f"{'would change' if dry_run else 'changed'}, "
          f"{len(PAYLOAD) - changed} already current; "
          f"{removed} path(s) "
          f"{'would be removed' if dry_run else 'removed'}, "
          f"{len(REMOVE) - removed} already absent.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """
    Command-line entry point.

    Parameters
    ----------
    argv : list of str, optional

    Returns
    -------
    int
        Process exit status.
    """
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--selfcheck" in argv:
        return selfcheck()
    if "--dry-run" in argv:
        return apply(dry_run=True)
    if "--apply" in argv:
        return apply(dry_run=False)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent, if a
        payload file mixes line endings, if a declared removal is also
        a transported content, or if a declared removal is still in the
        tree at build time.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_verify = src.index("def _verify_payload() -> None:")
    i_selfcheck = src.index("def selfcheck() -> int:")
    head = src[i_head:i_pay]
    verify = src[i_verify:i_selfcheck]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    # A path cannot be both transported and removed.  The two blocks
    # would contradict each other, and which one won would depend on
    # the order of two loops -- exactly the kind of answer this project
    # does not accept from a mechanism.
    both = sorted(set(FILES) & set(REMOVE))
    if both:
        print("ABORT: declared as both content and removal:")
        for f in both:
            print("   ", f)
        return 1

    # A removal still present at build time means the phase declared it
    # and did not do it.  The patcher would then transport a removal
    # the delivered tree does not have, and the tree rebuilt from the
    # patcher would differ from the tree delivered -- which is the whole
    # defect this block exists to close.
    lingering = [f for f in REMOVE if (ROOT / f).exists()]
    if lingering:
        print("ABORT: declared removed but still in the tree:")
        for f in lingering:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    rm = "\n".join(f'    "{rel}",' for rel in REMOVE)

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n"
        + "#: Every path this phase removes, explicitly.  There is no\n"
          "#: digest for a removal: the fact declared is an absence, and\n"
          "#: an absence has no bytes to hash.  What makes the list safe\n"
          "#: is that it is enumerated, not derived -- an operator can\n"
          "#: read, before running anything, exactly what will go.\n"
        + "REMOVE: List[str] = [\n" + rm + "\n]\n\n\n"
        + verify
        + TAIL
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s) "
          f"transported, {len(REMOVE)} removed, "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
