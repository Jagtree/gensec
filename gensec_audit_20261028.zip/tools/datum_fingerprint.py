r"""
Datum fingerprint — the instrument that measures P3.

Why this exists
---------------
``tools/numeric_fingerprint.py`` photographs the *sectional* quantities of
every example: mesh moments, domain vertices, equilibrium planes, ideal
properties.  Phase 12 §8 measured that **none of its probes enter any of
the three datum sites**.  So a fingerprint that reads ``INERT`` after P3
would be silence, not proof — it would say "the numbers I happen to look
at did not move", which is true today and would stay true whether P3
worked or not.

This tool looks where P3 acts.  For every example carrying a
``construction_history`` it records, on the **same key schema** as the
per-tendon ledger:

- ``auto_datum``   — the ULS casting datum written into ``bulk_planes``
- ``service_datum``— its service twin (the F4/F5 divergence lives here)
- ``grout_eps_init``— the reconciled locked-in strain per tendon
- ``sigma_p0`` / ``sigma_p`` — per stressing sub-step, per tendon
- the demand accumulated at each sub-step, and the state of every tendon

The output format is ``key = value``, byte-compatible with
``numeric_fingerprint``, so its ``compare`` command works on these files
unchanged.  There is no second comparison implementation.

Usage
-----
::

    python tools/datum_fingerprint.py capture datum_before.txt
    # ... land P3 ...
    python tools/datum_fingerprint.py capture datum_after.txt
    python tools/datum_fingerprint.py compare datum_before.txt datum_after.txt

The gate condition for P3 is the opposite of the one for a refactor:
these values **must move**.  ``INERT`` here means P3 did not reach the
datum sites.

Notes
-----
Values are physical quantities, never hashes.  A hash answers "did
anything change"; an engineer needs "what changed, by how much, where".
"""

from __future__ import annotations

import os
import sys
import traceback
from typing import Dict, List

# ----------------------------------------------------------------------
#  Reuse numeric_fingerprint's plumbing rather than cloning it.
# ----------------------------------------------------------------------
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from numeric_fingerprint import (         # noqa: E402
    ROOT, Recorder, compare, _fmt)        # noqa: F401

from gensec.io_yaml import load_yaml                          # noqa: E402
from gensec.solver.timeline import ConstructionTimeline       # noqa: E402


__all__ = ["capture", "compare", "iter_history_examples",
           "probe_example", "probe_retrofit_datum", "main"]


# ======================================================================
#  Example discovery
# ======================================================================

def iter_history_examples() -> List[str]:
    r"""
    Every ``examples/*.yaml`` that declares a ``construction_history``.

    The filter is textual and deliberately cheap: a YAML without the key
    cannot exercise a datum site, and parsing all of them to find out
    would make the tool slow enough that nobody runs it.

    Returns
    -------
    list of str
        Absolute paths, sorted.
    """
    ex = os.path.join(ROOT, "examples")
    out = []
    for name in sorted(os.listdir(ex)):
        if not name.endswith((".yaml", ".yml")):
            continue
        path = os.path.join(ex, name)
        try:
            with open(path, encoding="utf-8") as fh:
                if "construction_history:" in fh.read():
                    out.append(path)
        except OSError:                                  # pragma: no cover
            continue
    return out


def _read_back_sigma(res, tendon):
    r"""
    The stress a grouted tendon reads back, or ``None``.

    Read from the first losses record that carries a ``sigma_p0`` for
    *tendon*: the earliest instant at which the bonded tendon is
    evaluated in the service view, which is where a datum
    inconsistency shows up undiluted by later losses.

    Parameters
    ----------
    res : TimelineResolution
    tendon : str

    Returns
    -------
    float or None
        ``None`` when the model computes no losses -- there is then no
        read-back instant, which is an absence with a cause and not a
        measurement of zero.
    """
    for _key in sorted(getattr(res, "losses_trace", {}) or {}):
        for record in res.losses_trace[_key]:
            sigma = getattr(record, "sigma_p0", None)
            if sigma and tendon in sigma:
                return float(sigma[tendon])
    return None


def _demand_db(doc: dict) -> Dict[str, dict]:
    r"""
    Normalise the ``demands`` block to the mapping ``resolve`` wants.

    The YAML carries a *list* of records; the timeline wants
    ``{name: {"N", "Mx", "My"}}``.

    Parameters
    ----------
    doc : dict
        A loaded example document.

    Returns
    -------
    dict
    """
    dem = doc.get("demands") or []
    if isinstance(dem, dict):
        return dem
    return {d["name"]: {"N": float(d.get("N", 0.0)),
                        "Mx": float(d.get("Mx", 0.0)),
                        "My": float(d.get("My", 0.0))}
            for d in dem}


# ======================================================================
#  The probe
# ======================================================================

def probe_example(rec: Recorder, path: str) -> None:
    r"""
    Record every datum-site quantity of one example.

    Parameters
    ----------
    rec : Recorder
    path : str
        Absolute path of the example YAML.

    Notes
    -----
    A failure is recorded as a value (``!ExceptionType: message``) rather
    than raised: an example that cannot resolve is itself a measurement,
    and one broken example must not blind the tool to the other
    seventeen.
    """
    tag = os.path.splitext(os.path.basename(path))[0]
    try:
        doc = load_yaml(path)
    except Exception as exc:                             # pragma: no cover
        rec.fail(f"{tag}.load", exc)
        return

    block = doc.get("construction_history")
    if not block:
        return

    try:
        # This instrument has to photograph two trees: the one before
        # P3 and the one after.  ``from_document`` exists only on the
        # second, so the legacy construction is kept -- and *recorded*,
        # on its own key.  A fallback that leaves no trace is the
        # silent-path defect this project keeps finding; one that
        # writes down which branch it took is a measurement.
        if hasattr(ConstructionTimeline, "from_document"):
            rec.put(f"{tag}.tool.construction", "from_document")
            tl = ConstructionTimeline.from_document(doc)
        else:
            rec.put(f"{tag}.tool.construction", "from_block (pre-P3 tree)")
            tl = ConstructionTimeline.from_block(
                block, losses_models=doc.get("losses_models"))
        res = tl.resolve(doc["section"], _demand_db(doc))
    except Exception as exc:
        rec.fail(f"{tag}.resolve", exc)
        return

    # -- site 1: the casting datum.  One, now. -------------------------
    #
    # D2 (12_11 §5).  Before P3 this block recorded three families of
    # key: ``.auto.*``, ``.service.*`` and their ``.residue.*``.  The
    # second datum is gone -- one physical statement, one object -- so
    # ``.service.*`` and ``.residue.*`` are absent by construction and
    # not by omission.  A key that disappears for a declared cause is a
    # different event from one that disappears because the tool stopped
    # looking, and the comparison must be able to tell them apart: the
    # cause is recorded here, on its own key, so a diff carries it.
    for zi in sorted(res.datums):
        for name, v in zip(("eps0", "chi_x", "chi_y"), res.datums[zi]):
            rec.put(f"{tag}.datum.zone[{zi:02d}].auto.{name}", v)
    if hasattr(res, "service_datums"):
        for zi in sorted(getattr(res, "service_datums", {}) or {}):
            for name, v in zip(("eps0", "chi_x", "chi_y"),
                               res.service_datums[zi]):
                rec.put(f"{tag}.datum.zone[{zi:02d}].service.{name}", v)
            if zi in res.datums:
                for name, a, b in zip(("eps0", "chi_x", "chi_y"),
                                      res.datums[zi],
                                      res.service_datums[zi]):
                    rec.put(f"{tag}.datum.zone[{zi:02d}].residue.{name}",
                            float(a) - float(b))
    else:
        rec.put(f"{tag}.datum.second_object", "ABSENT: unified at P3")

    # -- the quantity that replaces the residue ------------------------
    #
    # The old ``.residue.*`` measured the *disagreement between two
    # datums*, which is a quantity that only exists while the defect
    # does.  What survives P3 is the claim itself: a tendon reads back,
    # in the view the rest of the analysis uses, exactly the stress it
    # was jacked to.  That number is measurable on every tree, before
    # and after, which is what makes it a gate quantity rather than a
    # symptom.
    for t in sorted(res.stress_sigma):
        jack = float(res.stress_sigma[t])
        read = _read_back_sigma(res, t)
        if read is None or not jack:
            continue
        rec.put(f"{tag}.zero_stress_residue.tendon[{t}].abs", read - jack)
        rec.put(f"{tag}.zero_stress_residue.tendon[{t}].rel",
                (read - jack) / jack)

    # -- site 3: the reconciled grouting strain ------------------------
    for t in sorted(res.grout_eps_init):
        rec.put(f"{tag}.grout_eps_init.tendon[{t}]", res.grout_eps_init[t])
    for t in sorted(res.stress_sigma):
        rec.put(f"{tag}.sigma_p0.tendon[{t}]", res.stress_sigma[t])
    for t in sorted(res.pre_post):
        rec.put(f"{tag}.pre_post.tendon[{t}]", res.pre_post[t])

    # -- site 4: the time-dependent emission, per interval -------------
    # Added in Phase 15.  Until then this instrument photographed the
    # datums, the grouting and the stressing ledger, and NOTHING that a
    # creep interval emits: the Boltzmann repair of section B moved the
    # eigenstrain plane of every interval and the tendon stress at the
    # end of the walk, and both fingerprints read INERT.  A fingerprint
    # that is inert across a change it structurally cannot observe is
    # silence, not evidence (the same reason Phase 14 added the
    # moment-curvature probe to ``numeric_fingerprint``).
    #
    # Keyed by the *stage index* the resolution uses, not by the event
    # index: it is the key the emission is stored under, and inventing a
    # second numbering here would be a second home for one fact.
    for step in sorted(getattr(res, "losses_ops", {}) or {}):
        ops = res.losses_ops[step] or {}
        planes = ops.get("bulk_plane_delta") or {}
        for zi in sorted(planes, key=int):
            plane = planes[zi]
            for name, value in zip(("eps0", "chi_x", "chi_y"), plane):
                rec.put(f"{tag}.losses.step[{int(step):03d}]."
                        f"zone[{int(zi):02d}].eigenstrain.{name}", value)
        for ui in sorted(ops.get("eps_override") or {}, key=int):
            rec.put(f"{tag}.losses.step[{int(step):03d}]."
                    f"union[{int(ui):02d}].eps_init",
                    ops["eps_override"][ui])

    for step in sorted(getattr(res, "losses_trace", {}) or {}):
        for sub, entry in enumerate(res.losses_trace[step] or []):
            head = f"{tag}.losses.step[{int(step):03d}][{sub:02d}]"
            for t in sorted(entry.sigma_p):
                rec.put(f"{head}.tendon[{t}].sigma_p0", entry.sigma_p0[t])
                rec.put(f"{head}.tendon[{t}].sigma_p", entry.sigma_p[t])
                rec.put(f"{head}.tendon[{t}].d_sigma_p", entry.d_sigma_p[t])
                rec.put(f"{head}.tendon[{t}].d_sigma_pr",
                        entry.d_sigma_pr[t])
            for zi in sorted(entry.phi):
                rec.put(f"{head}.zone[{int(zi):02d}].phi", entry.phi[zi])
                rec.put(f"{head}.zone[{int(zi):02d}].chi", entry.chi[zi])

    # -- the ledger, verbatim, on its own keys -------------------------
    led = getattr(res, "ledger", None)
    if led is not None:
        for key, value in led.items():
            rec.put(f"{tag}.{key}", value)

    # -- the emission ledgers, one per (combination, point) ------------
    section, db = doc["section"], _demand_db(doc)
    for combo in (doc.get("combinations") or []):
        try:
            tl.compile_combination(combo, res, section, db)
        except Exception as exc:
            rec.fail(f"{tag}.compile[{combo.get('name')}]", exc)
    for (cname, point), eled in sorted(
            getattr(res, "emission_ledgers", {}).items(),
            key=lambda kv: (str(kv[0][0]), str(kv[0][1]))):
        for key, value in eled.items():
            rec.put(f"{tag}.emit.{key}", value)


# ======================================================================
#  Capture
# ======================================================================

def probe_retrofit_datum(rec: Recorder) -> None:
    r"""
    The **datum** of a declared retrofit, synthetically.

    Synthetic and tied to no example, for the same reason as
    :func:`numeric_fingerprint._retrofit_declaration`: no distributed
    model can carry a section already in service, so this instrument
    was blind to D1b.  Measured at the opening of Phase 24 on the
    Phase-23 tree: of 402 recorded datum values, **zero** carried
    ``preexisting``, ``already_bonded`` or a declared bulk plane.

    A datum is exactly what the retrofit adds, and it arrives from two
    directions at once:

    * the **concrete** of an existing member is not at zero strain when
      the new jack is pulled.  Its declared plane
      :math:`(\varepsilon_0, \chi_x, \chi_y)` is an imposed-strain
      offset on every fibre — the same mechanism a staged zone's
      casting datum uses (``bulk_planes``), reached from a declaration
      instead of from a solve;
    * the **pre-existing tendon** carries a declared effective stress
      :math:`\sigma_{pe}` that no GenSec computation produced, and the
      reconciliation
      :math:`\varepsilon_{\text{init}} = \varepsilon_{pe,\text{eff}}
      - \varepsilon_{\text{sec,grout}}` has to land on it as it lands
      on a tendon GenSec did jack.

    Every key below exists on both trees: ``'refused:<reason>'`` where
    the retrofit is not modelled, a number where it is.  The class is
    fetched with :func:`getattr` and never imported by name, so a tree
    without it reports ``'absent'`` instead of failing to import.

    Parameters
    ----------
    rec : Recorder

    Notes
    -----
    Geometry as in ``22_0 §1.1``: 400 x 1200, three tendons
    :math:`A_p = 1500` at :math:`y = 150/200/250`,
    :math:`E_c = 35\,220.462`, :math:`E_p = 195\,000`.  Tendon 0 is the
    existing one, declared at :math:`\sigma_{pe} = 1100` MPa in
    concrete carrying :math:`\varepsilon_0 = -3\times 10^{-4}`,
    :math:`\chi_x = 1.5\times 10^{-7}`.
    """
    from gensec.geometry.fiber import Tendon
    from gensec.geometry.section import RectSection
    import gensec.solver.posttension as _pt
    from numeric_fingerprint import _retrofit_laws

    B, H, N_Y = 400.0, 1200.0, 240
    EC, EP, AP, SP0 = 35220.462, 195000.0, 1500.0, 1300.0
    Y_TENDONS = (150.0, 200.0, 250.0)
    SIGMA_PE, EPS0_EX, CHIX_EX = 1100.0, -3.0e-4, 1.5e-7
    XREF_D, YREF_D, AGE_C, AGE_P = 0.0, 0.0, 14600.0, 14200.0

    bulk_law, strand_law = _retrofit_laws(EC, EP)

    def _section():
        tendons = [Tendon(y=float(yt), x=B / 2.0, material=strand_law,
                          Ap=AP, eps_pe=0.0) for yt in Y_TENDONS]
        return RectSection(B=B, H=H, bulk_material=bulk_law, rebars=[],
                           n_fibers_y=N_Y, tendons=tendons)

    keys = ["retrofit.datum.eps0_declared",
            "retrofit.datum.chi_x_declared",
            "retrofit.datum.sigma_pe_declared[00]",
            "retrofit.datum.eps_ref_grout[00]",
            "retrofit.datum.eps_ref_grout[01]",
            "retrofit.datum.eps_pe_eff[00]",
            "retrofit.datum.eps_init_grout[01]",
            "retrofit.datum.readback_sigma[01]"]

    def _refuse(token: str) -> None:
        for key in keys:
            rec.put(key, token)
        rec.put("retrofit.datum.outcome", token)

    decl_cls = getattr(_pt, "PreexistingState", None)
    if decl_cls is None:
        _refuse("refused:absent")
        return

    def _named_reason(exc) -> str:
        return str(getattr(exc, "reason", None)
                   or f"unnamed:{type(exc).__name__}")

    nan = float("nan")
    sec = _section()
    try:
        state = decl_cls(sigma_pe={0: SIGMA_PE}, eps0=EPS0_EX,
                         chi_x=CHIX_EX, chi_y=0.0, x_ref=XREF_D,
                         y_ref=YREF_D, concrete_age_days=AGE_C,
                         tendon_age_days={0: AGE_P})
        res = _pt.solve_posttension_sequence(
            sec, sigma_p0=[nan, SP0, SP0], Ep=EP, order=[1, 2],
            pending=[], already_bonded=state)
    except BaseException as exc:            # noqa: BLE001 — outcome is data
        _refuse(f"refused:{_named_reason(exc)}")
        return

    rec.put("retrofit.datum.outcome", "ok")
    rec.put("retrofit.datum.eps0_declared", float(state.eps0))
    rec.put("retrofit.datum.chi_x_declared", float(state.chi_x))
    rec.put("retrofit.datum.sigma_pe_declared[00]",
            float(state.sigma_pe[0]))
    rec.put("retrofit.datum.eps_ref_grout[00]",
            float(res.eps_ref_grout[0]))
    rec.put("retrofit.datum.eps_ref_grout[01]",
            float(res.eps_ref_grout[1]))
    rec.put("retrofit.datum.eps_pe_eff[00]", float(res.eps_pe_eff[0]))

    # Grout the newly stressed tendon 1 and read the reconciled datum
    # back: the existing tendon must not be re-grouted, and the new one
    # must read back exactly its own post-loss effective stress.
    try:
        gres = _pt.grout(sec, res, indices=[1])
    except BaseException as exc:            # noqa: BLE001 — outcome is data
        rec.put("retrofit.datum.eps_init_grout[01]",
                f"refused:{_named_reason(exc)}")
        rec.put("retrofit.datum.readback_sigma[01]",
                f"refused:{_named_reason(exc)}")
        return
    rec_row = next((r for r in gres.report["reconciliation"]
                    if int(r["tendon"]) == 1), None)
    if rec_row is None:
        rec.put("retrofit.datum.eps_init_grout[01]", "absent:record")
        rec.put("retrofit.datum.readback_sigma[01]", "absent:record")
        return
    rec.put("retrofit.datum.eps_init_grout[01]",
            float(rec_row["eps_init"]))
    rec.put("retrofit.datum.readback_sigma[01]",
            float(EP * (float(rec_row["eps_init"])
                        + float(rec_row["eps_ref_grout"]))))


def probe_d1c_datum(rec: Recorder) -> None:
    r"""
    The **datum** of the sequence on a law whose tangent varies.

    :func:`probe_retrofit_datum` above measures the same member on a
    constant-modulus law, and is therefore blind to D1c by
    construction: on a linear section the incremental and the
    cumulative increment forms are the same algebra.  Measured at the
    opening of Phase 25 on the Phase-24 tree: across 31 ``FiberSolver``
    builds inside the driver, over every distributed example that
    reaches it, the relative spread of the bulk tangent was **0.0**.

    So this probe repeats the battery on the EN 1992-1-1 §3.1.5 service
    law — one home for one fact, so the law itself is
    :class:`numeric_fingerprint._EC2ServiceLaw`, which adapts
    :func:`~gensec.materials.ec2_properties.en2sargin` and is not re-declared
    here.  The two probes together are the discriminator: the linear
    one must not move by a bit, the nonlinear one must.

    Every key exists on both trees, ``'refused:<reason>'`` where the
    call does not complete.

    Parameters
    ----------
    rec : Recorder

    Notes
    -----
    Geometry as in ``22_0 §1.1``.  Concrete C35/45 at
    :math:`f_{cm} = 43`, :math:`E_{cm} = 34\,077`,
    :math:`\varepsilon_{c1} = -2.2\times 10^{-3}`.
    """
    from gensec.geometry.fiber import Tendon
    from gensec.geometry.section import RectSection
    import gensec.solver.posttension as _pt
    from numeric_fingerprint import _EC2ServiceLaw, _retrofit_laws

    B, H, N_Y = 400.0, 1200.0, 240
    EP, AP, SP0 = 195000.0, 1500.0, 1300.0
    Y_TENDONS = (150.0, 200.0, 250.0)
    FCK = 35.0                          # C35/45

    bulk_law = _EC2ServiceLaw(FCK)
    _, strand_law = _retrofit_laws(bulk_law.Ecm, EP)

    def _section():
        tendons = [Tendon(y=float(yt), x=B / 2.0, material=strand_law,
                          Ap=AP, eps_pe=0.0) for yt in Y_TENDONS]
        return RectSection(B=B, H=H, bulk_material=bulk_law, rebars=[],
                           n_fibers_y=N_Y, tendons=tendons)

    keys = ["d1c.datum.eps_ref_grout[00]",
            "d1c.datum.eps_ref_grout[01]",
            "d1c.datum.eps_ref_grout[02]",
            "d1c.datum.eps_pe_eff[00]",
            "d1c.datum.eps_init_grout[00]",
            "d1c.datum.readback_sigma[00]"]

    def _named_reason(exc) -> str:
        return str(getattr(exc, "reason", None)
                   or f"unnamed:{type(exc).__name__}")

    def _refuse(token: str) -> None:
        for key in keys:
            rec.put(key, token)
        rec.put("d1c.datum.outcome", token)

    sec = _section()
    try:
        res = _pt.solve_posttension_sequence(
            sec, sigma_p0=[SP0] * 3, Ep=EP, order=[0, 1, 2])
    except BaseException as exc:            # noqa: BLE001 — outcome is data
        _refuse(f"refused:{_named_reason(exc)}")
        return

    rec.put("d1c.datum.outcome", "ok")
    for k in range(3):
        rec.put(f"d1c.datum.eps_ref_grout[{k:02d}]",
                float(res.eps_ref_grout[k]))
    rec.put("d1c.datum.eps_pe_eff[00]", float(res.eps_pe_eff[0]))

    try:
        gres = _pt.grout(sec, res, indices=[0])
    except BaseException as exc:            # noqa: BLE001 — outcome is data
        rec.put("d1c.datum.eps_init_grout[00]",
                f"refused:{_named_reason(exc)}")
        rec.put("d1c.datum.readback_sigma[00]",
                f"refused:{_named_reason(exc)}")
        return
    row = next((r for r in gres.report["reconciliation"]
                if int(r["tendon"]) == 0), None)
    if row is None:
        rec.put("d1c.datum.eps_init_grout[00]", "absent:record")
        rec.put("d1c.datum.readback_sigma[00]", "absent:record")
        return
    rec.put("d1c.datum.eps_init_grout[00]", float(row["eps_init"]))
    rec.put("d1c.datum.readback_sigma[00]",
            float(EP * (float(row["eps_init"])
                        + float(row["eps_ref_grout"]))))


def capture(out_path: str) -> int:
    r"""
    Walk every history-bearing example and write the fingerprint.

    Parameters
    ----------
    out_path : str
        Destination file.

    Returns
    -------
    int
        Process exit status (``0``).
    """
    rec = Recorder()
    paths = iter_history_examples()
    print(f"datum fingerprint: {len(paths)} example(s) with a "
          f"construction_history")
    for p in paths:
        name = os.path.basename(p)
        try:
            probe_example(rec, p)
            print(f"  ok    {name}")
        except Exception as exc:                          # pragma: no cover
            rec.fail(f"{os.path.splitext(name)[0]}.probe", exc)
            print(f"  FAIL  {name}: {type(exc).__name__}: {exc}")
            traceback.print_exc(limit=3)
    # Synthetic, example-free: the datum a declared retrofit brings.
    try:
        probe_retrofit_datum(rec)
        probe_d1c_datum(rec)
        print("  ok    <synthetic retrofit>")
    except Exception as exc:                              # pragma: no cover
        rec.fail("retrofit.datum.probe", exc)
        print(f"  FAIL  <synthetic retrofit>: {type(exc).__name__}: {exc}")
    rec.dump(out_path)
    print(f"\nwrote {len(rec.rows)} values to {out_path}")
    return 0


def main(argv: List[str]) -> int:
    r"""
    Command-line entry point.

    Parameters
    ----------
    argv : list of str

    Returns
    -------
    int
    """
    if len(argv) >= 2 and argv[0] == "capture":
        return capture(argv[1])
    if len(argv) >= 3 and argv[0] == "compare":
        rtol, top = 1e-12, 25
        if "--rtol" in argv:
            rtol = float(argv[argv.index("--rtol") + 1])
        if "--top" in argv:
            top = int(argv[argv.index("--top") + 1])
        return compare(argv[1], argv[2], rtol, top)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
