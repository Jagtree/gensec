# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
Completion markers: distinguishing a finished file from an in-flight one.

The failure this exists to prevent
----------------------------------
Phase 30 opened by verifying the provenance of the incoming archive:
``tar`` listing, ``git clone`` of the bundle, a recursive ``diff``
against the clone, and a file count.  All four agreed.  Nine hours of
work later, ``tools/numeric_fingerprint.py`` in the working tree no
longer matched the bundle, and it contained two probes whose docstrings
quoted measurements produced during that same session.  The session had
no record of writing them.

The material was in fact prior work from this same session, left behind
when a turn was cut short before its account of itself was written.  The
code was sound; what was missing was any way to tell **finished work
from work interrupted mid-write**.  That question consumed a full
exchange and nearly cost a rewrite of three hundred lines that already
existed.  This module answers it mechanically so it is never asked
again.

What a marker does and does not prove
-------------------------------------
A completion marker is a single line appended as the **last line** of a
file:

.. code-block:: text

    # GENSEC-COMPLETE phase=30 utc=2026-09-03T17:12:04Z sha256=<64 hex> body_lines=3774

It proves exactly two things, and they are the two things that matter
after an interrupted write:

**The writer reached the end of the file.**  The marker is the last
line, so it cannot exist unless everything before it was written.  A
marker at the top of a file would survive truncation and would then
assert completeness about a file that is not complete; that is why the
position is not a matter of taste.  It is the whole mechanism.

**Nothing has touched the file since.**  The digest covers every byte
before the marker.  A later edit that does not re-stamp the file makes
the digest disagree with the body, and the gate fails.

It proves **nothing about authorship**.  A string can be typed by
anyone and anything; a marker that claimed "written by X" would be an
assertion no measurement backs, which is the species of defect this
project spends its phases removing.  The marker says *complete and
unchanged since*, and stops there.  Authorship is what the git history
is for.

The rules
---------
1. **The marker is the last line of the file.  Never anywhere else.**
   Not the header, not next to the licence block.  Its position is its
   proof.

2. **A marker is written when the file is finished, not when writing
   stops.**  Finished means: the file does what its docstring says, and
   whatever verifies it — its tests, its gate, its selfcheck — has been
   run and has passed.  Stamping a file to tidy the tree inverts the
   tool into a lie that is harder to detect than the silence it
   replaced.

3. **A digest mismatch voids the marker, not the file.**  It means the
   body changed after the stamp.  The remedy is to re-verify the file
   and re-stamp it, never to edit the marker to agree with the body.
   Editing the marker forges the one fact the marker exists to carry.

4. **The absence of a marker means "in flight", not "broken".**  An
   unmarked file is work whose completion was never asserted.  It is
   measured and audited, never deleted — the standing rule that
   unrecognised code in the tree is prior work, with the reason now
   made explicit rather than left to judgement.

5. **The marker carries the phase that stamped it.**  A file marked
   ``phase=27`` in a Phase 30 tree is complete, not stale: phases do not
   invalidate each other's work.  The field is provenance, not an expiry
   date.

6. **The marker respects the file's own line ending.**  GenSec files
   are CRLF per-file; a stamp that normalises line endings would make
   every patcher's byte comparison fail for a reason that has nothing to
   do with content.

7. **Generated and vendored files are exempt**, and the exemption is
   declared in :data:`EXEMPT`, not left implicit.  A file nobody wrote
   by hand cannot assert that a writer reached its end.

Why this is worth a tool rather than a habit
--------------------------------------------
A convention that is not checked decays into a convention that is
believed.  ``--gate`` reads every marker and recomputes every digest, so
the claim "the tree is finished" is a measurement rather than a memory.
``--falsify`` proves the gate can fail: it builds corrupted copies —
a body edited after stamping, a marker moved off the last line, a
truncated tail, a forged digest — and requires the gate to reject each
one, plus a null control that must pass untouched.  A gate never seen
to fail is not evidence.

Usage
-----
.. code-block:: shell

    python3 tools/completion_marker.py --gate
    python3 tools/completion_marker.py --stamp src/gensec/solver/sls.py
    python3 tools/completion_marker.py --status
    python3 tools/completion_marker.py --falsify
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple

MARKER_TOKEN = "GENSEC-COMPLETE"

#: Comment prefix per extension.  A file type with no prefix here cannot
#: carry a marker, because there is no way to write one that the file's
#: own parser will ignore.
COMMENT_PREFIX: Dict[str, str] = {
    ".py": "#",
    ".yaml": "#",
    ".yml": "#",
    ".toml": "#",
    ".txt": "#",
    ".cfg": "#",
}

#: Paths, relative to the repository root, that never carry a marker.
#: Generated or vendored content: no writer reached their end by hand.
EXEMPT: Tuple[str, ...] = (
    "tree_output.txt",
    "tools/material_assumption_baseline.txt",
)

_MARKER_RE = re.compile(
    r"^(?P<prefix>\S+)\s+" + MARKER_TOKEN +
    r"\s+phase=(?P<phase>\d+)"
    r"\s+utc=(?P<utc>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)"
    r"\s+sha256=(?P<sha>[0-9a-f]{64})"
    r"\s+body_lines=(?P<lines>\d+)\s*$"
)


# ======================================================================
# Repository root
# ======================================================================

def _repo_root() -> str:
    """
    Absolute path of the repository root.

    Returns
    -------
    str
        The directory containing ``tools/`` and ``src/``.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


# ======================================================================
# Reading
# ======================================================================

def _read_bytes(path: str) -> bytes:
    """
    Read a file as raw bytes.

    Bytes rather than text: the line ending is part of what must be
    preserved, and a text-mode read would hide it.

    Parameters
    ----------
    path : str
        Path to the file.

    Returns
    -------
    bytes
        The file's exact content.
    """
    with open(path, "rb") as fh:
        return fh.read()


def split_marker(raw: bytes) -> Tuple[bytes, Optional[str]]:
    """
    Split a file's bytes into body and marker line.

    The marker, if present, is the final line.  A file whose final line
    is not a marker has no marker: a marker found anywhere else is not
    a marker, by rule 1.

    Parameters
    ----------
    raw : bytes
        The file's exact content.

    Returns
    -------
    body : bytes
        Everything before the marker line, including the line terminator
        that precedes it.  Equal to ``raw`` when there is no marker.
    marker : str or None
        The marker line without its terminator, or ``None``.
    """
    if not raw:
        return raw, None
    trailing = b""
    core = raw
    while core.endswith(b"\n") or core.endswith(b"\r"):
        trailing = core[-1:] + trailing
        core = core[:-1]
    idx = max(core.rfind(b"\n"), core.rfind(b"\r"))
    last = core[idx + 1:]
    try:
        text = last.decode("utf-8")
    except UnicodeDecodeError:
        return raw, None
    if MARKER_TOKEN not in text:
        return raw, None
    if not _MARKER_RE.match(text.strip()):
        # Present but malformed: still a marker for reporting purposes,
        # so the gate can reject it rather than silently ignore it.
        return core[:idx + 1], text
    return core[:idx + 1], text


def body_digest(body: bytes) -> str:
    """
    SHA-256 of the body, hex.

    Parameters
    ----------
    body : bytes
        Everything before the marker line.

    Returns
    -------
    str
        Lower-case hex digest, 64 characters.
    """
    return hashlib.sha256(body).hexdigest()


def _line_ending(body: bytes) -> bytes:
    """
    The line ending the file already uses.

    Parameters
    ----------
    body : bytes
        The file body.

    Returns
    -------
    bytes
        ``b"\\r\\n"`` or ``b"\\n"``; CRLF when the file's last terminator
        is CRLF, LF otherwise.  Rule 6.
    """
    if body.endswith(b"\r\n"):
        return b"\r\n"
    if body.endswith(b"\n"):
        return b"\n"
    if b"\r\n" in body:
        return b"\r\n"
    return b"\n"


def _count_lines(body: bytes) -> int:
    """
    Number of lines in the body.

    Parameters
    ----------
    body : bytes
        The file body.

    Returns
    -------
    int
        Line count, counting a final unterminated line.
    """
    if not body:
        return 0
    text = body.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    n = text.count(b"\n")
    if not text.endswith(b"\n"):
        n += 1
    return n


# ======================================================================
# Verification
# ======================================================================

class Verdict:
    """
    Outcome of examining one file.

    Attributes
    ----------
    rel : str
        Path relative to the repository root.
    state : str
        One of ``"complete"``, ``"in_flight"``, ``"stale_digest"``,
        ``"malformed"``, ``"exempt"``.
    detail : str
        Human-readable explanation, empty when there is nothing to say.
    phase : str or None
        The phase recorded in the marker, when there is one.
    """

    __slots__ = ("rel", "state", "detail", "phase")

    def __init__(self, rel: str, state: str, detail: str = "",
                 phase: Optional[str] = None) -> None:
        self.rel = rel
        self.state = state
        self.detail = detail
        self.phase = phase

    @property
    def failed(self) -> bool:
        """
        Whether this verdict makes the gate fail.

        Returns
        -------
        bool
            True for ``stale_digest`` and ``malformed``.  ``in_flight``
            is not a failure: rule 4.
        """
        return self.state in ("stale_digest", "malformed")


def verify_file(path: str, rel: str) -> Verdict:
    """
    Examine one file and report its completion state.

    Parameters
    ----------
    path : str
        Absolute path to the file.
    rel : str
        Path relative to the repository root, used in the verdict.

    Returns
    -------
    Verdict
        The outcome.
    """
    if rel.replace(os.sep, "/") in EXEMPT:
        return Verdict(rel, "exempt")
    raw = _read_bytes(path)
    body, marker = split_marker(raw)
    if marker is None:
        # A well-formed marker anywhere but the last line is not a
        # marker (rule 1) -- but it must be *reported*, not ignored.
        # Falsification case ``marker_not_last`` found this hole: a
        # buried marker was silently indistinguishable from an unstamped
        # file, which is the very silence this tool exists to remove.
        text = body.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
        for n, line in enumerate(text.decode("utf-8", "replace").split("\n")):
            if _MARKER_RE.match(line.strip()):
                return Verdict(
                    rel, "malformed",
                    "marker on line %d but the file continues past it; "
                    "a marker proves completion only as the last line"
                    % (n + 1))
        return Verdict(rel, "in_flight", "no marker")
    m = _MARKER_RE.match(marker.strip())
    if m is None:
        return Verdict(rel, "malformed",
                       "marker present but does not parse: %r" % marker[:80])
    want = m.group("sha")
    got = body_digest(body)
    if want != got:
        return Verdict(
            rel, "stale_digest",
            "body changed after stamping: marker %s..., body %s..."
            % (want[:12], got[:12]),
            m.group("phase"))
    want_lines = int(m.group("lines"))
    got_lines = _count_lines(body)
    if want_lines != got_lines:
        return Verdict(
            rel, "stale_digest",
            "body line count changed: marker %d, body %d"
            % (want_lines, got_lines),
            m.group("phase"))
    return Verdict(rel, "complete", "", m.group("phase"))


# ======================================================================
# Stamping
# ======================================================================

def stamp_file(path: str, phase: int, when: Optional[str] = None) -> str:
    """
    Append or refresh the completion marker of one file.

    Re-stamping a file that already carries a marker replaces it: the
    body is re-digested and the timestamp is renewed.  The marker is
    never edited in place to agree with a changed body by any other
    route, because that would forge the fact it carries (rule 3).

    Parameters
    ----------
    path : str
        Absolute path to the file.
    phase : int
        The phase asserting completion.
    when : str, optional
        UTC timestamp in ``YYYY-MM-DDTHH:MM:SSZ``.  Defaults to now.

    Returns
    -------
    str
        The marker line written.

    Raises
    ------
    ValueError
        If the file's extension has no comment syntax in
        :data:`COMMENT_PREFIX`: a marker that the file's own parser
        would choke on is worse than no marker.
    """
    ext = os.path.splitext(path)[1].lower()
    prefix = COMMENT_PREFIX.get(ext)
    if prefix is None:
        raise ValueError(
            "no comment syntax declared for %r; add it to COMMENT_PREFIX "
            "or leave the file unmarked" % ext)
    raw = _read_bytes(path)
    body, _ = split_marker(raw)
    eol = _line_ending(body)
    if body and not (body.endswith(b"\n") or body.endswith(b"\r")):
        body = body + eol
    stamp = when or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    marker = ("%s %s phase=%d utc=%s sha256=%s body_lines=%d"
              % (prefix, MARKER_TOKEN, phase, stamp,
                 body_digest(body), _count_lines(body)))
    with open(path, "wb") as fh:
        fh.write(body)
        fh.write(marker.encode("utf-8"))
        fh.write(eol)
    return marker


# ======================================================================
# Walking the tree
# ======================================================================

def _candidates(root: str) -> List[Tuple[str, str]]:
    """
    Every file in the tree that could carry a marker.

    Parameters
    ----------
    root : str
        Repository root.

    Returns
    -------
    list of (str, str)
        Pairs of absolute path and repository-relative path.
    """
    out: List[Tuple[str, str]] = []
    skip = {".git", "__pycache__", ".pytest_cache", ".venv", "_build"}
    for dirpath, dirnames, filenames in os.walk(root):
        # ``*.egg-info`` joins the skip set in Phase 32, measured.  The
        # directory is build metadata that setuptools writes on an
        # editable install and that no commit ever carries, but its
        # five .txt/.cfg entries were counted here -- so the "in
        # flight" total this tool publishes was 291 on a clone and 296
        # on the same clone after `pip install -e .`.  A denominator
        # that depends on whether the tree happens to be installed is
        # not a denominator, and 00_BOOTSTRAP.md quotes it as one.
        dirnames[:] = [d for d in dirnames
                       if d not in skip and not d.endswith(".egg-info")]
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            if ext not in COMMENT_PREFIX:
                continue
            ap = os.path.join(dirpath, fn)
            out.append((ap, os.path.relpath(ap, root)))
    return sorted(out, key=lambda p: p[1])


def gate(root: str, verbose: bool = False) -> int:
    """
    Verify every marker in the tree.

    Parameters
    ----------
    root : str
        Repository root.
    verbose : bool, optional
        List every file, not only the failures.

    Returns
    -------
    int
        0 when no marker is stale or malformed, 1 otherwise.  An
        unmarked file does not fail the gate (rule 4).
    """
    verdicts = [verify_file(ap, rel) for ap, rel in _candidates(root)]
    bad = [v for v in verdicts if v.failed]
    tally: Dict[str, int] = {}
    for v in verdicts:
        tally[v.state] = tally.get(v.state, 0) + 1
    if verbose:
        for v in verdicts:
            print("  %-14s %s%s" % (v.state, v.rel,
                                    "  -- " + v.detail if v.detail else ""))
    for v in bad:
        print("  FAIL  %-14s %s -- %s" % (v.state, v.rel, v.detail))
    print()
    print("%d file(s) examined: %s"
          % (len(verdicts),
             ", ".join("%d %s" % (n, k) for k, n in sorted(tally.items()))))
    if bad:
        print("GATE FAIL: %d marker(s) do not match their body." % len(bad))
        return 1
    print("GATE PASS: every marker present agrees with its body.")
    return 0


def status(root: str) -> int:
    """
    Report completion state per directory.

    Parameters
    ----------
    root : str
        Repository root.

    Returns
    -------
    int
        Always 0; this is a report, not a gate.
    """
    verdicts = [verify_file(ap, rel) for ap, rel in _candidates(root)]
    by_dir: Dict[str, Dict[str, int]] = {}
    for v in verdicts:
        d = os.path.dirname(v.rel) or "."
        by_dir.setdefault(d, {})
        by_dir[d][v.state] = by_dir[d].get(v.state, 0) + 1
    print("%-42s %9s %9s %6s" % ("directory", "complete", "in_flight", "bad"))
    for d in sorted(by_dir):
        t = by_dir[d]
        print("%-42s %9d %9d %6d"
              % (d, t.get("complete", 0), t.get("in_flight", 0),
                 t.get("stale_digest", 0) + t.get("malformed", 0)))
    return 0


# ======================================================================
# Falsification
# ======================================================================

def falsify(root: str) -> int:
    """
    Prove the gate can fail.

    Builds a throwaway copy of a stamped file for each corruption and
    requires the verdict to reject it, plus a null control that must be
    accepted untouched.  A gate never seen to fail is not evidence.

    The corruptions
    ---------------
    ``body_edited``
        One byte of the body changes after stamping.  The digest must
        disagree.
    ``marker_not_last``
        A line is appended after the marker, so the marker is no longer
        the last line.  It must stop counting as a marker.
    ``tail_truncated``
        The last quarter of the body is cut and the marker kept, which
        is exactly the interrupted-write shape.  The digest must
        disagree.
    ``digest_forged``
        The digest field is replaced with a well-formed but wrong value.
        The gate must not be satisfied by shape alone.
    ``null_control``
        Nothing changes.  The gate must pass, or the other four prove
        nothing.

    Parameters
    ----------
    root : str
        Repository root.

    Returns
    -------
    int
        0 when every corruption is rejected and the control accepted.
    """
    tmp = tempfile.mkdtemp(prefix="gensec_marker_falsify_")
    try:
        src = os.path.join(tmp, "subject.py")
        with open(src, "wb") as fh:
            for i in range(40):
                fh.write(("# body line %d\r\n" % i).encode("utf-8"))
        stamp_file(src, 30)
        pristine = _read_bytes(src)

        cases = []

        def _case(name, raw, must_fail):
            p = os.path.join(tmp, name + ".py")
            with open(p, "wb") as fh:
                fh.write(raw)
            v = verify_file(p, name + ".py")
            ok = v.failed if must_fail else (v.state == "complete")
            cases.append((name, v.state, must_fail, ok, v.detail))

        body, marker = split_marker(pristine)
        eol = b"\r\n"

        _case("null_control", pristine, False)
        _case("body_edited",
              body.replace(b"# body line 7", b"# body line X", 1)
              + marker.encode() + eol, True)
        _case("marker_not_last",
              pristine + b"# appended after the marker" + eol, True)
        cut = body[: max(1, len(body) * 3 // 4)]
        if not cut.endswith(b"\n"):
            cut = cut[: cut.rfind(b"\n") + 1]
        _case("tail_truncated", cut + marker.encode() + eol, True)
        forged = re.sub(r"sha256=[0-9a-f]{64}",
                        "sha256=" + "0" * 64, marker)
        _case("digest_forged", body + forged.encode() + eol, True)

        print("%-18s %-14s %-10s %s" % ("case", "verdict", "expected", "ok"))
        for name, state, must_fail, ok, detail in cases:
            print("  %-16s %-14s %-10s %s%s"
                  % (name, state, "reject" if must_fail else "accept",
                     "OK" if ok else "**NOT DISCRIMINATING**",
                     "  -- " + detail if detail and not ok else ""))
        bad = [c for c in cases if not c[3]]
        print()
        if bad:
            print("FALSIFICATION FAIL: %d case(s) not discriminating."
                  % len(bad))
            return 1
        print("FALSIFICATION PASS: 4 corruptions rejected, "
              "null control accepted.")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ======================================================================
# CLI
# ======================================================================

def main(argv: List[str]) -> int:
    """
    Command-line entry point.

    Parameters
    ----------
    argv : list of str
        Arguments without the program name.

    Returns
    -------
    int
        Process exit code.
    """
    root = _repo_root()
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd = argv[0]
    if cmd == "--gate":
        return gate(root, verbose="-v" in argv)
    if cmd == "--status":
        return status(root)
    if cmd == "--falsify":
        return falsify(root)
    if cmd == "--stamp":
        if len(argv) < 2:
            print("--stamp needs at least one path")
            return 2
        # NO DEFAULT (Phase 32, Z-13).  This was ``phase = 30``, a
        # literal written when the tool was built and never revisited.
        # The field it fills is PROVENANCE -- section 4.2 rule 5 of the
        # bootstrap says so -- and a hardcoded default on a provenance
        # field asserts something false the moment the phase number
        # moves.  Measured: it silently labelled twenty Phase-32 files
        # as Phase-30 work, inside the phase whose own ledger records
        # three earlier instances of a declaration its object
        # contradicts.  The caller now says which phase, or nothing is
        # stamped.
        phase = None
        paths = []
        rest = argv[1:]
        i = 0
        while i < len(rest):
            if rest[i] == "--phase":
                phase = int(rest[i + 1])
                i += 2
                continue
            paths.append(rest[i])
            i += 1
        if phase is None:
            print("--stamp requires --phase N: the marker records which "
                  "phase completed the file, and a default would sign "
                  "somebody else's name to this work.")
            return 2
        for p in paths:
            ap = p if os.path.isabs(p) else os.path.join(root, p)
            print("  " + stamp_file(ap, phase))
        return 0
    print("unknown command %r" % cmd)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
# GENSEC-COMPLETE phase=32 utc=2026-09-05T13:56:13Z sha256=40017177539a781ca2107c66f37995b7385159e2c10c8a33cd9999c76bacc7bd body_lines=748
