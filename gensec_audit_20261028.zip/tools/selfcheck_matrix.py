# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
Falsification harness for patcher ``--selfcheck`` claims.

A ``--selfcheck`` that has never been seen to fail is not a check; it is
a decoration.  This harness deliberately corrupts a tree in six ways and
records, for every patcher that offers a ``--selfcheck``, whether the
corruption is **detected** and whether a subsequent application
**repairs** it.

Corruption modes
----------------
``deleted``
    The target file is removed.
``crlf_flip``
    Every line ending is swapped (``\r\n`` becomes ``\n`` and vice
    versa).  Content is unchanged as *text*; only bytes move.  This is
    the mode that separates a byte comparison from a text comparison,
    and the one a text comparison silently passes.
``truncated``
    The file is cut to 60 % of its length.
``one_byte``
    A single ASCII letter in the middle of the file is changed.
``read_only``
    Permissions are reduced to ``0444``; content is left correct.
``read_only_corrupt``
    ``one_byte`` **and** ``0444``.

The sixth mode is an addition to the five used in Phase 16, and the
reason is a measurement: plain ``read_only`` leaves the content correct,
so a PASS proves nothing -- it is the "passes before and after" shape
this project rejects in fixtures.  ``read_only_corrupt`` is the
discriminating version: it asks whether an application that *cannot*
write reports failure or reports success.

Scoring
-------
Two independent questions per cell, and they must not be conflated:

**detected** -- does ``--selfcheck`` exit non-zero on the corrupt tree?
    A green here is a **false green** whenever the corruption is still
    present, and a false green is worse than a vacuous check, because a
    vacuous check promises nothing.

**repaired** -- after running the patcher without flags, are the bytes
    back to the verified content?

Baseline discipline
-------------------
A patcher whose ``--selfcheck`` is already red on the pristine tree
cannot be measured this way: the red is pre-existing and the corruption
adds nothing observable.  Such patchers are reported as
``baseline RED`` with the reason, never scored.  This is the same rule
that governs fixtures (``15_1`` section 3, ``16_1`` section 3): a red
for the wrong reason is not evidence.

Usage
-----
``python tools/selfcheck_matrix.py [--patcher NAME] [--json]``
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
from typing import Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

MODES = ("deleted", "crlf_flip", "truncated", "one_byte",
         "read_only", "read_only_corrupt")

#: Patchers whose own application is what puts the tree into the state
#: their ``--selfcheck`` verifies.  For these the scratch tree is
#: primed by applying the patcher once before the mode loop.
_SELF_PRIMING = ("bytes",)


def _run(cmd: List[str], cwd: str) -> Tuple[int, str]:
    """
    Run *cmd* and return its exit status and combined output.

    The status is taken from the process itself, never through a pipe:
    ``cmd | tail`` reports ``tail``'s exit code, an error that has
    already cost this project three false green measurements.

    Parameters
    ----------
    cmd : list of str
    cwd : str

    Returns
    -------
    (int, str)
    """
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def _corrupt(path: str, mode: str) -> None:
    """
    Apply corruption *mode* to *path*.

    Parameters
    ----------
    path : str
    mode : str
        One of :data:`MODES`.
    """
    if mode == "deleted":
        os.remove(path)
        return
    raw = open(path, "rb").read()
    if mode == "crlf_flip":
        raw = (raw.replace(b"\r\n", b"\n") if b"\r\n" in raw
               else raw.replace(b"\n", b"\r\n"))
    elif mode == "truncated":
        raw = raw[: int(len(raw) * 0.6)]
    elif mode in ("one_byte", "read_only_corrupt"):
        i = len(raw) // 2
        while i < len(raw) and not (65 <= raw[i] <= 90 or
                                    97 <= raw[i] <= 122):
            i += 1
        if i >= len(raw):                              # pragma: no cover
            i = len(raw) - 1
        raw = raw[:i] + bytes([raw[i] ^ 0x20]) + raw[i + 1:]
    with open(path, "wb") as fh:
        fh.write(raw)
    if mode in ("read_only", "read_only_corrupt"):
        os.chmod(path, stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)


def _restore(scratch: str, snapshot: Dict[str, Optional[bytes]]) -> None:
    """
    Put every claimed file back to its snapshot state.

    Parameters
    ----------
    scratch : str
    snapshot : dict
        ``{relpath: bytes or None}``; ``None`` means the file did not
        exist when the snapshot was taken.
    """
    for rel, data in snapshot.items():
        path = os.path.join(scratch, *rel.split("/"))
        if os.path.exists(path):
            os.chmod(path, 0o644)
        if data is None:
            if os.path.exists(path):
                os.remove(path)
            continue
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as fh:
            fh.write(data)


def measure(name: str, mechanism: str, files: List[str],
            base: str) -> Dict[str, object]:
    """
    Run the six corruption modes against one patcher.

    Parameters
    ----------
    name : str
        Patcher file name.
    mechanism : str
        From :mod:`tools.selfcheck_inventory`.
    files : list of str
        Relative paths the patcher claims.
    base : str
        Path to a pristine tree to copy from.

    Returns
    -------
    dict
        ``{"name", "target", "baseline", "cells"}`` where ``cells`` maps
        each mode to ``{"selfcheck_exit", "detected", "apply_exit",
        "repaired"}``.
    """
    result: Dict[str, object] = {"name": name, "mechanism": mechanism,
                                 "target": None, "baseline": None,
                                 "cells": {}, "note": ""}
    scratch = tempfile.mkdtemp(prefix="sc_")
    tree = os.path.join(scratch, "gensec")
    try:
        shutil.copytree(base, tree, symlinks=True)
        patcher = os.path.join("patchers", name)

        if mechanism in _SELF_PRIMING:
            _run([sys.executable, patcher], tree)

        rc, _ = _run([sys.executable, patcher, "--selfcheck"], tree)
        result["baseline"] = rc
        if rc != 0:
            result["note"] = ("baseline RED after priming; a superseded "
                              "patcher cannot verify a tree a later "
                              "phase legitimately moved (F-B14)")
            return result

        candidates = [f for f in files
                      if os.path.isfile(os.path.join(tree, *f.split("/")))]
        if not candidates:
            result["note"] = "no claimed file present on disk"
            return result
        target = candidates[0]
        result["target"] = target
        tpath = os.path.join(tree, *target.split("/"))

        snapshot: Dict[str, Optional[bytes]] = {}
        for rel in files:
            p = os.path.join(tree, *rel.split("/"))
            snapshot[rel] = open(p, "rb").read() if os.path.isfile(p) else None
        want = snapshot[target]

        cells: Dict[str, Dict[str, object]] = {}
        for mode in MODES:
            _restore(tree, snapshot)
            _corrupt(tpath, mode)
            sc_rc, _ = _run([sys.executable, patcher, "--selfcheck"], tree)
            ap_rc, _ = _run([sys.executable, patcher], tree)
            now = (open(tpath, "rb").read()
                   if os.path.isfile(tpath) else None)
            cells[mode] = {
                "selfcheck_exit": sc_rc,
                "detected": sc_rc != 0,
                "apply_exit": ap_rc,
                "repaired": now == want,
            }
            os.chmod(tpath, 0o644) if os.path.exists(tpath) else None
        _restore(tree, snapshot)
        result["cells"] = cells
        return result
    finally:
        for dirpath, _, filenames in os.walk(scratch):
            for fn in filenames:
                try:
                    os.chmod(os.path.join(dirpath, fn), 0o644)
                except OSError:                        # pragma: no cover
                    pass
        shutil.rmtree(scratch, ignore_errors=True)


def main(argv: Optional[List[str]] = None) -> int:
    """
    Command-line entry point.

    Returns
    -------
    int
        ``0`` always; the harness reports, it does not gate.
    """
    argv = list(sys.argv[1:] if argv is None else argv)
    sys.path.insert(0, HERE)
    from selfcheck_inventory import inventory          # noqa: E402

    only = None
    if "--patcher" in argv:
        only = argv[argv.index("--patcher") + 1]

    rows = [r for r in inventory()
            if r["mechanism"] in ("bytes", "bytes_wrapped", "sentinel",
                                  "sentinel_local")]
    if only:
        rows = [r for r in rows if r["name"] == only]

    out = []
    for r in rows:
        out.append(measure(str(r["name"]), str(r["mechanism"]),
                           list(r["files"]), ROOT))

    if "--json" in argv:
        print(json.dumps(out, indent=2))
        return 0

    head = f"{'patcher':<30}" + "".join(f"{m[:9]:>11}" for m in MODES)
    print(head)
    print("-" * len(head))
    for r in out:
        if not r["cells"]:
            print(f"{r['name']:<30}  -- {r['note']}")
            continue
        line = f"{r['name']:<30}"
        for m in MODES:
            c = r["cells"][m]
            flag = "DET" if c["detected"] else "green"
            rep = "+rep" if c["repaired"] else ""
            line += f"{flag + rep:>11}"
        print(line)
        print(f"{'':<30}" + "".join(
            f"{str(r['cells'][m]['selfcheck_exit']) + '/' + str(r['cells'][m]['apply_exit']):>11}"
            for m in MODES))
    print("-" * len(head))
    print("  cell 1: DET = selfcheck exit != 0 (corruption detected); "
          "green = exit 0")
    print("          +rep = the application restored the verified bytes")
    print("  cell 2: selfcheck_exit / apply_exit, read directly")
    return 0


if __name__ == "__main__":                             # pragma: no cover
    raise SystemExit(main())
