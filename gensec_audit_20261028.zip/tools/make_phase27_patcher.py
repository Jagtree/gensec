r"""
Build ``patchers/run_phase27_service_path.py``.

The mechanism is **not** rewritten: the head (imports, ``ROOT``,
``PATH_ALIASES``, ``_resolve``) and the whole tail (``_verified``,
``main`` and its ``--selfcheck`` / ``--repair`` modes) are lifted
verbatim from the Phase-26 patcher.  One home for one fact: a
second implementation of atomic transport would be a second thing to
be wrong.  Only three regions are authored here — the header
docstring, ``PAYLOAD`` and ``DIGESTS``.

Usage
-----
::

    python3 tools/make_phase27_patcher.py
"""

import base64
import hashlib
import pathlib
import sys
import textwrap
import zlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase26_service_law.py"
OUT = ROOT / "patchers" / "run_phase27_service_path.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there.
FILES = [
    "src/gensec/materials/base.py",
    "src/gensec/materials/ec2_properties.py",
    "src/gensec/materials/rheology.py",
    "src/gensec/output/report.py",
    "src/gensec/solver/losses.py",
    "src/gensec/solver/posttension.py",
    "src/gensec/solver/sls.py",
    "src/gensec/solver/timeline.py",
    "examples/example_composite_losses.yaml",
    "examples/example_composite_losses_fb_gap.yaml",
    "tests/aci209_falsification.py",
    "tests/run_p02_modulus_validation.py",
    "tests/run_phase7_sls_validation.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase12_domain.py",
    "tests/test_phase12_p2.py",
    "tests/test_phase13_dump.py",
    "tests/test_phase15_boltzmann.py",
    "tests/test_phase27_service_path.py",
    "tools/numeric_fingerprint.py",
    "tools/element_class_baseline.txt",
    "tools/element_class_reasons.py",
    "tools/selfcheck_inventory.py",
    "tools/make_phase27_patcher.py",
    ".fingerprints/27_00_numeric_PRE.txt",
    ".fingerprints/27_00_datum_PRE.txt",
    ".fingerprints/27_00_domain_PRE.txt",
    ".fingerprints/27_01_numeric_POST.txt",
    ".fingerprints/27_01_datum_POST.txt",
    ".fingerprints/27_01_domain_POST.txt",
    "handoff/27_0-GENSEC_LEDGER_27.md",
    "handoff/27_1-GENSEC_PHASE27_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 27 — D26-7 / D26-8: the service law reaches the solver.

What this transports
--------------------
* ``src/gensec/materials/base.py`` — ``RheologicalModel`` gains a fifth
  abstract function, ``service_law(t)``.  Rheology is normative and so
  is the law it hands back: every constant evaluated **at t**, the
  tensile strength nominated by the provider's **own** code, and a
  refusal by name from any provider whose document owns no
  constitutive law;
* ``src/gensec/materials/rheology.py`` — the Eurocode provider builds
  ``ServiceConcrete`` from the single ``fben2`` evaluation it already
  uses for ``E_c``, so law and modulus cannot drift apart.
  ``f_ct,eff = f_ctm(t)`` because EN 1992-1-1 7.3.2(2) nominates it.
  The tabulated provider refuses: it knows J(t,t\u2032) and no strength;
* ``src/gensec/materials/ec2_properties.py`` — ``EC2EarlyAgeConcrete``
  and ``EC2_EARLY_AGE_LIMIT_DAYS``, the sub-three-day boundary, inside
  the module that owns the clause and naming no other document;
* ``src/gensec/solver/sls.py`` — ``ModulusMap`` becomes ``MaterialMap``
  (tuples of materials, ``E_bulk`` / ``E_elem`` derived from
  ``reference_modulus``); ``bulk_material`` / ``elem_material``;
  ``_as_material``, where a number still declares a straight line but
  the reverse no longer happens; ``sls_view`` without ``_lin``; and the
  removal of ``uncracked_basis_violated`` with its whole family;
* ``src/gensec/solver/losses.py`` — line 960 asked the provider for
  ``E_c(t)`` while the grout datum asked for ``service_law(t)``: the
  read-back of a jacked tendon came back 1252.335 MPa on a 1250.0 MPa
  jack.  Both solves now read one law from one provider;
* ``examples/example_composite_losses*.yaml`` — the topping moves from
  1 day to 3.  Below three days ``fben2`` reports f_cm = 0 while still
  reporting E_cm and f_ctm, and a material with stiffness, tensile
  strength and no compressive strength cannot be built;
* ``tools/numeric_fingerprint.py`` — two probes, ``_service_concrete``
  (288 keys) and ``_sls_staged`` (37).  Reachability was **measured**:
  the instrument crosses ``sls_view`` 80 times per capture and **zero**
  times inside ``verify_sls_staged``, which is API-only since Phase 7
  D5.  Both probes were falsified before their green was read;
* ``tests/test_phase27_service_path.py`` — **new**, 9 cases.  Run on a
  clone of ``gensec_phase26.bundle``: **5 red, 4 green**, every red an
  ``AssertionError``, not one ``ImportError``.  One fixture was
  replaced rather than relabelled after it went green on the pristine
  tree by omitting the modmap;
* ``tests/`` — the Phase-7 and Phase-12 contracts rewritten, not
  worked around; three validators adapted;
* ``.fingerprints/27_0*`` — PRE on a tree rebuilt from the bundle with
  the extended instrument verified byte-identical in both trees, POST
  on the repaired tree;
* ``handoff/`` — ledger, recap, and ``00_BOOTSTRAP.md`` updated in
  full.

What moved, and what did not
----------------------------
184 numeric keys of 5616, 49 datum of 418, **0 domain of 31**.  The
domain INERT is correct rather than blind: this phase does not change
what is declared, it changes what answers.  Of the numeric movements,
108 are ``example_composite_losses`` (age and law), 39
``example_staged_cracking``, 35 ``example_composite_timeline``, and 6
are ``sls.*`` — the removed flag.  Nothing was added and nothing
removed on any of the three.

The measurement the phase turns on, on 400x1200 C35/45 at N = -1000 kN
and M = 900 kNm through the datum path: the extreme tensile fibre goes
from **+6.531641 MPa** — against f_ctm = 3.209962 — to **0.000000**,
and the curvature from 4.173735e-07 to 1.328180e-06.

Usage
-----
::

    python3 patchers/run_phase27_service_path.py --selfcheck
    python3 patchers/run_phase27_service_path.py --repair
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the Phase-26 patcher this one is lifted from stores
    the bytes as they are, and a second encoding would be a second
    thing to get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    src = SRC.read_text(encoding="utf-8")
    # The mechanism is lifted verbatim: everything above PAYLOAD and
    # everything from _verify_payload down.  Only the header docstring
    # and the two data blocks are authored here.
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
