r"""
Build ``patchers/run_phase30_coordinate_and_silences.py``.

The mechanism is **not** rewritten: the head (imports, ``ROOT``,
``PATH_ALIASES``, ``_resolve``) and the whole tail (``_verified``,
``main`` and its ``--selfcheck`` / ``--repair`` modes) are lifted
verbatim from the Phase-29 patcher.  One home for one fact: a second
implementation of atomic transport would be a second thing to be
wrong.  Only three regions are authored here — the header docstring,
``PAYLOAD`` and ``DIGESTS``.

Usage
-----
::

    python3 tools/make_phase30_patcher.py
"""

import base64
import hashlib
import pathlib
import sys
import textwrap

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase29_extreme_fibre_check.py"
OUT = ROOT / "patchers" / "run_phase30_coordinate_and_silences.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there.
FILES = [
    "src/gensec/solver/sls.py",
    "src/gensec/geometry/primitives.py",
    "src/gensec/io_yaml.py",
    "src/gensec/materials/verification_limits.py",
    "src/gensec/materials/elastic.py",
    "examples/example_annulus.yaml",
    "examples/yaml_reference_example.yaml",
    "docs/yaml_reference.rst",
    "tests/run_phase7_sls_validation.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase27_service_path.py",
    "tests/test_phase28_strain_accumulation.py",
    "tests/test_phase29_extreme_fibre_check.py",
    "tests/test_phase30_reported_coordinate.py",
    "tests/test_phase30_check_block.py",
    "tests/test_phase30_polygonisation.py",
    "tools/numeric_fingerprint.py",
    "tools/completion_marker.py",
    "tools/selfcheck_inventory.py",
    "tools/material_assumption_baseline.txt",
    "tools/make_phase30_patcher.py",
    ".fingerprints/30_00_numeric_PRE.txt",
    ".fingerprints/30_00_datum_PRE.txt",
    ".fingerprints/30_00_domain_PRE.txt",
    ".fingerprints/30_01_numeric_POST.txt",
    ".fingerprints/30_01_datum_POST.txt",
    ".fingerprints/30_01_domain_POST.txt",
    "handoff/30_0-GENSEC_LEDGER_30.md",
    "handoff/30_1-GENSEC_PHASE30_RECAP.md",
    "handoff/30_2-GENSEC_ZONE_LIMITS_DESIGN.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 30 - the coordinate on the material, and four silences.

What this transports
--------------------
**Task A.**  A turning point of the zone's own law was placed by linear
interpolation along the segment joining the two extreme-strain
vertices.  On a re-entrant or holed region that segment leaves the
material, so the record named a coordinate with nothing under it:
measured over 360 strain directions, 360/360 on example_annulus (worst
excursion 366.335 mm), 359/360 on example_custom (108.788 mm), 121/360
on example_tee (17.144 mm).  The tee is named because 29_0 s10 recorded
it as unaffected, which held only for the single bending direction that
measurement used.  The value was never wrong -- a connected region
under an affine field attains every strain between its own extremes --
so the point is relocated onto the iso-strain line, which cannot move
the strain and therefore cannot move the stress.  Discarding it
instead was measured to move the reported extreme by up to 28.2743 MPa
on example_custom.  The coordinate is not unique: the line meets a
re-entrant region in two disjoint segments for 66.7 % of directions, so
what is published is A point at which the extreme is attained, not THE
point, and the choice is deterministic for that reason alone.

**Task B, four silences.**  ``StressLimits.fct_eff`` was accepted and
read zero times -- the socket left by the uncracked-basis flag Phase 27
removed -- and is deleted; f_ct,eff is a property of the concrete and
lives on ServiceConcrete.  ``_check_entry`` divided by an unguarded
limit: zero raised ZeroDivisionError, negative did not raise at all and
produced a negative utilisation.  The record rounded to six decimals
while the verdict was taken on the unrounded numbers, and the two bands
differ: 5e-07 MPa on the value, 5e-07*limit on eta -- 9.449e-04 MPa at
1860 MPa, where the record could read value 1860.0009, eta 1.0, passed
False.  ``tendon_stress`` and ``steel_tension`` vanished with no
skipped entry when their elements were absent, while decompression in
the same block already emitted one.

**Also.**  ``resolution`` on circle_poly / annulus_poly was Shapely's
quad_segs, i.e. segments per QUADRANT, while its docstring called it
vertices on the circumference: wrong by 4, and by 16 on the sagitta.
Renamed to ``segments_per_quadrant`` and made mandatory -- it selects
which section is analysed, not how finely a fixed one is integrated.

New tool ``tools/completion_marker.py``: a last-line marker carrying a
digest of everything before it, so a finished file can be told from one
left half-written by an interrupted turn.

Idempotent, all-or-nothing, CRLF preserved per file.  ``--selfcheck``
compares bytes.  See handoff/30_0-GENSEC_LEDGER_30.md.
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the Phase-29 patcher this one is lifted from stores
    the bytes as they are, and a second encoding would be a second
    thing to get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    src = SRC.read_text(encoding="utf-8")
    # The mechanism is lifted verbatim: everything above PAYLOAD and
    # everything from _verify_payload down.  Only the header docstring
    # and the two data blocks are authored here.
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
# GENSEC-COMPLETE phase=30 utc=2026-09-04T12:09:35Z sha256=5f2866162c55951771b16c79c3d4e7c6022e3d65c81bb58714d7c8983ac8ff59 body_lines=185
