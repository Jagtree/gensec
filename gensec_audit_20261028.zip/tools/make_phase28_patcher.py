r"""
Build ``patchers/run_phase28_strain_accumulation.py``.

The mechanism is **not** rewritten: the head (imports, ``ROOT``,
``PATH_ALIASES``, ``_resolve``) and the whole tail (``_verified``,
``main`` and its ``--selfcheck`` / ``--repair`` modes) are lifted
verbatim from the Phase-27 patcher.  One home for one fact: a second
implementation of atomic transport would be a second thing to be
wrong.  Only three regions are authored here — the header docstring,
``PAYLOAD`` and ``DIGESTS``.

Usage
-----
::

    python3 tools/make_phase28_patcher.py
"""

import base64
import hashlib
import pathlib
import sys
import textwrap

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase27_service_path.py"
OUT = ROOT / "patchers" / "run_phase28_strain_accumulation.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there.
FILES = [
    "src/gensec/materials/base.py",
    "src/gensec/materials/service_concrete.py",
    "src/gensec/solver/sls.py",
    "tests/run_phase7_sls_validation.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase28_strain_accumulation.py",
    "tools/numeric_fingerprint.py",
    "tools/element_class_baseline.txt",
    "tools/element_class_reasons.py",
    "tools/getattr_reasons.py",
    "tools/selfcheck_inventory.py",
    "tools/make_phase28_patcher.py",
    ".fingerprints/28_00_numeric_PRE.txt",
    ".fingerprints/28_00_datum_PRE.txt",
    ".fingerprints/28_00_domain_PRE.txt",
    ".fingerprints/28_01_numeric_POST.txt",
    ".fingerprints/28_01_datum_POST.txt",
    ".fingerprints/28_01_domain_POST.txt",
    "handoff/28_0-GENSEC_LEDGER_28.md",
    "handoff/28_1-GENSEC_PHASE28_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 28 — D27-1: the SLS accumulation moves to strain.

What this transports
--------------------
* ``src/gensec/solver/sls.py`` — the accumulation stops superposing
  stresses.  ``_affine_increment`` / ``_affine_entering_set`` become
  ``_strain_increment`` / ``_strain_entering_set``, the same
  expressions with the zone modulus taken out of them; the per-fibre
  stress accumulator is gone, because the per-zone affine strain field
  evaluated at a fibre **is** the fibre's strain and one fact needs one
  home.  ``_element_sigmas`` becomes ``_element_states``, returning
  strains and the element laws.  ``_extreme_fibre`` and
  ``_extreme_fibre_by_zone`` read the law over a candidate set;
  ``_decompression_probe`` takes its verdict on strain, with the
  declared stress tolerance divided by the zone's reference modulus so
  that the criterion on a straight line is bit-for-bit the Phase-7
  one.  ``debug_check_affine`` is removed with its keyword: it compared
  two accumulators and there is one.  ``stage["moduli"]`` is refused by
  ``ValueError`` naming ``service_law(t)``;
* ``src/gensec/materials/base.py`` — ``Material.stress_breakpoints()``,
  default ``()``.  On a curve the extreme stress over a region is no
  longer at a vertex, and where a law turns over is a fact belonging to
  the law.  Sampling instead would put back the discretisation error
  that the closed-form extreme fibre exists to remove (F6);
* ``src/gensec/materials/service_concrete.py`` — the override,
  ``(-eps_cu1, -eps_c1, +eps_ct)``: the peak of (3.14), the cracking
  strain where the tension branch drops to zero, and the compressive
  limit where the expression stops being defined;
* ``tools/numeric_fingerprint.py`` — 148 keys, 61 under ``sls_nl.*``
  and 87 under ``sls.res.*`` / ``sls.svc.*`` / ``sls.selfcheck[*]``.
  Each records the solved plane, the reported extremes, **the law
  re-read independently at the point the report names**, the residual,
  the value actually verified, and the function's outcome at its own
  defaults as a token.  The consistency keyword is read from the
  signature, never named, so the probe runs on both trees.  Falsified
  on four distinct corruptions plus a null control before any green was
  read;
* ``tests/test_phase28_strain_accumulation.py`` — **new**, 8 cases.
  Run on a clone of ``gensec_phase27.bundle``: **6 red, 2 green**,
  every red an ``AssertionError``, not one ``ImportError``.  The two
  greens are declared guards, labelled as such in the file, and are no
  evidence of repair — one pins the linear discriminator, the other
  pins the open F6 disagreement so it cannot be closed by accident;
* ``tests/`` — the four ``debug_check_affine=True`` call sites in the
  Phase-7 validator and the default in ``test_phase7_sls.py``;
* ``tools/element_class_reasons.py``, ``tools/getattr_reasons.py`` —
  two reasons renamed and archived rather than deleted, and one
  ``getattr`` site archived with the reason it went: the per-fibre keep
  mask carried "has this fibre entered", which is now "has its zone
  entered", a question the zone bookkeeping already answers;
* ``.fingerprints/28_0*`` — PRE on a tree rebuilt from the bundle with
  the extended instrument verified byte-identical in both trees, POST
  on the repaired tree;
* ``handoff/`` — ledger, recap, and ``00_BOOTSTRAP.md`` updated in
  full.

What moved, and what did not
----------------------------
**38 numeric keys of 5764, 0 datum of 418, 0 domain of 31.**  0 keys
added, 0 removed on any of the three.

Every one of the 38 is under a key that declares a **curve**: 22
``sls.svc.*``, 14 ``sls_nl.svc.*``, one ``sls.selfcheck[svc]``
(``AssertionError`` -> ``passed``) and one
``sls_nl.consistency_flag`` (``debug_check_affine`` -> ``absent``).
Not one key under ``sls_nl.lin.*`` moved and not one of the 24
examples moved a single value: on a straight line the old stress
superposition and the new strain superposition are the same
arithmetic.  The datum and domain INERTs are explained rather than
accepted — neither instrument crosses ``verify_sls_staged``, which is
API-only since Phase 7 decision D5.

The measurement the phase turns on, on 400x1200 C35/45 at N = -1000 kN
and M = 900 kNm with ``ServiceConcrete`` declared: at its own defaults
the function did not complete, aborting on its own cross-check at
1.119e-01 MPa; with that disabled it reported the extreme tensile
fibre at **+37.007148 MPa** against f_ct,eff = 3.209962, a factor
11.5.  It now reports **+3.209962 MPa at y = 449.898 mm**, which is
the crack front: with the neutral axis at 382.4 mm and
eps_ct = 8.971e-05, 382.4 + 67.5 = 449.9.

Deliberately not closed
-----------------------
Hotfix **F6 on the check path**.  ``concrete_compression`` verifies the
stress at the outermost fibre's centroid while the record reports the
section face, and labels the verified value with the face's
coordinates -- 1.36 % non-conservative on the linear reference.  Held
open by decision (``28_0`` §2) and pinned by fixture.

Usage
-----
::

    python3 patchers/run_phase28_strain_accumulation.py --selfcheck
    python3 patchers/run_phase28_strain_accumulation.py --apply
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the Phase-27 patcher this one is lifted from stores
    the bytes as they are, and a second encoding would be a second
    thing to get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    src = SRC.read_text(encoding="utf-8")
    # The mechanism is lifted verbatim: everything above PAYLOAD and
    # everything from _verify_payload down.  Only the header docstring
    # and the two data blocks are authored here.
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
