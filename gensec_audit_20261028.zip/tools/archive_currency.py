#!/usr/bin/env python3
r"""
Is the delivered archive **current** with the tree it was built from?

The defect this tool answers
----------------------------
At the close of Phase 33 the tarball and the bundle inside it were both
written at 19:55; the last commit of the phase was made at 20:03.  The
delivered bundle carried ``HEAD = 1124536`` while the working tree was
at ``f1d5ec0``, so a correction to ``00_BOOTSTRAP.md`` and the patcher
that correction regenerates were **missing from the archive** (E33-4).

Every one of the four provenance checks passed.  They had to: they
compare the tarball with **its own** bundle, and those two were
consistent with each other and stale together.  The seven gates passed
too — none of them looks at the archive at all.  The discrepancy was
caught by hand, by reading mtimes, which is not a method.

The question no existing check asks is the one this tool asks:

    *is the HEAD of the bundle inside the delivered archive the same
    commit the working tree was on when the archive was built, and was
    that tree clean at the time?*

Both halves are needed, and they fail in opposite directions:

* a bundle **behind** the tree ships a phase missing its own last
  commits — E33-4 exactly;
* a bundle **ahead** of the tree means the tarball was rolled from a
  different, older checkout than the bundle describes;
* a **dirty** tree means the tarball carries files that no commit
  contains, so the bundle is not a description of what was shipped.

Usage
-----
::

    python tools/archive_currency.py --gate --archive dist/x.tar.gz
    python tools/archive_currency.py --gate --archive x.tar.gz --repo .
    python tools/archive_currency.py --falsify

``--gate`` exits **0** when the archive is current and **1** otherwise,
with a named diagnosis on the failing line.  The exit status is the
answer; read it from the process and never through a pipe (E30-9:
``cmd | grep ...; echo $?`` reads ``grep``'s status).

``--falsify`` builds a throwaway repository, an archive from it, and
then corrupts that archive in each of the three distinct ways above,
requiring the gate to reject each one **with the diagnosis that names
it**, plus a null control the gate must accept.  A gate that has not
been falsified on a deliberately corrupted tree has not yet been shown
to be able to fail.

Notes
-----
Untracked files are **not** counted as dirt, and the exclusion is
deliberate rather than an oversight.  A working tree in which the
example set has been run carries around 180 untracked ``.csv`` /
``.png`` outputs which no phase commits and which ``tar`` does not
pick up either, because the archive is rolled from an explicit file
list.  Counting them would make the gate red on every tree that has
been exercised, and a gate that is always red is a gate nobody reads
(the lesson of Z-16).  Tracked modifications are the ones that can
silently reach the tarball while the bundle denies them, and those are
counted.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile

#: Exit status of a passing gate, and of a failing one.  Named so that
#: a reader of a ``return`` statement below does not have to remember
#: which way round the shell convention runs.
PASS, FAIL = 0, 1


def _git(args, cwd):
    r"""
    Run one ``git`` command and return ``(status, stdout)``.

    The status is read from the process object, never from a pipeline,
    which is the whole point of returning it separately from the text.

    Parameters
    ----------
    args : list of str
        Arguments after ``git``.
    cwd : str
        Working directory of the call.

    Returns
    -------
    tuple
        ``(int, str)``.
    """
    proc = subprocess.run(["git"] + list(args), cwd=cwd,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True)
    return proc.returncode, proc.stdout.strip()


def _bundle_head(bundle_path):
    r"""
    The commit a bundle's ``HEAD`` points at.

    ``git bundle list-heads`` prints ``<sha> <ref>`` per line and needs
    no repository, which is what makes it usable on an archive that has
    only been unpacked.

    Parameters
    ----------
    bundle_path : str

    Returns
    -------
    str or None
        The 40-hex sha, or ``None`` if the bundle names no ``HEAD``.
    """
    code, out = _git(["bundle", "list-heads", bundle_path],
                     os.path.dirname(bundle_path) or ".")
    if code != PASS:
        return None
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] in ("HEAD", "refs/heads/master",
                                            "refs/heads/main"):
            return parts[0]
    return None


def _extract_bundle(archive_path, dest):
    r"""
    Pull the single ``*.bundle`` member out of an archive.

    Parameters
    ----------
    archive_path : str
    dest : str
        Directory to extract into.

    Returns
    -------
    tuple
        ``(path, diagnosis)``.  Exactly one of the two is ``None``: a
        diagnosis is returned instead of raising so that every failure
        of this gate reaches the same reporting line.
    """
    if not os.path.isfile(archive_path):
        return None, f"archive_missing: no such archive {archive_path!r}"
    try:
        with tarfile.open(archive_path, "r:*") as tar:
            members = [m for m in tar.getmembers()
                       if m.isfile() and m.name.endswith(".bundle")]
            if not members:
                return None, ("bundle_absent: the archive carries no "
                              "*.bundle member, so nothing in it "
                              "states which commit it is")
            if len(members) > 1:
                return None, (f"bundle_ambiguous: the archive carries "
                              f"{len(members)} bundles "
                              f"({[m.name for m in members]}); one "
                              f"archive states one commit")
            tar.extract(members[0], dest, filter="data")
            return os.path.join(dest, members[0].name), None
    except tarfile.TarError as exc:
        return None, f"archive_unreadable: {exc}"


def gate(archive_path, repo_dir):
    r"""
    The gate: is *archive_path* current with *repo_dir*?

    Parameters
    ----------
    archive_path : str
        The delivered ``.tar.gz``.
    repo_dir : str
        The working repository the archive was built from.

    Returns
    -------
    int
        :data:`PASS` or :data:`FAIL`.  Every failure prints one line
        beginning with a **named** diagnosis, because a gate that says
        only "failed" sends its reader looking in the wrong place.
    """
    code, tree_head = _git(["rev-parse", "HEAD"], repo_dir)
    if code != PASS:
        print(f"  FAIL  not_a_repository: {repo_dir!r} is not a git "
              f"working tree")
        print("GATE FAIL: the archive's currency cannot be decided.")
        return FAIL

    code, dirt = _git(["status", "--porcelain", "--untracked-files=no"],
                      repo_dir)
    if code != PASS:
        print("  FAIL  status_unreadable: git status did not run")
        print("GATE FAIL: the archive's currency cannot be decided.")
        return FAIL

    failures = []
    if dirt:
        n = len(dirt.splitlines())
        failures.append(
            f"tree_dirty: {n} tracked file(s) modified and not "
            f"committed at build time, so the tarball carries content "
            f"no commit contains and the bundle cannot describe it "
            f"({dirt.splitlines()[0]}...)")

    tmp = tempfile.mkdtemp(prefix="gensec_archive_currency_")
    try:
        bundle, diag = _extract_bundle(archive_path, tmp)
        if diag is not None:
            failures.append(diag)
            bundle_head = None
        else:
            bundle_head = _bundle_head(bundle)
            if bundle_head is None:
                failures.append(
                    "bundle_headless: the bundle names no HEAD, so it "
                    "states no commit to compare")
            elif bundle_head != tree_head:
                # Which side is stale?  ``merge-base --is-ancestor``
                # answers it, and the two answers need opposite
                # repairs: rebuild the archive, or rebuild it from the
                # right checkout.
                anc, _ = _git(["merge-base", "--is-ancestor",
                               bundle_head, tree_head], repo_dir)
                desc, _ = _git(["merge-base", "--is-ancestor",
                                tree_head, bundle_head], repo_dir)
                if anc == PASS:
                    n_code, n_out = _git(
                        ["rev-list", "--count",
                         f"{bundle_head}..{tree_head}"], repo_dir)
                    behind = n_out if n_code == PASS else "?"
                    failures.append(
                        f"bundle_behind: the delivered bundle is at "
                        f"{bundle_head[:7]} and the tree is at "
                        f"{tree_head[:7]}, {behind} commit(s) later. "
                        f"The archive was built before the last "
                        f"commit; everything in those commits is "
                        f"missing from it (E33-4)")
                elif desc == PASS:
                    failures.append(
                        f"bundle_ahead: the delivered bundle is at "
                        f"{bundle_head[:7]}, which is LATER than the "
                        f"tree at {tree_head[:7]}. The tarball was "
                        f"rolled from an older checkout than the "
                        f"bundle describes")
                else:
                    failures.append(
                        f"bundle_unrelated: bundle {bundle_head[:7]} "
                        f"and tree {tree_head[:7]} share no ancestry; "
                        f"they are not two states of one history")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print(f"  archive     {archive_path}")
    print(f"  tree HEAD   {tree_head}")
    print(f"  bundle HEAD {bundle_head if bundle_head else '(none)'}")
    print(f"  tracked modifications at build time: "
          f"{len(dirt.splitlines()) if dirt else 0}")
    for f in failures:
        print(f"  FAIL  {f}")
    if failures:
        print(f"GATE FAIL: {len(failures)} reason(s); the delivered "
              f"archive does not describe the tree it was built from.")
        return FAIL
    print("GATE PASS: the bundle in the archive is at the tree's HEAD, "
          "and the tree carried no uncommitted tracked change.")
    return PASS


# ---------------------------------------------------------------------
#  Falsification
# ---------------------------------------------------------------------

def _make_repo(root):
    r"""
    Build a throwaway two-commit repository.

    Returns
    -------
    tuple
        ``(repo_dir, first_sha, second_sha)``.
    """
    repo = os.path.join(root, "repo")
    os.makedirs(repo)
    _git(["init", "-q", "-b", "master"], repo)
    _git(["config", "user.email", "f@x"], repo)
    _git(["config", "user.name", "f"], repo)
    with open(os.path.join(repo, "a.txt"), "w") as fh:
        fh.write("one\n")
    _git(["add", "-A"], repo)
    _git(["commit", "-qm", "one"], repo)
    _, first = _git(["rev-parse", "HEAD"], repo)
    with open(os.path.join(repo, "a.txt"), "w") as fh:
        fh.write("two\n")
    _git(["add", "-A"], repo)
    _git(["commit", "-qm", "two"], repo)
    _, second = _git(["rev-parse", "HEAD"], repo)
    return repo, first, second


def _make_archive(repo, path, rev):
    r"""
    Roll an archive whose bundle is built at *rev*.

    Parameters
    ----------
    repo : str
    path : str
        Destination ``.tar.gz``.
    rev : str
        The revision the bundle is built from.  Passing a revision
        other than ``HEAD`` is how the falsification manufactures a
        stale archive without waiting eight minutes for a real one.
    """
    # A bundle at a revision other than the tip is built in a
    # throwaway clone reset to that revision, because ``git bundle
    # create`` publishes *refs*, not arbitrary revisions: there is no
    # ``<sha>:<ref>`` form, and inventing one silently produced an
    # empty bundle the first time this helper was written.
    work = tempfile.mkdtemp(prefix="gensec_stalebundle_")
    try:
        clone = os.path.join(work, "c")
        code, _ = _git(["clone", "-q", repo, clone], work)
        if code != PASS:
            raise RuntimeError("could not clone the bench repository")
        _git(["checkout", "-q", "master"], clone)
        if rev != "HEAD":
            code, _ = _git(["reset", "--hard", "-q", rev], clone)
            if code != PASS:
                raise RuntimeError(f"could not reset to {rev!r}")
        bundle = os.path.join(work, "t.bundle")
        code, _ = _git(["bundle", "create", "-q", bundle,
                        "--all", "HEAD"], clone)
        if code != PASS:
            raise RuntimeError(f"could not build a bundle at {rev!r}")
        with tarfile.open(path, "w:gz") as tar:
            tar.add(bundle, arcname="pkg/t.bundle")
            tar.add(os.path.join(repo, "a.txt"), arcname="pkg/a.txt")
    finally:
        shutil.rmtree(work, ignore_errors=True)


def falsify():
    r"""
    Corrupt an archive three distinct ways and require rejection.

    The three are the three ways an archive can fail to describe its
    tree, and each carries its own named diagnosis so that a rejection
    for the wrong reason is not counted as a success.  A null control
    — an archive built correctly — must be **accepted**, without which
    a gate that rejects everything would score four out of four.

    Returns
    -------
    int
        :data:`PASS` if all four verdicts are as required.
    """
    import contextlib
    import io

    def verdict(archive, repo):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = gate(archive, repo)
        return code, buf.getvalue()

    results = []
    root = tempfile.mkdtemp(prefix="gensec_currency_falsify_")
    try:
        repo, first, second = _make_repo(root)

        # -- null control: bundle at HEAD, tree clean -----------------
        ok_archive = os.path.join(root, "ok.tar.gz")
        _make_archive(repo, ok_archive, "HEAD")
        code, out = verdict(ok_archive, repo)
        results.append(("null_control", "accept",
                        "accept" if code == PASS else "reject", out))

        # -- 1: bundle one commit behind (E33-4) ---------------------
        behind = os.path.join(root, "behind.tar.gz")
        _make_archive(repo, behind, first)
        code, out = verdict(behind, repo)
        results.append(("bundle_behind", "reject",
                        "reject" if code == FAIL else "accept", out))

        # -- 2: bundle one commit ahead ------------------------------
        # Same two commits, tree rolled back to the first.
        _git(["checkout", "-q", first], repo)
        ahead = os.path.join(root, "ahead.tar.gz")
        _make_archive(repo, ahead, second)
        code, out = verdict(ahead, repo)
        results.append(("bundle_ahead", "reject",
                        "reject" if code == FAIL else "accept", out))
        _git(["checkout", "-q", "master"], repo)

        # -- 3: dirty tree -------------------------------------------
        with open(os.path.join(repo, "a.txt"), "w") as fh:
            fh.write("uncommitted\n")
        code, out = verdict(ok_archive, repo)
        results.append(("tree_dirty", "reject",
                        "reject" if code == FAIL else "accept", out))
        _git(["checkout", "--", "a.txt"], repo)
    finally:
        shutil.rmtree(root, ignore_errors=True)

    bad = 0
    for name, want, got, out in results:
        named = name in out or name == "null_control"
        ok = (want == got) and named
        bad += 0 if ok else 1
        why = "" if named else "  (rejected, but not by its own name)"
        print(f"  {name:16s} {want:7s} {got:7s} "
              f"{'OK' if ok else 'MISS'}{why}")
    if bad:
        print(f"FALSIFICATION FAIL: {bad} case(s) did not behave as "
              f"required.")
        return FAIL
    print(f"FALSIFICATION PASS: {len(results) - 1} corruptions "
          f"rejected, each by its own diagnosis, null control "
          f"accepted.")
    return PASS


def main(argv):
    r"""
    Command line.

    Parameters
    ----------
    argv : list of str

    Returns
    -------
    int
        Process exit status.
    """
    ap = argparse.ArgumentParser(
        description="Is the delivered archive current with its tree?")
    ap.add_argument("--gate", action="store_true",
                    help="compare the archive's bundle with the tree")
    ap.add_argument("--falsify", action="store_true",
                    help="corrupt an archive three ways and require "
                         "rejection, plus a null control")
    ap.add_argument("--archive", help="path to the delivered .tar.gz")
    ap.add_argument("--repo", default=".",
                    help="the working repository (default: .)")
    args = ap.parse_args(argv)

    if args.falsify:
        return falsify()
    if args.gate:
        if not args.archive:
            ap.error("--gate needs --archive; there is no default "
                     "archive and guessing one would be the kind of "
                     "silent choice this repository does not make")
        return gate(args.archive, args.repo)
    ap.print_help()
    return FAIL


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
# GENSEC-COMPLETE phase=34 utc=2026-09-06T10:33:16Z sha256=55281ff1f396c1b7cdce8a8f53e926008b2090ab4610481ad8c9a6a51bfd8b57 body_lines=473
