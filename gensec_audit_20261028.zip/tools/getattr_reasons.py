# SPDX-License-Identifier: AGPL-3.0-or-later
# GenSec — reinforced/prestressed concrete sectional analysis.
# Copyright (C) 2026  Andrea (GenSec project).
r"""
The reasons behind the **substituting** ``getattr`` sites.

Why this file exists
--------------------
``tools/getattr_inventory.py`` measures every ``getattr`` in the package
and sorts it into four classes.  Its gate, from Phase 17 to Phase 19,
enforced exactly one rule: no *substituting* site on the machine-readable
dump path.  That rule is right and stays.  It is also narrow: it says
nothing about the **125 substituting sites everywhere else**, and a green
gate was being read as though it did.

That is the shape of N-9 one level further out, and the shape that
produced F-P00-1: *a substituting default that never substitutes is
invisible until the day it substitutes*.  The rule that came out of N-9 —
**an absolution by category does not absolve a member** — applies here
unchanged.  Four class names do not close 125 sites.

So this file does for ``getattr`` what
``tools/element_class_reasons.py`` does for the element-class inventory:
one reason per site, in the tree, under a gate.

What is different, and deliberately so
--------------------------------------
``element_class_reasons.py`` could be completed in one phase because it
had 190 sites already triaged in prose.  These 125 have not been read at
all.  Reading 125 call sites line by line does not fit in a phase that
also closes N-17, and pretending otherwise would produce the one outcome
worth avoiding: a gate that passes because nobody looked.

Hence the second table, :data:`UNREAD`.  A site may be **read** (an entry
in :data:`REASONS`) or **declared unread** (an entry in :data:`UNREAD`).
It may not be neither.  The gate refuses a site that is in no table, so
a new substituting site cannot enter the package silently, and
``--gate`` prints the residual count on every invocation so the debt is
never invisible.

``UNREAD`` is not an absolution.  It is a receipt.

The taxonomy of reasons
-----------------------
Each reason opens with a tag naming *what kind of thing* absolves the
site.  A site whose tag does not fit is a site that has not been read.

===============  =====================================================
tag              the claim
===============  =====================================================
``DEAD``         the attribute is set unconditionally by the declared
                 owner's ``__init__``, so on every object that reaches
                 this site the default is never taken.  **Measured**,
                 not asserted: ``--presence`` reports the count of
                 objects carrying the attribute out of the objects the
                 distributed examples produce.  A ``DEAD`` reason with
                 a presence below 100 % is a contradiction and the
                 tool says so
``DUCK``         the site is deliberately polymorphic: it accepts
                 objects of more than one type, and the default is the
                 answer for the types that do not carry the attribute.
                 The alternative types are named
``OPTIONAL``     the attribute is genuinely optional in the declared
                 schema; absence is a modelling choice, and the default
                 is the documented meaning of that choice
``COSMETIC``     the value reaches a label, a colour or an axis limit
                 and nothing else.  A wrong default changes what a
                 figure looks like and no number
``GUARDED``      the default is taken, and the value is validated or
                 raised on downstream before it can reach a
                 computation.  The guard is named
``DEFECT``       **not absolved** — the default can reach a number, and
                 the item id is given
===============  =====================================================

Notes
-----
The key is ``"<relpath>:<qualname>:<attr>#<ordinal>"``.  The ordinal
distinguishes several sites that share a module, a function and an
attribute name but not a default — ``posttension.py:_stressing_view``
has two ``bulk_eps_init`` sites with different defaults, and collapsing
them would absolve one by reading the other.  Line numbers are
deliberately **not** in the key: they drift under edits that change
nothing, and a key that drifts trains its reader to re-baseline without
looking.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

#: Reason per site, keyed as described in the module docstring.
REASONS: Dict[str, str] = {}


def _add(entries: Dict[str, str]) -> None:
    r"""
    Merge *entries* into :data:`REASONS`, refusing a duplicate key.

    Parameters
    ----------
    entries : dict

    Raises
    ------
    KeyError
        On a duplicate key, which would mean one reason silently
        replacing another.
    """
    for key, value in entries.items():
        if key in REASONS:
            raise KeyError(f"duplicate reason for {key!r}")
        REASONS[key] = value


# ======================================================================
#  solver/integrator.py — 13 sites.
#
#  Read first, and read whole, because this is the module the fiber
#  method runs through: every number GenSec publishes passes here.  It
#  is also the module in which Phase 16 found N-1/N-2 and Phase 19
#  found N-15, so nothing in it is absolved by family.
# ======================================================================

_add({
 "solver/integrator.py:FiberSolver.__init__:y_tendons#0":
   "DEAD: GenericSection.__init__ assigns y_tendons unconditionally, "
   "as an array that is empty when the section declares no tendons.  "
   "The default np.empty(0) is therefore the same object-shape the "
   "attribute already has in the no-tendon case, and is never taken.  "
   "It is not harmless to leave: the day a section-like object without "
   "the attribute reaches FiberSolver, this line invents a tendon-free "
   "section instead of failing, and every tendon force silently "
   "vanishes from N and Mx.  Kept for now because removing it is a "
   "behaviour change on the solver's constructor and belongs in a "
   "phase that can measure it; recorded so the choice is visible.",
 "solver/integrator.py:FiberSolver.__init__:x_tendons#0":
   "DEAD: the x-twin of the y_tendons site above, same owner, same "
   "assignment, same measured presence, same standing.",
 "solver/integrator.py:FiberSolver.__init__:eps_init_tendons#0":
   "DEAD: eps_init_tendons is assigned by GenericSection.__init__ "
   "alongside x_tendons/y_tendons and carries the locked-in strain "
   "eps_init of each tendon.  This is the most consequential of the "
   "three: eps_init enters the section strain as eps_sec = eps_p - "
   "eps_init, so a substituted empty array would not merely drop the "
   "tendons, it would drop the PRESTRESS while keeping the tendon "
   "areas if the other two arrays were present.  Measured present on "
   "every object the distributed examples build.",
 "solver/integrator.py:FiberSolver.__init__:bulk_eps_init#0":
   "DEAD: bulk_eps_init is a class attribute of GenericSection with "
   "the value 0.0, so the default here restates a declared default "
   "rather than inventing one.  This is the one site of the four in "
   "this constructor where the default and the owner's own value are "
   "the same fact written twice, which is the milder failure: it "
   "cannot produce a wrong number, only a second home for one fact.",
 "solver/integrator.py:FiberSolver._build_rebar_groups:mat_indices_rebar#0":
   "DUCK: the attribute exists on GenericSection but the None default "
   "is load-bearing and is IMMEDIATELY tested — the branch below reads "
   "'if mat_idx_r is None: single material on all rebars'.  A "
   "single-material section legitimately carries None here, so this is "
   "a two-valued schema (array or None) and not a missing attribute.  "
   "Reclassifying it as a probe would be wrong too: the value flows on "
   "into the grouping when it is not None.",
 "solver/integrator.py:FiberSolver._build_tendon_groups:mat_indices_tendon#0":
   "DUCK: the tendon twin of _build_rebar_groups above, same "
   "two-valued schema, same immediate branch.",
 "solver/integrator.py:FiberSolver._build_bulk_groups:mat_indices#0":
   "DUCK: the bulk twin of the two above.  None means 'one material "
   "over the whole bulk', which is the common case and not an "
   "absence.",
 "solver/integrator.py:FiberSolver._build_offset_fields:bulk_planes_active#0":
   "OPTIONAL: measured ABSENT on a plain GenericSection and present "
   "only on the materialised views StagedDomainManager produces.  This "
   "is therefore a live default, taken on every non-staged section, "
   "and it is the documented meaning of the absence: a section with no "
   "construction history has no per-plane activation mask.  The one "
   "site in this module where the default is genuinely exercised in "
   "normal operation.",
 "solver/integrator.py:FiberSolver._build_offset_fields:mat_indices#0":
   "DUCK: same two-valued schema as _build_bulk_groups, read here for "
   "the offset field rather than the grouping.  Not a second home for "
   "the fact — it reads the same attribute, it does not recompute it.",
 "solver/integrator.py:FiberSolver._build_offset_fields:mat_indices_rebar#0":
   "DUCK: as _build_rebar_groups, read for the offset field.",
 "solver/integrator.py:FiberSolver._build_offset_fields:mat_indices_tendon#0":
   "DUCK: as _build_tendon_groups, read for the offset field.",
 "solver/integrator.py:FiberSolver._tendon_forces:embedded_tendons#0":
   "DEAD: embedded_tendons is assigned by GenericSection.__init__ as a "
   "boolean mask over the tendon set.  The default np.ones(..., "
   "dtype=bool) declares every tendon embedded, which is the "
   "conservative direction for the bulk subtraction — an embedded "
   "tendon has the bulk stress at its position subtracted to avoid "
   "double counting.  If it ever substituted on a section with "
   "EXTERNAL tendons the subtraction would be applied where there is "
   "no bulk to subtract, and the tendon force would come out too "
   "small.  N-16 was the same element class going missing from a "
   "different quantity; this is where it would go missing from the "
   "force itself.",
 "solver/integrator.py:FiberSolver._elastic_initial_guess:ideal_gross_area#0":
   "GUARDED: ideal_gross_area is assigned by GenericSection.__init__, "
   "so the default is dead in normal operation; and were it taken, the "
   "substituted B*H feeds only the ELASTIC INITIAL GUESS of the "
   "Newton-Raphson driver.  The guard is convergence itself: the "
   "returned plane is accepted only after the residual test in "
   "_nr_uniaxial, so a poor starting point costs iterations and cannot "
   "produce a wrong answer.  The same expression appears in "
   "capacity.py three times, and that repetition is the real finding "
   "here — one fact, four homes.",
})


# ======================================================================
#  solver/capacity.py — 7 sites.
# ======================================================================

_add({
 "solver/capacity.py:NMDiagram.__init__:fcd#0":
   "DUCK: 'b' here is the bulk material, and fcd is defined by the "
   "concrete classes and not by the elastic or tabulated ones.  The "
   "None default is the answer for a bulk material that has no design "
   "strength, and the consumers below test it before use.  A section "
   "whose bulk is a generic elastic material is a supported model, so "
   "this is polymorphism and not an absence.",
 "solver/capacity.py:NMDiagram._vectorized_solve_N:ideal_gross_area#0":
   "GUARDED: the second of the four homes of 'sec.B * sec.H'.  Dead on "
   "every GenericSection, and where it feeds a result it feeds a "
   "normalisation of the axial force used to seed the search, not the "
   "force itself.  Recorded as a duplicate-definition finding rather "
   "than a defect: one fact should have one home, and this fact has "
   "four (integrator.py once, capacity.py three times).",
 "solver/capacity.py:NMDiagram._zone_cracking_strain:ec2#0":
   "DUCK: a bulk material either carries an EC2 property object or "
   "does not, and both are supported declarations.  The None default "
   "is exactly the case N-3 measured: a concrete declared with a bare "
   "fck has no ec2 object, the cracking strain cannot be resolved, and "
   "the key reads 'no_ec2_properties'.  So the default here does NOT "
   "silently substitute a number — it routes to a NAMED refusal, which "
   "is the behaviour the rest of the project asks for.",
 "solver/capacity.py:NMDiagram._zone_cracking_strain:fctm#0":
   "DUCK: read off the ec2 object resolved by the site above, with the "
   "same two-valued outcome and the same named refusal downstream.",
 "solver/capacity.py:NMDiagram._zone_cracking_strain:ecm#0":
   "DUCK: the modulus half of the eps_cr = f_ctm / E_cm pair, same "
   "resolution and same refusal as fctm above.",
 "solver/capacity.py:NMDiagram._zone_cracking_strain:eps_ct#0":
   "OPTIONAL: a material may declare its tensile strain limit "
   "directly, in which case eps_ct is used in preference to the EC2 "
   "derivation.  Absence is the ordinary case and means 'derive it', "
   "which is what the branch below does.",
 "solver/capacity.py:NMDiagram._scan_chi:ideal_gross_area#0":
   "GUARDED: the third and fourth homes of 'sec.B * sec.H' sit in this "
   "function and _vectorized_solve_N.  Same standing as those, and the "
   "same finding: this expression wants one home.",
})


# ======================================================================
#  solver/analysis.py, solver/prestress_transfer.py — 2 sites.
# ======================================================================

_add({
 "solver/analysis.py:AnalysisEngine._decompose:embedded_tendons#0":
   "DEAD: the decomposition twin of the _tendon_forces site in "
   "integrator.py, with the identical default and the identical "
   "consequence if it ever substituted — an external tendon reported "
   "with the bulk contribution subtracted from it.  The two sites "
   "compute the same mask from the same attribute in two places, which "
   "is the duplicate-definition pattern again; N-13 lived in this "
   "function for the material name map and was closed in Phase 18.",
 "solver/prestress_transfer.py:solve_pretension_transfer:tendons#0":
   "DEAD: GenericSection.__init__ assigns tendons as a list, empty "
   "when none are declared.  Substituting [] would make the transfer "
   "solver report a section with no prestress to transfer and return "
   "silently, which is the worst available failure for this routine: "
   "there is no other signal that the tendons were dropped.",
})


# ======================================================================
#  materials/concrete.py, materials/rheology.py — 6 sites.
#
#  Read together because they are two homes of ONE decision: which
#  modulus answers for a concrete.  Reading either alone would have
#  absolved the duplication.
# ======================================================================

_add({
 "materials/concrete.py:Concrete.reference_modulus:code#0":
   "OPTIONAL: the declaration stamp. io_yaml sets .code on every "
   "material it builds; a Concrete constructed directly in Python "
   "carries none, and the None default routes to the inference below "
   "-- an EC2 property object present means the EC2 bridge built it, "
   "which IS a declaration, and its absence means UNDECLARED, which "
   "declines. The default therefore never produces a NUMBER: it "
   "selects between a declaration and a refusal, and both say which "
   "code they are.",
 "materials/codes.py:NormativeCode._fck_of:fck#0":
   "DUCK: the one home for 'does this material state a characteristic "
   "strength'. Every code subclass reads f_ck through it rather than "
   "with its own getattr, so the question is asked once and answered "
   "once. A steel, a tabulated law and a user law all legitimately "
   "have no f_ck; None is the answer for them and the caller turns it "
   "into a named refusal, never into a modulus.",
 "materials/codes.py:EC2Code.reference_modulus:ec2#0":
   "DUCK: a concrete either carries an EC2 property object or does "
   "not, and both are supported declarations. The None default routes "
   "to the f_ck derivation below, which is the same clause through "
   "the same provider -- one formula, one home -- and not to a "
   "substituted value.",
 "materials/codes.py:EC2Code.reference_modulus:ecm#0":
   "DUCK: read off whatever the site above resolved. The chained "
   "getattr is what makes both safe: the outer is reachable only when "
   "the inner produced None, and the pair is tested as a unit before "
   "either is used.",
 "materials/codes.py:EC2Code.design_reduction:gamma_c#0":
   "OPTIONAL: a partial factor is declared or it is not, and the "
   "None default is passed straight through into DesignReduction as "
   "None -- never as 1.0. The distinction is load-bearing: 'this "
   "material declares no gamma_c' and 'this material declares "
   "gamma_c = 1' are different statements, and a caller that divided "
   "by a substituted 1.0 would turn the first silently into the "
   "second. _pos() enforces it by returning None for a non-positive "
   "or unparseable value rather than clamping.",
 "materials/codes.py:EC2Code.design_reduction:gamma_s#0":
   "OPTIONAL: the reinforcement twin of gamma_c above, same "
   "reasoning. Absent on a bulk-only material, which is the ordinary "
   "case and not a defect.",
 "materials/codes.py:EC2Code.design_reduction:gamma_p#0":
   "OPTIONAL: the prestressing twin. Absent on every material that "
   "is not a prestressing steel, so this default is TAKEN in normal "
   "operation -- one of the few here that is -- and the None it "
   "yields is the documented meaning of the absence.",
 "solver/integrator.py:_yield_strain_of:Ep#0":
   "DUCK: the site is deliberately polymorphic across the two steel "
   "families. A rebar carries Es, a strand carries Ep, and the "
   "or-chain reads whichever the material has. Neither default can "
   "reach a number: if both are absent the function returns None, "
   "and a capacity factor written against a yield strain declines "
   "rather than being evaluated against an invented one.",
 "solver/integrator.py:_yield_strain_of:f_p01d#0":
   "DUCK: the strength half of the same polymorphic pair -- fyd for "
   "a rebar, f_p01d for a strand -- with the same None outcome and "
   "the same refusal downstream.",
 "solver/integrator.py:FiberSolver.sectional_state:y_fibers#0":
   "OPTIONAL: the extreme compression strain is reported only when "
   "the section exposes a fibre census. The None default routes to "
   "eps_c = None, which is an ABSENCE and not a zero -- zero is a "
   "strain, absence is not -- and a code that needs the compression "
   "strain must decline on None rather than read it as unstrained.",
 "materials/rheology.py:EC2ReferenceModulus.E_c:ec2#0":
   "DUCK: the same three-site pattern as Concrete.reference_modulus, "
   "in the rheology provider rather than on the material.  **This "
   "duplication is the finding.**  Two implementations of 'which "
   "modulus answers for this concrete' is two homes for one normative "
   "fact, and the project's own rule is that a normative formula has "
   "one home.  Not repaired here: merging them changes which object "
   "owns the decision, which is an architecture choice for Andrea and "
   "not a triage outcome.",
 "materials/rheology.py:EC2ReferenceModulus.E_c:ecm#0":
   "DUCK: as the ecm site in Concrete.reference_modulus, and the same "
   "duplication finding.",
 "materials/rheology.py:EC2ReferenceModulus.E_c:fck#0":
   "GUARDED: as the fck site in Concrete.reference_modulus, and the "
   "same duplication finding.",
})


# ======================================================================
#  The register of sites NOT yet read.
# ======================================================================

#: Sites acknowledged as unread, with the module they live in and a note
#: on what reading them will require.  A site here is **not** absolved;
#: it is on record as owing an explanation.  The gate counts these and
#: prints the count on every invocation, so the debt cannot become
#: invisible by being ignored.
#:
#: The order is the order the next phase should read them in, and the
#: ordering rule is consequence, not convenience: a default that can
#: reach a published number first, a default that can reach a figure
#: last.
UNREAD: Dict[str, str] = {}


def _unread(module: str, count: int, note: str) -> None:
    r"""
    Declare a whole module's substituting sites as unread.

    Parameters
    ----------
    module : str
        Package-relative POSIX path.
    count : int
        Number of substituting sites in it at the time of declaration.
        Recorded so that a module which GROWS a site cannot hide the
        new one behind the old debt: the gate compares the count.
    note : str
        What reading this module will take.
    """
    if module in UNREAD:
        raise KeyError(f"duplicate unread declaration for {module!r}")
    UNREAD[module] = f"{count}|{' '.join(note.split())}"


_unread(
    "solver/section_state.py", 19,
    "The staged machinery, and the largest single block.  Reading it "
    "needs the object census first: these sites take base sections, "
    "SectionState objects and materialised views interchangeably, so "
    "'the attribute is always present' has to be established on three "
    "types and not one.  Highest consequence of the remaining set: "
    "geometry_signature feeds capacity_hash.")
_unread(
    "solver/sls.py", 19,
    "Serviceability.  Shares the three-type problem with "
    "section_state.py and adds a fourth object, the SLS view.  Several "
    "defaults here are ranges and empty arrays whose substitution "
    "would shorten a loop rather than raise, which is the silent kind. "
    "19 -> 18 in Phase 28: see getattr_reasons.REMOVED for the site "
    "that went and why.  18 -> 19 in Phase 32: the per-zone concrete "
    "check reads f_ck from the zone's DECLARED material, and the "
    "default is None on purpose -- a zone whose bulk material is not "
    "a concrete has no characteristic strength, which is an ordinary "
    "state and produces a 'skipped' entry naming the lever, never a "
    "silent pass.  Substituting the attribute would be the silent "
    "kind; returning None is what makes the branch reportable.")
_unread(
    "solver/losses.py", 8,
    "Loss computation.  Four of the eight read EC2 prestressing-steel "
    "properties off an ec2 bridge and look like the DUCK pattern "
    "already read in capacity.py; that resemblance is a hypothesis to "
    "test, not a reason, and copying the reason across would be the "
    "absolution-by-category this file exists to refuse.")
_unread(
    "solver/posttension.py", 7,
    "Post-tensioning.  Two bulk_eps_init sites in one function with "
    "different defaults, which is exactly the collision the key "
    "ordinal was designed for and needs both branches read.")
_unread(
    "solver/timeline.py", 6,
    "The construction timeline.  Two of the six are on the dump path "
    "and are already probes under the existing rule; the remaining "
    "four are element reads in _tendon_info, including a nested "
    "getattr(t, 'area', getattr(t, 'Ap', 0.0)) whose inner default is "
    "a separate site.")
_unread(
    "io_yaml.py", 8,
    "The loader.  These run against half-built sections during "
    "parsing, so the presence measurement taken on finished objects "
    "does not apply and a different instrument is needed.")
_unread(
    "materials/base.py", 9,
    "Identity and declared domains.  Three feed content_token and "
    "__qualname__ into the BLAKE2b digest, which is ratified "
    "architecture: a wrong default there changes a hash, and the "
    "reading has to establish that it cannot.")
_unread(
    "output/report.py", 7,
    "Text report.  Expected to be COSMETIC throughout, and that "
    "expectation is precisely why it is last: a family everyone "
    "expects to be harmless is the family nobody checks.")
_unread(
    "output/geometry_plot.py", 7,
    "Geometry figure.  Same expectation and same caution as "
    "report.py.")
_unread(
    "output/plots.py", 3,
    "Diagram figures.  Two substitute a bounding box computed from B "
    "and H, a fifth home for that expression.")
_unread(
    "api.py", 2,
    "The public façade.  Short, but it is the surface other code is "
    "written against.")
_unread(
    "geometry/geometry.py", 1,
    "Tendon parent resolution for staged sections.")
_unread(
    "output/_polydraw.py", 1,
    "Shapely geometry-type dispatch.")


def reason_for(key: str) -> Optional[str]:
    r"""
    The recorded reason for a substituting site, or ``None``.

    Parameters
    ----------
    key : str
        ``"<relpath>:<qualname>:<attr>#<ordinal>"``, exactly as
        ``getattr_inventory`` builds it.

    Returns
    -------
    str or None
        The reason, whitespace-collapsed to one line; ``None`` if the
        site has never been read.
    """
    value = REASONS.get(key)
    return None if value is None else " ".join(value.split())


def unread_for(module: str) -> Optional[Tuple[int, str]]:
    r"""
    The declared unread count and note for *module*, or ``None``.

    Parameters
    ----------
    module : str
        Package-relative POSIX path.

    Returns
    -------
    tuple of (int, str), or None
        ``(count, note)`` when the module is on the unread register.
    """
    value = UNREAD.get(module)
    if value is None:
        return None
    count, _, note = value.partition("|")
    return int(count), note


# ======================================================================
#  ARCHIVE — reasons for sites that are no longer in the tree.
#
#  Same rule as element_class_reasons.REPAIRED, and stated there in
#  full: a reason whose site disappears is MOVED here with the phase
#  that removed it.  Never deleted -- the reason is the record of why
#  the site existed and why it stopped needing to -- and never left in
#  REASONS, where --gate would report it as drift on every invocation.
#
#  The gate enforces the move: a key in REASONS naming a site the
#  inventory no longer finds fails --gate with the instruction.
# ======================================================================

REMOVED: Dict[str, str] = {
 "solver/sls.py:verify_sls_staged:_bulk_keep#0":
   "REMOVED in Phase 28 (D27-1).  It read the view's per-fibre keep "
   "mask so that the walk could mark which BASE fibres had entered "
   "the history, in a boolean array parallel to the per-fibre stress "
   "accumulator.  Both are gone: the accumulator is now one per-zone "
   "affine STRAIN field, the strain at a fibre is that field "
   "evaluated at the fibre, and 'has this fibre entered' is 'has its "
   "zone entered' -- a question the zone bookkeeping already answers "
   "without asking the view for anything.  The site was not deleted "
   "for being a getattr; it went because the fact it carried stopped "
   "being a separate fact.  Substituting sites in this file 19 -> 18.",
 "materials/concrete.py:Concrete.reference_modulus:ec2#0":
   "REMOVED in Phase 21 (F-P21-1). Concrete no longer derives its own "
   "modulus: it asks the NormativeCode it was declared under. The "
   "chained EC2 read moved to codes.EC2Code.reference_modulus, where "
   "it is correct because that class is NAMED EC2.",
 "materials/concrete.py:Concrete.reference_modulus:ecm#0":
   "REMOVED in Phase 21 (F-P21-1), with its twin above and for the "
   "same reason. Substituting sites over the phase: 125 -> 122 for "
   "the three concrete.py removals, then -> 126 with the four "
   "materials/codes.py sites the declaration itself introduces.",
 "materials/concrete.py:Concrete.reference_modulus:fck#0":
   "REMOVED in Phase 21 (F-P21-1).  It read fck as the fallback input "
   "for a concrete carrying no EC2 bridge, and the Phase 20 triage "
   "recorded it as GUARDED on the ground that 'a missing modulus is "
   "never invented here'.  That reading was correct about the ABSENCE "
   "of fck and wrong about its PRESENCE: when fck was there the "
   "function invented a modulus from EN 1992-1-1 Table 3.1, for a "
   "material whose declaration named no code.  Measured, the same "
   "f_ck under ACI 318-19 19.2.2.1 gives a value 33.9 % lower at C25 "
   "and 18.5 % lower at C40; and because the resolver asks the "
   "material before applying the build's rule, an installed ACI rule "
   "lost to the invented Eurocode value.  The site is gone: the "
   "material now declines with NormativeChoiceNotDeclared and the "
   "replaceable rule owns the choice.  Substituting sites 125 -> 124.",
}


def removed_reason_for(key: str) -> Optional[str]:
    r"""
    The archived reason for a site no longer in the tree.

    Parameters
    ----------
    key : str
        ``"<relpath>:<qualname>:<attr>#<ordinal>"``.

    Returns
    -------
    str or None
    """
    value = REMOVED.get(key)
    return None if value is None else " ".join(value.split())
# GENSEC-COMPLETE phase=32 utc=2026-09-05T13:56:13Z sha256=bbfa9c462f7f9aabc236510380f134e471005c6ea115f2ab7cd145859fd4a613 body_lines=589
