r"""
Element-class inventory — which consumers enumerate which element classes.

Why this exists
---------------
Phase 15 closed F-M3 by finding **six** sites, not the four that had been
named, and the sixth was of a different class entirely.  The lesson was
not "look harder": it was that an inventory produced by reading is an
opinion, and an inventory produced by a program is a measurement that the
next phase can re-run and compare.

A GenSec section carries three classes of element:

=========  ==========================================  ====================
class      collection on the section                   fiber-level carrier
=========  ==========================================  ====================
bulk       ``zones`` / ``bulk_materials``              ``fibers``
rebar      ``rebars`` / ``rebar_groups``               point areas
tendon     ``tendons``                                 point areas
=========  ==========================================  ====================

Every consumer downstream of the solver that walks *element classes* --
to decompose a resultant, to test a strain against a limit, to draw, to
serialise -- must either enumerate all three or state why it does not.
A consumer that enumerates two of the three and says nothing about the
third is **blind by construction**, and the blindness is invisible in
review precisely because the code that is missing is not there to read.

What this measures
------------------
For every function and method in ``src/gensec`` the tool counts, by AST
walk, the identifiers and attribute names that belong to each class
vocabulary.  It then reports every function whose signature over the
three classes is *partial*: at least one class present, at least one
absent.

A partial signature is **not** a defect by itself -- a function that
computes the concrete-only cracking strain should mention bulk and
nothing else.  It is a site that owes an explanation.  The tool's job is
to hand the list to a human, not to judge it.

Usage
-----
::

    python tools/element_class_inventory.py            # full report
    python tools/element_class_inventory.py --gate     # exit 1 on drift
    python tools/element_class_inventory.py --baseline # rewrite baseline

The gate compares against ``tools/element_class_baseline.txt``.  A new
partial site must be justified or removed, exactly as a new
``getattr``-with-default must be.

The baseline format (Phase 18)
------------------------------
Each line is a signature **and its reason**::

    solver/sls.py:_extreme_fibre B--                 # SUBJECT: the extreme ...

A line carrying a signature and no ``#`` reason is **refused** by
``--gate``, and ``--baseline`` refuses to write one.  Until Phase 18 the
baseline was 191 bare signatures, and the reasons lived in a prose
handoff (``17_2``) where 77 of them were *category* absolutions — true
statements about a family that say nothing about a member.  That is the
form ``17_0 §7`` forbids, and it is where Phase 16 and Phase 18 found
N-1, N-2, N-13 and N-14.  The reasons now live in
:mod:`element_class_reasons`, in the tree, under the gate.

Notes
-----
The vocabularies are deliberately *lexical*.  A semantic analysis would
need a type checker and would still miss a duck-typed collection; a
lexical one over-reports, and over-reporting is the safe direction for
an instrument whose failure mode is silence.
"""

from __future__ import annotations

import argparse
import ast
import os
import sys
from typing import Dict, List, Set, Tuple

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src", "gensec")
BASELINE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "element_class_baseline.txt")

#: Lexical vocabulary of each element class.  Matched against identifier
#: names, attribute names and string constants, case-insensitively, as
#: whole words or as ``_``-separated components.
VOCAB: Dict[str, Tuple[str, ...]] = {
    "bulk": ("bulk", "zone", "zones", "concrete", "fiber", "fibers",
             "bulk_materials", "zone_names"),
    "rebar": ("rebar", "rebars", "rebar_groups", "reinf", "reinforcement",
              "as_", "bars"),
    "tendon": ("tendon", "tendons", "strand", "strands", "prestress",
               "tendon_groups", "eps_pe"),
}

#: Modules whose job is *not* to consume solver output.  Their partial
#: signatures are structural, not evidence of a blind consumer.
EXCLUDE_DIRS = ("_docs_assets",)

#: Header written at the top of the baseline.  Lines starting with ``#``
#: are skipped by the parser, so the file explains itself to whoever
#: opens it without a tool.
_BASELINE_HEADER = (
    "# element-class baseline — one line per PARTIAL signature, and the\n"
    "# reason it is partial.  Written by\n"
    "#     python tools/element_class_inventory.py --baseline\n"
    "# from tools/element_class_reasons.py, which is where the reasons\n"
    "# are edited.  Do not hand-edit this file: --gate refuses a line\n"
    "# with a signature and no reason, and cross-checks every reason\n"
    "# against the table.\n"
    "#\n"
    "# Reason tags: SUBJECT UNION SLOT GEOMETRY MATERIAL PARSER RENDER\n"
    "#              REPORT CONFIG ENTRY DELEGATE HOMOGEN INERT DEFECT\n"
    "# See tools/element_class_reasons.py for what each one claims.\n"
)


def _tokens(name: str) -> Set[str]:
    r"""Split *name* into lower-case ``_``-separated components plus itself."""
    low = name.lower()
    out = {low}
    out.update(p for p in low.split("_") if p)
    return out


def _classes_of(node: ast.AST) -> Set[str]:
    r"""
    Which element-class vocabularies appear anywhere under *node*.

    Parameters
    ----------
    node : ast.AST
        Usually a :class:`ast.FunctionDef`.

    Returns
    -------
    set of str
        A subset of ``{'bulk', 'rebar', 'tendon'}``.
    """
    seen: Set[str] = set()
    for sub in ast.walk(node):
        names: List[str] = []
        if isinstance(sub, ast.Name):
            names.append(sub.id)
        elif isinstance(sub, ast.Attribute):
            names.append(sub.attr)
        elif isinstance(sub, ast.arg):
            names.append(sub.arg)
        elif isinstance(sub, ast.Constant) and isinstance(sub.value, str):
            names.append(sub.value)
        for nm in names:
            toks = _tokens(nm)
            for cls, words in VOCAB.items():
                if toks & set(words):
                    seen.add(cls)
    return seen


def scan_file(path: str) -> List[Tuple[str, int, str, Set[str]]]:
    r"""
    Every function in *path* with its element-class signature.

    Returns
    -------
    list of (relpath, lineno, qualified_name, classes)
    """
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    try:
        tree = ast.parse(src)
    except SyntaxError:                                  # pragma: no cover
        return []
    rel = os.path.relpath(path, SRC).replace(os.sep, "/")
    out = []

    def walk(node, prefix=""):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.ClassDef):
                walk(child, prefix + child.name + ".")
            elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                out.append((rel, child.lineno, prefix + child.name,
                            _classes_of(child)))
                walk(child, prefix + child.name + ".")

    walk(tree)
    return out


def inventory() -> List[Tuple[str, int, str, Set[str]]]:
    r"""Scan the whole package.  Sorted, so the report is diffable."""
    rows = []
    for base, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs
                   if d != "__pycache__" and d not in EXCLUDE_DIRS]
        for name in sorted(files):
            if name.endswith(".py"):
                rows.extend(scan_file(os.path.join(base, name)))
    rows.sort(key=lambda r: (r[0], r[1]))
    return rows


def partial(rows) -> List[Tuple[str, int, str, Set[str]]]:
    r"""The rows whose signature covers some classes but not all three."""
    return [r for r in rows if r[3] and len(r[3]) < 3]


def _sig(classes: Set[str]) -> str:
    r"""``B-T`` style signature: present initial, ``-`` for absent."""
    return "".join(c[0].upper() if c in classes else "-"
                   for c in ("bulk", "rebar", "tendon"))


def _key(row) -> str:
    return f"{row[0]}:{row[2]} {_sig(row[3])}"


def _site(row) -> str:
    r"""``<relpath>:<qualname>`` — the key of the reasons table."""
    return f"{row[0]}:{row[2]}"


#: Column at which the reason starts, so the baseline stays diffable.
_REASON_COL = 78


def _reasons_module():
    r"""
    Import :mod:`element_class_reasons` from beside this file.

    Returns
    -------
    module

    Raises
    ------
    SystemExit
        If the reasons table is missing.  The gate cannot be satisfied
        without it, and an inventory whose reasons went missing must
        fail loudly rather than pass as "no reasons required".
    """
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import element_class_reasons as mod
    except ImportError as exc:                           # pragma: no cover
        raise SystemExit(
            f"element_class_inventory: cannot import the reasons table "
            f"({exc}).  tools/element_class_reasons.py is part of the "
            f"gate, not an optional extra: a baseline of bare signatures "
            f"is the form this gate exists to replace.")
    return mod


def _format_baseline_line(row, reason: str) -> str:
    r"""One baseline line: ``key SIG`` padded, then ``# reason``."""
    head = _key(row)
    pad = " " * max(2, _REASON_COL - len(head))
    return f"{head}{pad}# {' '.join(reason.split())}"


def _parse_baseline_line(line: str):
    r"""
    Split a baseline line into ``(key, reason)``.

    Returns
    -------
    key : str
        ``"<relpath>:<qualname> SIG"``, the drift key.
    reason : str
        Everything after the first ``#``, stripped.  **Empty string if
        the line carries no reason**, which is the condition the gate
        refuses — the whole point of the format.
    """
    body, sep, reason = line.partition("#")
    return body.strip(), (reason.strip() if sep else "")


def main(argv=None) -> int:
    r"""CLI entry point.  Returns the process exit code."""
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--gate", action="store_true",
                    help="exit 1 if the partial set drifted from baseline "
                         "or any baseline line carries no reason")
    ap.add_argument("--baseline", action="store_true",
                    help="rewrite the baseline file from the current tree")
    ap.add_argument("--tendon-blind", action="store_true",
                    help="only the sites that name bulk or rebar but "
                         "never a tendon")
    ap.add_argument("--reasons", action="store_true",
                    help="print each partial site with its reason")
    args = ap.parse_args(argv)

    rows = inventory()
    part = partial(rows)
    blind = [r for r in part if "tendon" not in r[3]
             and ({"bulk", "rebar"} & r[3])]

    if args.baseline:
        R = _reasons_module()
        unread = [_site(r) for r in part if R.reason_for(_site(r)) is None]
        if unread:
            print("REFUSING to write a baseline with unexplained sites:",
                  file=sys.stderr)
            for s in unread:
                print(f"  NO REASON  {s}", file=sys.stderr)
            print(f"\n{len(unread)} site(s) have no entry in "
                  f"element_class_reasons.REASONS.  Read them and add "
                  f"one; a bare signature is what this format replaced.",
                  file=sys.stderr)
            return 1
        with open(BASELINE, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(_BASELINE_HEADER)
            for r in part:
                fh.write(_format_baseline_line(
                    r, R.reason_for(_site(r))) + "\n")
        print(f"baseline rewritten: {len(part)} partial site(s), "
              f"each with a reason")
        return 0

    if args.reasons:
        R = _reasons_module()
        for r in part:
            print(f"  {_sig(r[3])}  {_site(r)}")
            print(f"        {R.reason_for(_site(r))}")
        return 0

    shown = blind if args.tendon_blind else part
    print(f"element-class inventory — {len(rows)} function(s) under "
          f"{os.path.relpath(SRC, ROOT)}")
    print(f"  full (B R T)      {sum(1 for r in rows if len(r[3]) == 3)}")
    print(f"  partial           {len(part)}")
    print(f"  tendon-blind      {len(blind)}   "
          f"(names bulk or rebar, never a tendon)")
    print()
    for r in shown:
        print(f"  {_sig(r[3])}  {r[0]}:{r[1]}  {r[2]}")

    if args.gate:
        if not os.path.exists(BASELINE):
            print("\nno baseline; run --baseline first.", file=sys.stderr)
            return 1
        base = {}
        unreasoned = []
        with open(BASELINE, encoding="utf-8") as fh:
            for ln in fh:
                ln = ln.rstrip("\n")
                if not ln.strip() or ln.lstrip().startswith("#"):
                    continue                      # header / blank
                key, reason = _parse_baseline_line(ln)
                if not key:
                    continue
                base[key] = reason
                if not reason:
                    unreasoned.append(key)
        now = {_key(r) for r in part}
        added, gone = sorted(now - set(base)), sorted(set(base) - now)

        # (1) the reason gate: a signature without a reason is refused,
        #     whether it drifted or not.
        if unreasoned:
            print()
            for u in unreasoned:
                print(f"  NO REASON  {u}")
            print(f"\ngate: {len(unreasoned)} baseline line(s) carry a "
                  f"signature and no reason.  A partial site is a site "
                  f"that owes an explanation; an unexplained one cannot "
                  f"reach a green tree.")
            return 1

        # (2) the drift gate, unchanged.
        if added or gone:
            print()
            for a in added:
                print(f"  ADDED    {a}")
            for g in gone:
                print(f"  REMOVED  {g}")
            print(f"\ndrift: +{len(added)} / -{len(gone)}")
            return 1

        # (3) every partial site must also be readable in the reasons
        #     table, so that a baseline edited by hand cannot outlive it.
        R = _reasons_module()
        unread = [_site(r) for r in part if R.reason_for(_site(r)) is None]
        if unread:
            print()
            for s in unread:
                print(f"  NO REASON  {s}  (baseline has one, table does not)")
            return 1

        # (4) the archive rule, decided in Phase 20.  A reason whose
        #     site stopped being partial belongs in REPAIRED, not in
        #     REASONS: see the ARCHIVE block in element_class_reasons.
        #     Leaving it in REASONS made --gate print a changelog that
        #     grows every phase, and a green output that is mostly
        #     history is a green output nobody reads.
        stale = sorted(k for k in R.REASONS
                       if k not in {_site(r) for r in part})
        if stale:
            print()
            for k in stale:
                print(f"  MOVE TO ARCHIVE  {k}")
            print(f"\ngate: {len(stale)} reason(s) in REASONS name a "
                  f"site the inventory no longer reports as partial. "
                  f"A repair is not a deletion: move the reason to "
                  f"element_class_reasons.REPAIRED with the phase "
                  f"that repaired it, so the record survives and the "
                  f"gate's output stays a signal.")
            return 1
        print(f"\ngate: no drift, {len(part)} site(s), every one with a "
              f"reason.")
        print(f"      {len(getattr(R, 'REPAIRED', {}))} archived "
              f"reason(s) for sites repaired in earlier phases "
              f"(element_class_reasons.REPAIRED).")
    return 0


if __name__ == "__main__":                               # pragma: no cover
    raise SystemExit(main())
