# SPDX-License-Identifier: AGPL-3.0-or-later
# GenSec — reinforced/prestressed concrete sectional analysis.
# Copyright (C) 2026  Andrea (GenSec project).
r"""
Inventory of every ``getattr`` call in the package, by risk class.

Why this tool exists
--------------------
``getattr(obj, "k", default)`` is a **silent** decision.  When the
attribute is there the call is invisible; when it is not, the default
takes its place and nothing in the output says so.  That is tolerable in
a plotting helper, where the consequence is a slightly different label.
It is not tolerable on the path of a **versioned dump**, where the
default becomes a number a future reader will take for a measurement,
with no way left to tell the two apart.  A silent default inside a
versioned contract is permanent.

So the rule this tool enforces is narrow and stated:

* on the dump path, ``getattr`` with a default is **forbidden**;
* everywhere else it is inventoried, classified and left alone.

The second half matters as much as the first.  A tool that flagged all
196 sites would be ignored by the second week; one that flags the
handful that can corrupt a contract is one somebody reads.

Classes
-------
``raising``
    Two-argument ``getattr(obj, "k")``.  Raises
    :class:`AttributeError` when absent.  Not a finding.
``dynamic``
    The attribute name is computed, not a literal.  Reported
    separately because the name cannot be reasoned about statically.
``probe``
    Three-argument, and the result is immediately tested for truth or
    identity (``if getattr(x, "k", None) is not None``).  This is a
    *question*, not a substitution: the default never reaches a
    computation.  Not a finding.
``substituting``
    Three-argument, and the default flows into a value.  This is the
    class the dump path must not contain.

Usage
-----
::

    python3 tools/getattr_inventory.py                 # whole package
    python3 tools/getattr_inventory.py --dump-path     # only the dump path
    python3 tools/getattr_inventory.py --gate          # exit 1 on a finding

Notes
-----
The dump path is declared in :data:`DUMP_PATH`, not inferred.  Inferring
it would mean following the call graph through ``getattr`` itself, which
is the thing being audited.
"""

from __future__ import annotations

import argparse
import ast
import os
import sys
from typing import Dict, Iterator, List, Optional, Tuple

#: Repository root, derived from this file's location.
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#: Package directory walked by the inventory.
_SRC = os.path.join(_ROOT, "src", "gensec")

#: Modules on the machine-readable dump path, as ``package``-relative
#: POSIX paths.  Declared, never inferred: the call graph would have to
#: be followed through ``getattr`` to infer it, which is circular.
#:
#: A module enters this list when the dump reads a value out of it, not
#: when the dump merely imports it.
DUMP_PATH: Tuple[str, ...] = (
    "output/timeline_dump.py",
    "solver/prestress_ledger.py",
)

#: Functions inside otherwise-off-path modules that the dump reads
#: through, as ``{module: (qualified function name, ...)}``.  The
#: photograph the dump serialises is written by ``_record_driver``, so
#: that function is on the path even though ``timeline.py`` as a whole
#: is not.
DUMP_PATH_FUNCTIONS: Dict[str, Tuple[str, ...]] = {
    "solver/timeline.py": (
        "ConstructionTimeline._record_driver",
        "ConstructionTimeline._reconcile_grout",
    ),
}


class Site:
    r"""
    One ``getattr`` call site.

    Parameters
    ----------
    path : str
        Package-relative POSIX path of the module.
    line : int
        1-based line number.
    func : str
        Dotted name of the enclosing class/function, or ``'<module>'``.
    attr : str or None
        The attribute name when it is a string literal, else ``None``.
    kind : str
        One of ``'raising'``, ``'dynamic'``, ``'probe'``,
        ``'substituting'``.
    default : str
        Source text of the default expression, or ``''``.
    """

    __slots__ = ("path", "line", "func", "attr", "kind", "default")

    def __init__(self, path: str, line: int, func: str,
                 attr: Optional[str], kind: str, default: str):
        self.path = path
        self.line = int(line)
        self.func = func
        self.attr = attr
        self.kind = kind
        self.default = default

    @property
    def on_dump_path(self) -> bool:
        r"""
        Whether this site sits on the machine-readable dump path.

        Returns
        -------
        bool
        """
        if self.path in DUMP_PATH:
            return True
        for module, funcs in DUMP_PATH_FUNCTIONS.items():
            if self.path == module and self.func in funcs:
                return True
        return False

    def __str__(self) -> str:
        name = repr(self.attr) if self.attr is not None else "<computed>"
        tail = f" -> {self.default}" if self.default else ""
        return (f"{self.path}:{self.line} [{self.kind}] "
                f"{self.func}: {name}{tail}")


class _Visitor(ast.NodeVisitor):
    r"""
    Collect ``getattr`` sites, tracking the enclosing scope.

    Parameters
    ----------
    path : str
        Package-relative POSIX path, used to label the sites.
    source : str
        Module source, used to recover default expressions verbatim.
    """

    def __init__(self, path: str, source: str):
        self.path = path
        self._lines = source.splitlines()
        self._scope: List[str] = []
        #: Nodes already classified as a truth/identity probe, by id.
        self._probes: set = set()
        self.sites: List[Site] = []

    # -- scope tracking ------------------------------------------------

    def visit_ClassDef(self, node):            # noqa: N802 (ast API)
        r"""Push the class name onto the scope stack."""
        self._scope.append(node.name)
        self.generic_visit(node)
        self._scope.pop()

    def visit_FunctionDef(self, node):         # noqa: N802 (ast API)
        r"""Push the function name onto the scope stack."""
        self._scope.append(node.name)
        self.generic_visit(node)
        self._scope.pop()

    visit_AsyncFunctionDef = visit_FunctionDef

    # -- probe detection -----------------------------------------------

    def visit_Compare(self, node):             # noqa: N802 (ast API)
        r"""
        Mark ``getattr(...) is None`` and friends as probes.

        A three-argument ``getattr`` whose result is immediately
        compared is asking a question; the default is the *absent*
        answer and never reaches a computation.
        """
        for operand in [node.left] + list(node.comparators):
            if self._is_getattr(operand):
                self._probes.add(id(operand))
        self.generic_visit(node)

    def visit_If(self, node):                  # noqa: N802 (ast API)
        r"""Mark ``if getattr(...)`` as a probe."""
        if self._is_getattr(node.test):
            self._probes.add(id(node.test))
        self.generic_visit(node)

    def visit_UnaryOp(self, node):             # noqa: N802 (ast API)
        r"""Mark ``not getattr(...)`` as a probe."""
        if isinstance(node.op, ast.Not) and self._is_getattr(node.operand):
            self._probes.add(id(node.operand))
        self.generic_visit(node)

    def visit_BoolOp(self, node):              # noqa: N802 (ast API)
        r"""Mark the non-final operands of ``and``/``or`` as probes."""
        for value in node.values[:-1]:
            if self._is_getattr(value):
                self._probes.add(id(value))
        self.generic_visit(node)

    @staticmethod
    def _is_getattr(node) -> bool:
        r"""
        Whether *node* is a ``getattr(...)`` call.

        Parameters
        ----------
        node : ast.AST

        Returns
        -------
        bool
        """
        return (isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "getattr")

    # -- the site itself -----------------------------------------------

    def visit_Call(self, node):                # noqa: N802 (ast API)
        r"""Record a ``getattr`` call site and recurse."""
        if self._is_getattr(node):
            self.sites.append(self._classify(node))
        self.generic_visit(node)

    def _classify(self, node) -> Site:
        r"""
        Build the :class:`Site` for a ``getattr`` call node.

        Parameters
        ----------
        node : ast.Call

        Returns
        -------
        Site
        """
        attr = None
        if len(node.args) >= 2 and isinstance(node.args[1], ast.Constant) \
                and isinstance(node.args[1].value, str):
            attr = node.args[1].value

        if len(node.args) < 3:
            kind = "raising" if attr is not None else "dynamic"
            default = ""
        elif attr is None:
            kind = "dynamic"
            default = self._segment(node.args[2])
        elif id(node) in self._probes:
            kind = "probe"
            default = self._segment(node.args[2])
        else:
            kind = "substituting"
            default = self._segment(node.args[2])

        func = ".".join(self._scope) or "<module>"
        return Site(self.path, node.lineno, func, attr, kind, default)

    def _segment(self, node) -> str:
        r"""
        Source text of *node*, collapsed to one line.

        Parameters
        ----------
        node : ast.AST

        Returns
        -------
        str
        """
        try:
            text = ast.get_source_segment("\n".join(self._lines), node)
        except Exception:                       # pragma: no cover
            text = None
        if not text:
            return "<?>"
        return " ".join(text.split())


def key_of(site: "Site", ordinal: int) -> str:
    r"""
    The stable key of a substituting site.

    ``"<relpath>:<qualname>:<attr>#<ordinal>"``.  The ordinal counts
    sites that share module, function *and* attribute name but not
    necessarily the same default — ``posttension.py:_stressing_view``
    holds two ``bulk_eps_init`` reads with different defaults, and one
    key for both would absolve one by reading the other.

    Line numbers are deliberately absent.  They move under edits that
    change nothing, and a key that drifts for no reason trains its
    reader to re-baseline without looking, which is the habit every
    gate in this tree exists to prevent.

    Parameters
    ----------
    site : Site
    ordinal : int
        0-based index within the ``(path, func, attr)`` group, in line
        order.

    Returns
    -------
    str
    """
    attr = site.attr if site.attr is not None else "<computed>"
    return f"{site.path}:{site.func}:{attr}#{ordinal}"


def keyed_substituting(sites: List["Site"]) -> List[Tuple[str, "Site"]]:
    r"""
    Every substituting site paired with its :func:`key_of`.

    Parameters
    ----------
    sites : list of Site
        The full inventory, in walk order (which is line order within
        a module).

    Returns
    -------
    list of (str, Site)
    """
    seen: Dict[Tuple[str, str, Optional[str]], int] = {}
    out: List[Tuple[str, Site]] = []
    for site in sites:
        if site.kind != "substituting":
            continue
        group = (site.path, site.func, site.attr)
        ordinal = seen.get(group, 0)
        seen[group] = ordinal + 1
        out.append((key_of(site, ordinal), site))
    return out


def _reasons_module():
    r"""
    Import ``getattr_reasons``, or fail loudly.

    The table is part of the gate, not an optional extra: an inventory
    of bare call sites is precisely the form this gate replaced.

    Returns
    -------
    module

    Raises
    ------
    SystemExit
        When the table cannot be imported, naming the cause.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import getattr_reasons as mod
    except ImportError as exc:                       # pragma: no cover
        raise SystemExit(
            f"getattr_inventory: cannot import the reasons table "
            f"({exc}).  tools/getattr_reasons.py is part of the gate: "
            f"without it every substituting site is unexplained and "
            f"the gate would pass on silence.")
    return mod


def audit(sites: List["Site"]):
    r"""
    Sort every substituting site into read, declared-unread, or owed.

    Parameters
    ----------
    sites : list of Site

    Returns
    -------
    read : list of str
        Keys with an entry in ``getattr_reasons.REASONS``.
    unread : list of str
        Keys in a module on the unread register whose declared count
        matches the measured one.
    owed : list of str
        Keys in neither.  **A non-empty list fails the gate.**
    miscounted : list of str
        Modules on the unread register whose declared count no longer
        matches the number of substituting sites measured in them,
        reported as ``"module: declared N, measured M"``.  A module
        that grows a site must not hide it behind the old debt.
    stale : list of str
        Keys in ``REASONS`` that no longer name a site in the tree.
    """
    R = _reasons_module()
    keyed = keyed_substituting(sites)

    measured: Dict[str, int] = {}
    for _key, site in keyed:
        measured[site.path] = measured.get(site.path, 0) + 1

    miscounted = []
    for module in sorted(R.UNREAD):
        declared = R.unread_for(module)[0]
        found = measured.get(module, 0)
        if declared != found:
            miscounted.append(
                f"{module}: declared {declared}, measured {found}")

    read, unread, owed = [], [], []
    for key, site in keyed:
        if R.reason_for(key) is not None:
            read.append(key)
        elif site.path in R.UNREAD:
            unread.append(key)
        else:
            owed.append(key)

    live = {k for k, _ in keyed}
    stale = sorted(k for k in R.REASONS if k not in live)
    return read, unread, owed, miscounted, stale


def walk(root: str = _SRC) -> Iterator[Site]:
    r"""
    Yield every ``getattr`` site under *root*.

    Parameters
    ----------
    root : str, optional
        Directory to walk.  Default: the installed package tree.

    Yields
    ------
    Site
    """
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in sorted(dirnames)
                       if d not in ("__pycache__", ".git")]
        for filename in sorted(filenames):
            if not filename.endswith(".py"):
                continue
            full = os.path.join(dirpath, filename)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            with open(full, "r", encoding="utf-8", newline="") as handle:
                source = handle.read()
            tree = ast.parse(source, filename=rel)
            visitor = _Visitor(rel, source)
            visitor.visit(tree)
            yield from visitor.sites


def main(argv=None) -> int:
    r"""
    Run the inventory.

    Parameters
    ----------
    argv : list of str, optional

    Returns
    -------
    int
        ``0`` unless ``--gate`` is given and a substituting site sits
        on the dump path.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dump-path", action="store_true",
                        help="restrict the report to the dump path")
    parser.add_argument("--gate", action="store_true",
                        help="exit 1 on a substituting site on the "
                             "dump path, or on one that is neither "
                             "read nor declared unread")
    parser.add_argument("--reasons", action="store_true",
                        help="print every substituting site with its "
                             "recorded reason, and exit 0")
    parser.add_argument("--root", default=_SRC)
    args = parser.parse_args(argv)

    sites = list(walk(args.root))

    if args.reasons:
        R = _reasons_module()
        for key, site in keyed_substituting(sites):
            reason = R.reason_for(key)
            print(f"  {key}")
            if reason is None:
                declared = R.unread_for(site.path)
                note = ("UNREAD — " + declared[1]) if declared else \
                    "OWED — no reason and no unread declaration"
                print(f"        {note}")
            else:
                print(f"        {reason}")
        return 0

    if args.dump_path:
        sites = [s for s in sites if s.on_dump_path]

    by_kind: Dict[str, int] = {}
    for site in sites:
        by_kind[site.kind] = by_kind.get(site.kind, 0) + 1

    findings = [s for s in sites
                if s.kind == "substituting" and s.on_dump_path]

    print(f"getattr inventory — {len(sites)} site(s) under {args.root}")
    for kind in ("raising", "probe", "dynamic", "substituting"):
        print(f"  {kind:<14} {by_kind.get(kind, 0):>4}")
    print()

    on_path = [s for s in sites if s.on_dump_path]
    print(f"on the declared dump path: {len(on_path)} site(s)")
    for site in on_path:
        print(f"  {site}")
    print()

    if findings:
        print(f"FINDING: {len(findings)} substituting site(s) on the "
              f"dump path.  A silent default inside a versioned "
              f"contract is permanent; replace each with an access "
              f"that raises, or with an absence recorded in "
              f"dump['absences'] with its cause.")
        for site in findings:
            print(f"  {site}")
    else:
        print("no substituting getattr on the dump path.")

    # ------------------------------------------------------------------
    #  The reason audit, new in Phase 20.
    #
    #  The dump-path rule above is narrow by design and stays narrow.
    #  What it never said anything about is the substituting sites
    #  everywhere else, and a green gate was being read as though it
    #  did.  Below, every one of them must be either READ or DECLARED
    #  UNREAD -- never merely absent, which is how a gate passes on
    #  silence.  The residual is printed on every invocation so the
    #  debt cannot become invisible by being ignored.
    # ------------------------------------------------------------------
    subst = [s for s in sites if s.kind == "substituting"]
    read, unread, owed, miscounted, stale = audit(sites)
    total = len(subst)
    print()
    print(f"substituting sites: {total}")
    print(f"  read (a reason per site)     {len(read):>4}")
    print(f"  declared unread (on record)  {len(unread):>4}")
    print(f"  owed (neither)               {len(owed):>4}")
    if unread:
        print("\nstill to read, by module, in the order the register "
              "gives:")
        R = _reasons_module()
        for module in R.UNREAD:
            count = R.unread_for(module)[0]
            print(f"  {count:>4}  {module}")
    if stale:
        print(f"\n{len(stale)} recorded reason(s) name a site that is "
              f"no longer in the tree.  A removal is not a deletion: "
              f"move each to getattr_reasons.REMOVED with the phase "
              f"that removed it and the count before and after, so "
              f"the record survives and the gate stays a signal.")
        for key in stale:
            print(f"  MOVE TO ARCHIVE  {key}")
    if miscounted:
        print()
        for line in miscounted:
            print(f"  MISCOUNT  {line}")
    if owed:
        print()
        for key in owed:
            print(f"  NO REASON  {key}")
        print(f"\n{len(owed)} substituting site(s) have no entry in "
              f"getattr_reasons.REASONS and live in no module on the "
              f"unread register.  A substituting default that never "
              f"substitutes is invisible until the day it does "
              f"(F-P00-1): read it, or put it on the register with a "
              f"count.")

    failed = bool(findings) or bool(owed) or bool(miscounted) \
        or bool(stale)
    if not failed:
        R = _reasons_module()
        print(f"\ngate: no substituting getattr on the dump path; "
              f"{len(read)} site(s) read, {len(unread)} on the unread "
              f"register, 0 unaccounted for.")
        print(f"      {len(getattr(R, 'REMOVED', {}))} archived "
              f"reason(s) for sites removed in earlier phases "
              f"(getattr_reasons.REMOVED).")
    return 1 if (args.gate and failed) else 0


if __name__ == "__main__":                      # pragma: no cover
    sys.exit(main())
