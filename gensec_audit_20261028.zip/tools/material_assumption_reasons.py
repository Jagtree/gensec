# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
# This file is part of GenSec.  AGPL-3.0-or-later.
# ---------------------------------------------------------------------------
r"""
Written reasons for material-assumption sites added after the baseline.

The baseline in ``material_assumption_baseline.txt`` is the debt as it
stood when Phase 29 first measured it.  It is not a target and not a
failure; it is a number.  This file exists so that the number cannot
grow in silence: every site added after the baseline must arrive with a
sentence saying why the engine is entitled to assume a material property
there, keyed by ``"<path>:<line>"``.

A reason is a claim about code.  When the code moves, the reason goes
stale, and the gate refuses a stale reason for the same purpose it
refuses an unexplained site: a register that disagrees with the tree
measures nothing.
"""

#: ``"category|module|name"`` -> why the assumption is admissible.
REASONS = {
    "clause|src/gensec/io_yaml.py|ec2":
        "Phase 37 removed the loader's normative defaults: 'ls', "
        "'loadtype', 'TypeConc', 'NA', 'time', 'Ep', 'eps_ud_factor' "
        "and 'diagram' are now read and never supplied.  The count "
        "rose from four to ten because each refusal names the EN 1992 "
        "clause the parameter belongs to, so the reader learns what "
        "the missing declaration governs instead of only that it is "
        "missing.  These sites assume nothing: they are the places "
        "where GenSec states that it will not assume, and the clause "
        "is named in the refusal rather than acted upon.",
}
