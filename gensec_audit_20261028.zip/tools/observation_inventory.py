r"""
Observation inventory — every module names the fingerprint family that
watches it, or declares that none does.

Why this exists
---------------
``element_class_inventory`` answers *does this consumer enumerate all
three element classes*.  This tool answers the question E34-1 left open:
*does anything watch this module at all*.

E34-1 was a merge of two implementations that read ``INERT`` on the
numeric, datum and domain fingerprints together.  The merge was not
thereby correct: **no probe looked at that code**, so all three had
nothing to say.  The failure mode is silence, and silence is invisible
in review by construction — the check that is missing is not there to
read.

Line coverage does not answer it.  Coverage reports *this line ran*; the
question is *this line is watched*, and E34-1 ran.  A ``coverage run``
over the capture was attempted in Phase 35, ran past fifty minutes
without completing, and would have decided nothing (``35_0`` §6).  The
only mechanical form of "observed" is a declaration under a gate, which
is what :mod:`observation_reasons` holds and what this tool checks.

What the gate refuses
---------------------
1. A module of ``src/gensec`` with **no entry** in
   :mod:`observation_reasons`.  A new module arrives unwatched by
   default, and the gate is what turns that default into a diff.
2. An entry naming a **family that does not exist** in the reference
   fingerprints.  A declaration whose family was renamed or deleted is
   a declaration that observes nothing while claiming otherwise — the
   species of ``35_0`` §4.
3. An entry for a **module that is gone**.  A reason outliving its
   subject makes the inventory's own numbers false.
4. An ``OBSERVED`` entry naming **no family at all**.  The empty tuple
   means unobserved, and unobserved belongs in the other table with a
   reason for why nothing could watch it.

What it does **not** check, deliberately: that a named family really
would move on a change in the module.  That is the claim the reason
makes, and it is established by the evidence run in
``tools/observation_evidence.py`` — a call-level profile of the three
captures — not by this gate, which must stay cheap enough to run in the
closing checklist.

Family names
------------
A family is the first ``.``-separated component of a fingerprint key,
qualified by its capture, because the same component occurs in more
than one::

    numeric:law   datum:d1c   domain:EC2RheologicalModel

``numeric:examples`` and ``datum:examples`` are collectives standing for
the walk over ``examples/*.yaml``; each expands to the stems of the
distributed examples that appear as families in that capture, and the
gate refuses the collective if the expansion is empty.

Usage
-----
::

    python tools/observation_inventory.py            # full report
    python tools/observation_inventory.py --gate     # exit 1 on drift
    python tools/observation_inventory.py --baseline # rewrite baseline
    python tools/observation_inventory.py --falsify  # prove it says no

The reference captures default to the newest ``*_numeric_POST.txt``,
``*_datum_POST.txt`` and ``*_domain_POST.txt`` under ``.fingerprints/``;
``--numeric``, ``--datum`` and ``--domain`` override them.

Notes
-----
The baseline is written **from the declarations**, never by hand, for
the reason ``35_0`` gives for every inventory in this tree: a baseline
edited directly can agree with nothing, and a gate that compares a file
to itself is a gate that always passes.
"""

from __future__ import annotations

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile
from typing import Dict, List, Sequence, Set, Tuple

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src", "gensec")
TOOLS = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(TOOLS, "observation_baseline.txt")
FINGERPRINTS = os.path.join(ROOT, ".fingerprints")
EXAMPLES = os.path.join(ROOT, "examples")

#: Directories under ``src/gensec`` that hold no Python of ours.
EXCLUDE_DIRS = ("_docs_assets", "__pycache__")

#: The three captures, in the order they are reported.
CAPTURES = ("numeric", "datum", "domain")

#: The collective family name, per capture.
COLLECTIVE = "examples"

PASS, FAIL = 0, 1

_BASELINE_HEADER = (
    "# observation baseline — one line per module of src/gensec, and the\n"
    "# fingerprint families that observe it.  Written by\n"
    "#     python tools/observation_inventory.py --baseline\n"
    "# from tools/observation_reasons.py, which is where the\n"
    "# declarations are edited.  Do not hand-edit this file.\n"
    "#\n"
    "# A line whose family list is UNOBSERVED declares that no key of\n"
    "# any capture watches the module; its reason says why nothing\n"
    "# could, or -- tag DEBT -- that a probe is owed.\n"
)

#: Column at which the family list starts, so the baseline stays
#: diffable when a module is renamed.
_FAMILY_COL = 38


# ----------------------------------------------------------------------
#  The tree
# ----------------------------------------------------------------------

def modules(src: str = SRC) -> List[str]:
    r"""
    Every module of the package, as ``/``-separated relative paths.

    Parameters
    ----------
    src : str, optional
        Package root.  Parameterised so that :func:`falsify` can point
        the same code at a deliberately corrupted copy.

    Returns
    -------
    list of str
        Sorted, so the report and the baseline are diffable.
    """
    out: List[str] = []
    for base, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for name in sorted(files):
            if name.endswith(".py"):
                rel = os.path.relpath(os.path.join(base, name), src)
                out.append(rel.replace(os.sep, "/"))
    return sorted(out)


# ----------------------------------------------------------------------
#  The reference captures
# ----------------------------------------------------------------------

def newest_capture(kind: str, folder: str = FINGERPRINTS) -> str:
    r"""
    Path of the most recent archived POST capture of *kind*.

    Parameters
    ----------
    kind : {'numeric', 'datum', 'domain'}
    folder : str, optional

    Returns
    -------
    str
        Empty string when the folder holds none, which the caller turns
        into a refusal rather than into an empty family set: an absent
        reference would let every declaration pass.

    Notes
    -----
    The archive names captures ``NN_MM_<kind>_POST.txt``, so lexical
    order is chronological order and "newest" needs no timestamp.
    """
    found = sorted(glob.glob(os.path.join(folder, f"*_{kind}_POST.txt")))
    return found[-1] if found else ""


def families_in(path: str) -> Set[str]:
    r"""
    The unqualified family names present in a capture file.

    Parameters
    ----------
    path : str
        A fingerprint file: ``# comment`` lines, then ``key = value``.

    Returns
    -------
    set of str
        The first ``.``-separated component of every key, with any
        ``[...]`` subscript stripped.  A key with no ``.`` is its own
        family, which is how the domain capture's class-level keys are
        named.
    """
    fams: Set[str] = set()
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            key = line.partition(" = ")[0].strip()
            fams.add(key.split(".")[0].split("[")[0])
    return fams


def example_stems(folder: str = EXAMPLES) -> Set[str]:
    r"""The stem of every distributed example document."""
    return {os.path.basename(p)[:-5]
            for p in glob.glob(os.path.join(folder, "*.yaml"))}


def valid_families(paths: Dict[str, str],
                   examples: Set[str]) -> Tuple[Set[str], Dict[str, int]]:
    r"""
    The set of family names a declaration may name.

    Parameters
    ----------
    paths : dict
        ``{'numeric': path, 'datum': path, 'domain': path}``.  A missing
        or empty path contributes nothing, and the caller refuses.
    examples : set of str
        Stems of ``examples/*.yaml``, used to fold the walk's per-document
        families into the collective.

    Returns
    -------
    valid : set of str
        Qualified names, e.g. ``'numeric:law'``.  The collective
        ``'<capture>:examples'`` is included only for a capture whose
        families actually include at least one example stem.
    expansion : dict
        ``{'<capture>:examples': n}`` — how many stems the collective
        stands for in each capture.  Reported, so that a collective
        quietly shrinking to one document is visible.
    """
    valid: Set[str] = set()
    expansion: Dict[str, int] = {}
    for kind, path in paths.items():
        if not path or not os.path.exists(path):
            continue
        fams = families_in(path)
        hit = fams & examples
        for f in fams:
            valid.add(f"{kind}:{f}")
        if hit:
            valid.add(f"{kind}:{COLLECTIVE}")
            expansion[f"{kind}:{COLLECTIVE}"] = len(hit)
    return valid, expansion


# ----------------------------------------------------------------------
#  The declarations
# ----------------------------------------------------------------------

def _reasons_module():
    r"""
    Import :mod:`observation_reasons` from beside this file.

    Returns
    -------
    module

    Raises
    ------
    SystemExit
        If the table is missing.  A gate whose declarations vanished
        must fail loudly rather than pass as "nothing to check", which
        is the failure this whole inventory exists to make impossible.
    """
    if TOOLS not in sys.path:
        sys.path.insert(0, TOOLS)
    try:
        import observation_reasons as mod
    except ImportError as exc:                           # pragma: no cover
        raise SystemExit(
            f"observation_inventory: cannot import the declarations "
            f"({exc}).  tools/observation_reasons.py is part of the "
            f"gate, not an optional extra.")
    return mod


def _format_line(module: str, fams: Sequence[str], reason: str) -> str:
    r"""One baseline line: module, family list, then ``# reason``."""
    head = module
    pad = " " * max(2, _FAMILY_COL - len(head))
    body = " ".join(fams) if fams else "UNOBSERVED"
    return f"{head}{pad}{body}\n{'':4}# {' '.join(reason.split())}"


# ----------------------------------------------------------------------
#  Verdict
# ----------------------------------------------------------------------

def check(src: str = SRC,
          paths: Dict[str, str] | None = None,
          examples: Set[str] | None = None) -> Tuple[List[str], Dict]:
    r"""
    Run every refusal and return the problems found.

    Parameters
    ----------
    src : str, optional
        Package root to walk.
    paths : dict, optional
        Reference captures; defaults to the newest archived POST of
        each kind.
    examples : set of str, optional

    Returns
    -------
    problems : list of str
        Empty when the gate passes.  Each entry is one refused fact,
        already worded for printing.
    stats : dict
        ``modules``, ``observed``, ``unobserved``, ``debt``,
        ``valid_families``, ``expansion``.
    """
    R = _reasons_module()
    if paths is None:
        paths = {k: newest_capture(k) for k in CAPTURES}
    if examples is None:
        examples = example_stems()

    problems: List[str] = []
    missing_capture = [k for k in CAPTURES
                       if not paths.get(k) or not os.path.exists(paths[k])]
    if missing_capture:
        problems.append(
            f"no reference capture for {', '.join(missing_capture)}: "
            f"without one, every family name would validate against an "
            f"empty set and the gate would pass on anything.")

    valid, expansion = valid_families(paths, examples)
    mods = modules(src)
    declared = set(R.OBSERVED) | set(R.UNOBSERVED)

    for m in mods:
        if m not in declared:
            problems.append(
                f"NO ENTRY         {m}  -- a module with no declaration "
                f"is unwatched by default; say which family observes it "
                f"or declare it UNOBSERVED with the reason.")

    for m in sorted(declared - set(mods)):
        problems.append(
            f"MODULE GONE      {m}  -- a declaration whose subject left "
            f"the tree makes this inventory's own counts false.")

    for m, (fams, _reason) in sorted(R.OBSERVED.items()):
        if not fams:
            problems.append(
                f"EMPTY FAMILIES   {m}  -- an OBSERVED entry naming no "
                f"family is an unobserved module; move it to UNOBSERVED "
                f"with the reason nothing can watch it.")
        for f in fams:
            if f not in valid:
                problems.append(
                    f"NO SUCH FAMILY   {m}  names {f!r}, which is in no "
                    f"reference capture.  Valid names are "
                    f"'<capture>:<first key component>'.")

    for name, n in expansion.items():
        if n == 0:                                       # pragma: no cover
            problems.append(
                f"EMPTY COLLECTIVE {name} expands to no example.")

    debt = sum(1 for r in R.UNOBSERVED.values()
               if r.lstrip().lstrip("*").startswith("DEBT"))
    stats = {
        "modules": len(mods),
        "observed": len(R.OBSERVED),
        "unobserved": len(R.UNOBSERVED),
        "debt": debt,
        "valid_families": len(valid),
        "expansion": expansion,
        "paths": paths,
    }
    return problems, stats


# ----------------------------------------------------------------------
#  Falsification
# ----------------------------------------------------------------------

def falsify() -> int:
    r"""
    Corrupt the tree three distinct ways and require rejection.

    The three are the three ways a declaration set can stop describing
    its tree, and each must be rejected by **its own** diagnosis: a
    rejection for the wrong reason is not counted as a success.  A null
    control — the tree untouched — must be **accepted**, without which a
    gate that refused everything would score four out of four.

    ==========================  ==========================================
    corruption                  required diagnosis
    ==========================  ==========================================
    a new module, no entry      ``NO ENTRY``
    an entry naming a family
    that is in no capture       ``NO SUCH FAMILY``
    an entry left behind for a
    module that was deleted     ``MODULE GONE``
    ==========================  ==========================================

    Returns
    -------
    int
        :data:`PASS` if all four verdicts are as required.
    """
    def verdict(work: str) -> Tuple[int, str]:
        r"""Run ``--gate`` inside *work* as a subprocess, from *work*."""
        proc = subprocess.run(
            [sys.executable, os.path.join(work, "tools",
                                          "observation_inventory.py"),
             "--gate"],
            cwd=work, capture_output=True, text=True)
        return proc.returncode, proc.stdout + proc.stderr

    def fresh(tmp: str, tag: str) -> str:
        work = os.path.join(tmp, tag)
        os.makedirs(work)
        for sub in ("src", "tools", "examples", ".fingerprints"):
            shutil.copytree(os.path.join(ROOT, sub),
                            os.path.join(work, sub),
                            ignore=shutil.ignore_patterns("__pycache__"))
        return work

    results: List[Tuple[str, bool, str]] = []
    with tempfile.TemporaryDirectory() as tmp:

        # 0 — null control.
        work = fresh(tmp, "null")
        code, out = verdict(work)
        results.append(("null control (untouched tree)",
                        code == PASS, f"exit {code}"))

        # 1 — a module nobody declared.
        work = fresh(tmp, "new_module")
        with open(os.path.join(work, "src", "gensec", "_intruder.py"),
                  "w", encoding="utf-8") as fh:
            fh.write("VALUE = 1.0\n")
        code, out = verdict(work)
        results.append(("new module with no entry",
                        code == FAIL and "NO ENTRY" in out
                        and "_intruder.py" in out, f"exit {code}"))

        # 2 — a family that is in no capture.
        work = fresh(tmp, "bad_family")
        p = os.path.join(work, "tools", "observation_reasons.py")
        with open(p, encoding="utf-8") as fh:
            src = fh.read()
        marker = '"io_yaml.py": (\n   ("numeric:examples"'
        assert marker in src, "falsify: the io_yaml entry moved"
        src = src.replace(marker,
                          '"io_yaml.py": (\n   ("numeric:no_such_bench"', 1)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(src)
        code, out = verdict(work)
        results.append(("entry names a family in no capture",
                        code == FAIL and "NO SUCH FAMILY" in out,
                        f"exit {code}"))

        # 3 — a declaration outliving its module.
        work = fresh(tmp, "module_gone")
        os.remove(os.path.join(work, "src", "gensec", "tolerances.py"))
        code, out = verdict(work)
        results.append(("declaration left for a deleted module",
                        code == FAIL and "MODULE GONE" in out
                        and "tolerances.py" in out, f"exit {code}"))

    print("observation_inventory --falsify")
    for name, ok, detail in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {name:44s} {detail}")
    bad = [n for n, ok, _ in results if not ok]
    if bad:
        print(f"\nFALSIFICATION FAIL: {len(bad)} verdict(s) wrong.")
        return FAIL
    print("\nFALSIFICATION PASS: 3 corruptions rejected, each by its own "
          "diagnosis, null control accepted.")
    return PASS


# ----------------------------------------------------------------------
#  CLI
# ----------------------------------------------------------------------

def main(argv=None) -> int:
    r"""CLI entry point.  Returns the process exit code."""
    ap = argparse.ArgumentParser(
        description="which fingerprint family observes which module")
    ap.add_argument("--gate", action="store_true",
                    help="exit 1 if a module has no declaration, a "
                         "declaration names a family that does not "
                         "exist, or a declaration outlives its module")
    ap.add_argument("--baseline", action="store_true",
                    help="rewrite the baseline from the declarations")
    ap.add_argument("--falsify", action="store_true",
                    help="prove the gate rejects three corruptions and "
                         "accepts a null control")
    for kind in CAPTURES:
        ap.add_argument(f"--{kind}", default=None,
                        help=f"reference {kind} capture "
                             f"(default: newest archived POST)")
    args = ap.parse_args(argv)

    if args.falsify:
        return falsify()

    paths = {k: (getattr(args, k) or newest_capture(k)) for k in CAPTURES}
    problems, stats = check(paths=paths)
    R = _reasons_module()

    if args.baseline:
        if problems:
            print("REFUSING to write a baseline over an unclean tree:",
                  file=sys.stderr)
            for p in problems:
                print(f"  {p}", file=sys.stderr)
            return FAIL
        with open(BASELINE, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(_BASELINE_HEADER)
            for m in modules():
                fams, reason = R.entry_for(m)
                fh.write(_format_line(m, fams, reason) + "\n")
        print(f"baseline rewritten: {stats['modules']} module(s), "
              f"{stats['observed']} observed, "
              f"{stats['unobserved']} unobserved")
        return PASS

    print(f"observation inventory — {stats['modules']} module(s) under "
          f"{os.path.relpath(SRC, ROOT)}")
    for kind in CAPTURES:
        print(f"  reference {kind:8s} "
              f"{os.path.relpath(paths[kind], ROOT) if paths[kind] else '(none)'}")
    print(f"  valid family names {stats['valid_families']}"
          + (f"   collectives: "
             + ", ".join(f"{k}={v}" for k, v in
                         sorted(stats["expansion"].items()))
             if stats["expansion"] else ""))
    print(f"  observed          {stats['observed']}")
    print(f"  UNOBSERVED        {stats['unobserved']}   "
          f"of which DEBT {stats['debt']}")
    print()
    for m in sorted(R.UNOBSERVED):
        tag = R.UNOBSERVED[m].lstrip().lstrip("*").split(":")[0]
        print(f"  {tag:10s} {m}")

    if args.gate:
        if problems:
            print()
            for p in problems:
                print(f"  {p}")
            print(f"\ngate: {len(problems)} problem(s).  A module nobody "
                  f"watches must say so; a declaration that names "
                  f"nothing real observes nothing while claiming "
                  f"otherwise.")
            return FAIL
        print(f"\ngate: every one of {stats['modules']} module(s) carries "
              f"a declaration, and every family named exists in the "
              f"reference captures.")
        print(f"      {stats['unobserved']} module(s) are UNOBSERVED, "
              f"{stats['debt']} of them tagged DEBT — measured, not "
              f"repaired.")
    return PASS


if __name__ == "__main__":                               # pragma: no cover
    raise SystemExit(main())
# GENSEC-COMPLETE phase=36 utc=2026-09-10T11:27:49Z sha256=8abedcc16ada9a759f11ce0f4ebb7921a7031600daf19d508c098108c7e98128 body_lines=576
