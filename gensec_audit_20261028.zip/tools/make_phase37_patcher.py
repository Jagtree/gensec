r"""
Build ``patchers/run_phase37_no_defaults_and_observation.py``.

The mechanism is lifted verbatim from the Phase-36 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across six phases, and a
rewrite would put a verified thing back on trial for no gain.

One limitation, stated because it is not visible from the output: the
payload transports **content**, never **removals**.  Phase 37 deletes
``tests/run_phase36_patcher_falsification.py`` (replaced, not
accompanied -- see ``37_0`` section 11, E37-4), and that deletion does
not travel with the payload.  Applying this patcher to a tree that still
carries the Phase-36 harness leaves it there, permanently red.

Run from the repository root::

    python3 tools/make_phase37_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase36_observation_and_unknown_keys.py"
OUT = ROOT / "patchers" / "run_phase37_no_defaults_and_observation.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    # --- the loader and its second home -----------------------------
    "src/gensec/io_yaml.py",
    "src/gensec/materials/ec2_bridge.py",
    # --- the instruments --------------------------------------------
    "tools/numeric_fingerprint.py",
    "tools/observation_evidence.py",
    "tools/observation_reasons.py",
    "tools/material_assumption_reasons.py",
    "tools/selfcheck_inventory.py",
    "tools/make_phase37_patcher.py",
    # --- the falsifier that replaces its predecessor ----------------
    "tests/run_phase37_patcher_falsification.py",
    # --- callers made explicit --------------------------------------
    "tests/run_phase4_yaml_validation.py",
    "tests/run_phase5_c5_validation.py",
    "tests/test_capacity_v2.py",
    "tests/test_materials.py",
    "tests/test_phase12_ledger.py",
    "tests/test_phase12_p3_closure.py",
    "tests/test_phase12_p3_red.py",
    "tests/test_phase13_dump.py",
    "tests/test_phase14_cracking.py",
    "tests/test_phase15_mechanical_strain.py",
    "tests/test_phase18_scope.py",
    "tests/test_phase19_hull.py",
    "tests/test_phase23_declared_reduction.py",
    "tests/test_phase34_retrofit_yaml_surface.py",
    "tests/test_phase36_unknown_keys.py",
    "tests/test_phase5_c5.py",
    "tests/test_phase8_task1.py",
    "tests/test_solver_uniaxial.py",
    # --- the shipped documents that now declare what they receive ---
    "examples/Pannello_187x30.yaml",
    "examples/Pannello_30x187.yaml",
    "examples/biaxial_column.yaml",
    "examples/example_annulus.yaml",
    "examples/example_biaxial_column.yaml",
    "examples/example_composite_losses.yaml",
    "examples/example_composite_losses_fb_gap.yaml",
    "examples/example_composite_topping.yaml",
    "examples/example_external_tendon.yaml",
    "examples/example_prestress.yaml",
    "examples/example_staged_construction.yaml",
    "examples/example_staged_cracking.yaml",
    "examples/example_staged_injection.yaml",
    "examples/example_strand_only_slab.yaml",
    "examples/example_tee.yaml",
    "examples/example_v2_1.yaml",
    "examples/vcaslu_1.yaml",
    # --- the six fingerprints ---------------------------------------
    ".fingerprints/37_00_numeric_PRE.txt",
    ".fingerprints/37_00_datum_PRE.txt",
    ".fingerprints/37_00_domain_PRE.txt",
    ".fingerprints/37_01_numeric_POST.txt",
    ".fingerprints/37_01_datum_POST.txt",
    ".fingerprints/37_01_domain_POST.txt",
    # --- the handoff -------------------------------------------------
    "handoff/37_0-GENSEC_LEDGER_37.md",
    "handoff/37_1-GENSEC_PHASE37_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 37 - no normative defaults, and the last two blind modules.

What this transports
--------------------
Four subsets.

1. **No normative default, in either home (D).**  ``io_yaml.py``
   supplied twelve of them -- ``ls``, ``NA``, ``loadtype``,
   ``TypeConc``, ``time``, ``Ep``, ``eps_ud_factor``, ``diagram`` -- and
   the four ``ec2_bridge`` constructors repeated the same values in
   their signatures, so removing them from the loader alone would have
   moved the silence down one level and left it silence.  Measured:
   eight shipped materials were taking ``ls = "F"``, i.e.
   ``gamma_c = 1.5`` and ``f_cd = 17.0`` MPa where a quasi-permanent
   combination gives 1.0 and 25.5 -- fifty per cent of design
   compressive strength chosen by a ``.get`` default.  82 keys written
   into 17 of the 24 shipped examples, 60 into 9 fixture documents, 36
   call sites made explicit.  **Zero numbers moved**: every value
   written is the one the document was already receiving.
2. **``solver/prestress_transfer.py`` observed (E34-1).**  The module
   was not dead code: six real importers, two of them validators.  What
   was missing was a key, not a caller.  ``d1c.divergence`` already
   compared the driver against ``_cumulative_reference``, which builds a
   FiberSolver and calls ``posttension._stressing_view`` -- independent
   in form, not in machinery.  The closed form shares nothing, and reads
   **exactly 0** on the linear law.
3. **``cli.py`` observed (E34-1).**  No fixture ran ``cli.main``: the
   one that names the verb opens the file and greps its text.  21 keys
   now hold which engines ``run`` invokes and in what order.
4. **The evidence instrument repaired.**  ``observation_evidence
   --check`` exited 1 on the pristine tree: the domain capture reads
   class attributes, and an attribute read raises no ``'call'`` event.
   Domain evidence is now structural -- definition site plus the MRO
   modules that OWN the attributes read.  Eight domain declarations
   were false and are withdrawn; two are added to ``materials/base.py``,
   which owns them.

Fingerprints
------------
numeric 6160 -> 6183: +23 added (2 ``d1c.divergence.*.
max_rel_sigma_closed_form``, 21 ``cli.*``), **0 moved, 0 removed**.
datum 418 and domain 31 read INERT, byte-identical files.

Probe debt 12 -> 10, measured in the evidence trace, not deduced.
"""
'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
