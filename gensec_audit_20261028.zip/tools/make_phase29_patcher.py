r"""
Build ``patchers/run_phase28_strain_accumulation.py``.

The mechanism is **not** rewritten: the head (imports, ``ROOT``,
``PATH_ALIASES``, ``_resolve``) and the whole tail (``_verified``,
``main`` and its ``--selfcheck`` / ``--repair`` modes) are lifted
verbatim from the Phase-27 patcher.  One home for one fact: a second
implementation of atomic transport would be a second thing to be
wrong.  Only three regions are authored here — the header docstring,
``PAYLOAD`` and ``DIGESTS``.

Usage
-----
::

    python3 tools/make_phase28_patcher.py
"""

import base64
import hashlib
import pathlib
import sys
import textwrap

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase28_strain_accumulation.py"
OUT = ROOT / "patchers" / "run_phase29_extreme_fibre_check.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there.
FILES = [
    "src/gensec/solver/sls.py",
    "src/gensec/output/report.py",
    "tests/run_phase7_sls_validation.py",
    "tests/run_phase8_task3_validation.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase28_strain_accumulation.py",
    "tests/test_phase29_extreme_fibre_check.py",
    "tools/numeric_fingerprint.py",
    "tools/material_assumption_inventory.py",
    "tools/material_assumption_reasons.py",
    "tools/material_assumption_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase29_patcher.py",
    ".fingerprints/29_00_numeric_PRE.txt",
    ".fingerprints/29_00_datum_PRE.txt",
    ".fingerprints/29_00_domain_PRE.txt",
    ".fingerprints/29_01_numeric_POST.txt",
    ".fingerprints/29_01_datum_POST.txt",
    ".fingerprints/29_01_domain_POST.txt",
    "handoff/29_0-GENSEC_LEDGER_29.md",
    "handoff/29_1-GENSEC_PHASE29_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 29 - F6 on the check path, and the decompression record.

What this transports
--------------------
``concrete_compression`` verified ``S_bulk[i_min]``, the stress at the
centroid of the outermost fibre, while the record reported the section
face and the check wore the face's coordinates.  The gap is exactly
proportional to the half-fibre inset -- 3.3759 % at n_fibers_y = 24,
0.3375 % at 240 -- and non-conservative throughout, against a clause
that limits the stress at the extreme fibre of the SECTION.

The decompression record published ``sigma_probe_MPa`` beside the
``eps_probe`` its verdict is taken on.  On a cracking law the two give
opposite answers past eps_ct, where the law returns zero.  It now
carries the strain alone, as value and limit, and no eta: it is the one
check with no capacity to divide by.  The governing selection was
repaired instead -- a failed check governs over a passing one.

Idempotent, all-or-nothing, CRLF preserved per file.  ``--selfcheck``
compares bytes.  See handoff/29_0-GENSEC_LEDGER_29.md.
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the Phase-27 patcher this one is lifted from stores
    the bytes as they are, and a second encoding would be a second
    thing to get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    src = SRC.read_text(encoding="utf-8")
    # The mechanism is lifted verbatim: everything above PAYLOAD and
    # everything from _verify_payload down.  Only the header docstring
    # and the two data blocks are authored here.
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
