#!/usr/bin/env python3
r"""
Generate ``patchers/run_phase22_staged.py`` from the tested tree.

The generator reads the files Phase 22 moved **from disk, as bytes**,
measures each one's line-ending convention at byte level **once**, and
emits a standalone patcher carrying the verified content.  The emitted
patcher's machinery (``_looks_like_root``, ``_verified``, ``_kind``,
``_write_route``, ``_commit``, ``main``) is lifted verbatim from
``run_phase19_hull.py``, so N-10's all-or-nothing commit travels
unchanged instead of being retyped.

``measure_line_ending`` refuses to emit a mixed file rather than
declaring one convention for it.  That behaviour is taken from
``make_phase20_patcher.py``, which is kept in the tree as provenance:
a lone ``\r`` is an error, not a line ending, and a file that mixes
CRLF and LF cannot be transported under a single declaration.
"""

from __future__ import annotations

import base64
import hashlib
import textwrap
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase21_codes.py"
OUT = ROOT / "patchers" / "run_phase22_staged.py"

#: The payload, in the order a reader should meet it: the repair, the
#: instruments, the gates' own records, the fixtures, the example, the
#: documents.  Completeness is **measured** after generation by
#: comparing the tree this produces against the tree the suite ran
#: green on -- never assumed.
FILES = [
    # --- the repair: one home for the stressing-sequence physics ------
    "src/gensec/solver/posttension.py",
    "src/gensec/solver/timeline.py",
    # --- the instrument, extended BEFORE the repair -------------------
    "tools/numeric_fingerprint.py",
    # --- the gate's own records, which the gate rewrote itself --------
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/selfcheck_inventory.py",
    # --- the generator, as provenance for the next phase --------------
    "tools/make_phase22_patcher.py",
    # --- the fixtures and the example that makes D1 observable --------
    "tests/test_phase22_intra_sequence.py",
    "examples/example_staged_injection.yaml",
    # --- the probes: measured, kept, tracked --------------------------
    "claude_scratch/probe_d1_intra_sequence.py",
    "claude_scratch/probe_d1_blindness.py",
    "claude_scratch/suite_cut.py",
    # --- the documents ------------------------------------------------
    "handoff/00_BOOTSTRAP.md",
    "handoff/6_8-WARNING_intra_sequence_bonded.md",
    "handoff/10_6-GENSEC_PRESTRESS_ARC_CLOSURE.md",
    "handoff/22_0-GENSEC_LEDGER_22.md",
    "handoff/22_1-GENSEC_PHASE22_RECAP.md",
]




DOCSTRING = r'''r"""
GenSec Phase 22 — F-P22-1: staged injection, and a resisting view that
grows as cables are grouted.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64``
of exactly what was on disk in the tree the Phase 22 suite ran green
on (952 tests, six disjoint groups over 38 files), line endings
included.

The defect, and the measurement that qualified it as one.  Before this
phase the section a post-tensioning jack was pulled against was
**tendon-free and constant** across the whole sequence, so a cable
already injected contributed no stiffness to the jacks that followed.
Measured on a 400x1200 girder with three tendons Ap=1500 at
y=-450/-400/-350 (``22_0`` §1.1), tendon-free view versus
already-injected view: the elastic-shortening loss comes out **5.1 %
too large** and the final ``sigma_p`` **0.46 % too low**; on a
1000x250 slab, 6.8 % and 0.88 %.  Every tolerance GenSec declares sits
at 1e-9 relative or below, so this is eight orders of magnitude out.
The refusal was not a conservatism worth narrowing.

* ``src/gensec/solver/posttension.py`` — ``bonded_before={tendon:
  step}`` and ``pending=[...]``, and a resisting view rebuilt whenever
  the bonded set changes.  ``(x_ref, y_ref)`` is pinned from the
  tendon-free view: bonding a tendon moves the homogenised centroid,
  and per-step planes read about migrating origins are not summable.
  Two named scope-boundary exceptions:
  ``IntraSequenceUndeclared`` (a tendon with no declared role — GenSec
  names the three readings instead of picking one) and
  ``PreexistingBondedNotModelled`` (the retrofit, still refused, with
  the reason written out);
* ``src/gensec/solver/timeline.py`` — the walk carries ``grout_step``
  and hands the driver the schedule.  The old refusal fired at the
  FIRST grout of an ordinary staged history, reading "not yet
  stressed" as "already grouted": a correct refusal applied to the
  wrong case;
* ``tools/numeric_fingerprint.py`` — extended **before** the repair.
  It recorded nothing of the post-tension sequence, and a
  refusal-turned-computation moves no number, so it now records an
  integer count of injections already made at each jack and the named
  outcome of the driver.  Measured blindness: 0 of 23 distributed
  examples interleaved ``stress`` and ``grout``, and the two that
  grouted at all carried a single tendon;
* ``examples/example_staged_injection.yaml`` — the case, made
  observable by a battery instrument for the first time;
* ``tests/test_phase22_intra_sequence.py`` — eight fixtures, all red
  on the pristine tree, zero ``ImportError``, zero ``AttributeError``.

Measured: **0 numbers move** among the 4685 shared numeric keys except
nine, all attributed in ``22_0`` §1.4; the datum fingerprint moves
**zero** of its 164 shared values; the domain fingerprint is INERT.

Usage
-----
::

    python3 patchers/run_phase22_staged.py --selfcheck
    python3 patchers/run_phase22_staged.py --repair
"""'''


def measure_line_ending(data: bytes) -> str:
    r"""
    The line-ending convention of *data*, measured at byte level.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
        ``'CRLF'``, ``'LF'``, or ``'none'`` for a file with no line
        break at all.

    Raises
    ------
    ValueError
        If the file mixes conventions or carries a lone ``\r``.  A
        mixed file cannot be transported with a single declaration,
        and declaring one anyway is the failure mode this measurement
        exists to prevent.
    """
    crlf = data.count(b"\r\n")
    bare_lf = data.count(b"\n") - crlf
    bare_cr = data.count(b"\r") - crlf
    if bare_cr:
        raise ValueError(f"lone CR present: {bare_cr}")
    if crlf and bare_lf:
        raise ValueError(f"mixed: {crlf} CRLF and {bare_lf} bare LF")
    if crlf:
        return "CRLF"
    if bare_lf:
        return "LF"
    return "none"


def encode(data: bytes) -> str:
    r"""
    ``zlib`` + ``base64``, wrapped as a Python implicit concatenation.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
    """
    blob = base64.b64encode(zlib.compress(data, 9)).decode("ascii")
    chunks = textwrap.wrap(blob, 100)
    return "\n".join(f'        "{c}"' for c in chunks)


def main() -> int:
    r"""
    Emit the Phase 22 patcher.

    Returns
    -------
    int
        ``0`` on success, ``2`` when a payload file is missing.
    """
    src = SRC.read_text(encoding="utf-8")
    machinery = src[src.index("def _looks_like_root(root):"):
                    src.index("def main(argv=None):")]
    tail = src[src.index("def main(argv=None):"):]
    tail = tail.replace("Phase 21", "Phase 22")
    tail = tail.replace(
        '    print("GenSec Phase 21 patcher — the declared normative "\n'
        '          "code, and everything derived from it")',
        '    print("GenSec Phase 22 patcher — staged injection, and a "\n'
        '          "resisting view that grows as cables are grouted")')

    payload, digests, endings = [], [], []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"MISSING {rel}")
            return 2
        data = path.read_bytes()
        le = measure_line_ending(data)
        payload.append(f'    "{rel}":\n{encode(data)},')
        digests.append(
            f'    "{rel}":\n        "{hashlib.sha256(data).hexdigest()}",')
        endings.append(f'    "{rel}": "{le}",')
        print(f"  {rel:<46} {len(data):>8} bytes  {le}")

    out = [
        DOCSTRING,
        "\nfrom __future__ import annotations\n",
        "import base64",
        "import hashlib",
        "import os",
        "import sys",
        "import zlib",
        "from pathlib import Path\n",
        "ROOT = Path(__file__).resolve().parent.parent\n",
        "#: ``{relative path: zlib+base64 of the verified bytes}``.",
        "PAYLOAD = {",
        "\n".join(payload),
        "}\n",
        "#: ``{relative path: sha256 of the verified bytes}``.",
        "DIGESTS = {",
        "\n".join(digests),
        "}\n",
        "#: ``{relative path: line-ending convention as MEASURED, at byte",
        "#: level, once, before generating}``.  Recorded so a reader can",
        "#: check the transport without decoding it.  No file in this",
        "#: payload is mixed; the generator refuses to emit one that is.",
        "LINE_ENDINGS = {",
        "\n".join(endings),
        "}\n\n",
        machinery,
        tail,
    ]
    OUT.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"\nwrote {OUT} ({OUT.stat().st_size} bytes), "
          f"{len(FILES)} file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
