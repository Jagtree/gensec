# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
Numeric fingerprint of the whole example set — a change detector.

Purpose
-------
Some changes to GenSec are supposed to move numbers and some are not.
"No number moved" is a claim; this tool turns it into a measurement.

It walks every file in ``examples/``, computes a fixed battery of
**physical quantities** — areas, static and second moments, integrated
axial force and bending moments, interaction-domain extrema, solved
strain planes — and writes them as a sorted, one-value-per-line text
file.  Two such files are compared numerically, with a tolerance, so
that the answer is not merely *different / identical* but *how much,
and where*.

What it deliberately does not read
----------------------------------
No hash, no digest, no signature, no ``id()``.  A change to the
*representation* of identity moves a hash by construction; a
fingerprint built on hashes would therefore report a difference for
exactly the retrofit it is meant to certify as inert — and, worse,
would report *no* difference when the representation is unchanged but
the physics has moved.  Every quantity recorded here is a number a
structural engineer could compute by hand.

Determinism
-----------
Every probe is a direct evaluation at a prescribed strain plane or a
prescribed load level.  Nothing is sampled at random, nothing depends
on dictionary iteration order or on ``PYTHONHASHSEED``, and the file
list is sorted.  Two runs on an unmodified tree produce byte-identical
output.

Failure is data
---------------
When a probe raises, the exception type and message are recorded as
the value.  A patch that turns a working example into a failing one —
or that silently changes *which* exception is raised — shows up in the
comparison exactly like a moved number.  Suppressing the failure would
hide it.

Usage
-----
::

    python tools/numeric_fingerprint.py capture  before.txt
    #   ... apply a patcher ...
    python tools/numeric_fingerprint.py capture  after.txt
    python tools/numeric_fingerprint.py compare  before.txt after.txt

    # tighten or loosen the movement threshold (default 1e-12)
    python tools/numeric_fingerprint.py compare before.txt after.txt \
        --rtol 1e-9

Exit status of ``compare`` is 0 when every value is within tolerance
and the two files describe the same set of keys, 1 otherwise.
"""

from __future__ import annotations

import glob
import math
import os
import sys
import traceback
from typing import Dict, List, Tuple

import numpy as np


# ======================================================================
#  Repository plumbing
# ======================================================================

def _repo_root() -> str:
    """
    Locate the repository root by walking up from this file.

    Returns
    -------
    str
        Absolute path of the directory containing ``src/gensec`` and
        ``examples``.

    Raises
    ------
    RuntimeError
        If the layout is not found.
    """
    cur = os.path.dirname(os.path.abspath(__file__))
    while True:
        if (os.path.isdir(os.path.join(cur, "src", "gensec"))
                and os.path.isdir(os.path.join(cur, "examples"))):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            raise RuntimeError(
                "repository root not found above "
                f"{os.path.abspath(__file__)!r}")
        cur = parent


ROOT = _repo_root()
if os.path.join(ROOT, "src") not in sys.path:
    sys.path.insert(0, os.path.join(ROOT, "src"))


# ======================================================================
#  Value formatting
# ======================================================================

#: Significant digits written for every float.  Twelve is far above
#: the size of any change this project cares about (the datum defect
#: is 29–41 %) and far below the ~16 digits at which last-bit
#: arithmetic noise would start to dominate the diff.
_SIG = 12


def _fmt(value) -> str:
    """
    Render one value in a diff-stable form.

    Parameters
    ----------
    value : float, int, bool or str

    Returns
    -------
    str
    """
    if isinstance(value, str):
        return value
    if isinstance(value, (bool, np.bool_)):
        return "true" if value else "false"
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    v = float(value)
    if math.isnan(v):
        return "nan"
    if math.isinf(v):
        return "+inf" if v > 0 else "-inf"
    if v == 0.0:
        return "0"
    return f"{v:.{_SIG}g}"


class Recorder:
    """
    Accumulate ``key -> value`` pairs for one fingerprint file.

    Keys are hierarchical, dot-separated, and always written sorted,
    so the output of two runs lines up under ``diff`` even if the
    probes execute in a different order.

    Attributes
    ----------
    rows : dict
        ``{key: formatted_value}``.
    """

    def __init__(self) -> None:
        self.rows: Dict[str, str] = {}

    def put(self, key: str, value) -> None:
        """
        Record one value.

        Parameters
        ----------
        key : str
        value : float, int, bool or str

        Raises
        ------
        KeyError
            If *key* was already recorded.  A duplicate key means two
            probes are silently overwriting each other, which would
            make the fingerprint depend on execution order.
        """
        if key in self.rows:
            raise KeyError(f"duplicate fingerprint key: {key}")
        self.rows[key] = _fmt(value)

    def fail(self, key: str, exc: BaseException) -> None:
        """
        Record a probe failure as a value.

        Parameters
        ----------
        key : str
        exc : BaseException
        """
        msg = str(exc).replace("\n", " ")[:110]
        self.rows[key] = f"!{type(exc).__name__}: {msg}"

    def dump(self, path: str) -> None:
        """
        Write the fingerprint file.

        Parameters
        ----------
        path : str
        """
        lines = [f"{k} = {self.rows[k]}" for k in sorted(self.rows)]
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("# GenSec numeric fingerprint\n")
            fh.write(f"# {len(lines)} values\n")
            fh.write("\n".join(lines) + "\n")


# ======================================================================
#  Probes
# ======================================================================

def _mesh_moments(rec: Recorder, tag: str, section) -> None:
    r"""
    Record raw mesh integrals.

    These are the discrete moments the fiber integrator actually sums,

    .. math::

        A = \sum_i A_i, \qquad
        S_y = \sum_i A_i x_i, \qquad
        S_x = \sum_i A_i y_i,

    .. math::

        I_{yy} = \sum_i A_i x_i^2, \qquad
        I_{xx} = \sum_i A_i y_i^2, \qquad
        I_{xy} = \sum_i A_i x_i y_i,

    taken about the global origin.  They change if and only if the
    mesh changes, so they separate a meshing regression from a
    constitutive one.

    Parameters
    ----------
    rec : Recorder
    tag : str
        Example identifier used as the key prefix.
    section : GenericSection
    """
    x = np.asarray(section.x_fibers, dtype=float)
    y = np.asarray(section.y_fibers, dtype=float)
    a = np.asarray(section.A_fibers, dtype=float)
    mi = np.asarray(section.mat_indices, dtype=int)

    rec.put(f"{tag}.mesh.n_fibers", int(x.size))
    rec.put(f"{tag}.mesh.A", float(a.sum()))
    rec.put(f"{tag}.mesh.Sy", float((a * x).sum()))
    rec.put(f"{tag}.mesh.Sx", float((a * y).sum()))
    rec.put(f"{tag}.mesh.Iyy_o", float((a * x * x).sum()))
    rec.put(f"{tag}.mesh.Ixx_o", float((a * y * y).sum()))
    rec.put(f"{tag}.mesh.Ixy_o", float((a * x * y).sum()))
    rec.put(f"{tag}.mesh.x_min", float(x.min()))
    rec.put(f"{tag}.mesh.x_max", float(x.max()))
    rec.put(f"{tag}.mesh.y_min", float(y.min()))
    rec.put(f"{tag}.mesh.y_max", float(y.max()))

    # Per-zone area: this is the quantity a zone/material re-keying
    # must leave untouched, and the one a zone-axis collapse moves.
    for z in sorted(set(int(v) for v in mi)):
        sel = mi == z
        rec.put(f"{tag}.mesh.zone[{z}].n", int(sel.sum()))
        rec.put(f"{tag}.mesh.zone[{z}].A", float(a[sel].sum()))

    rec.put(f"{tag}.geom.n_rebars", len(getattr(section, "rebars", []) or []))
    rec.put(f"{tag}.geom.n_tendons",
            len(getattr(section, "tendons", []) or []))
    rec.put(f"{tag}.geom.x_centroid", float(section.x_centroid))
    rec.put(f"{tag}.geom.y_centroid", float(section.y_centroid))


#: Strain planes at which the section response is sampled.
#:
#: ``eps0`` [-] is the strain at the reference point; ``chi_x`` and
#: ``chi_y`` [1/mm] are the curvatures.  The values span the service
#: range and reach into the non-linear branch of the concrete law
#: (:math:`\varepsilon_{c2} = -2 \times 10^{-3}`), so the probe is
#: sensitive to the constitutive path and not only to the elastic
#: stiffness.  A curvature of :math:`5 \times 10^{-6}\ \mathrm{mm}^{-1}`
#: over a 1 m depth is a fibre strain of :math:`\pm 2.5 \times 10^{-3}`.
_PLANES: Tuple[Tuple[float, float, float], ...] = (
    (0.0, 0.0, 0.0),
    (-2.0e-4, 0.0, 0.0),
    (-1.0e-3, 0.0, 0.0),
    (+1.0e-4, 0.0, 0.0),
    (0.0, 1.0e-6, 0.0),
    (0.0, 5.0e-6, 0.0),
    (0.0, -5.0e-6, 0.0),
    (0.0, 0.0, 1.0e-6),
    (0.0, 0.0, 5.0e-6),
    (-5.0e-4, 2.0e-6, 0.0),
    (-5.0e-4, 2.0e-6, 1.0e-6),
    (-1.5e-3, 5.0e-6, 2.0e-6),
)


def _direct_response(rec: Recorder, tag: str, solver) -> None:
    r"""
    Record :math:`(N, M_x, M_y)` at each prescribed strain plane.

    This is the *direct* problem — no iteration, no convergence
    tolerance, no initial guess — so the recorded numbers are a pure
    function of the mesh, the constitutive laws, the initial strains
    and the bonding masks.  Any of those moving moves these numbers;
    nothing else can.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    """
    for k, (eps0, cx, cy) in enumerate(_PLANES):
        key = f"{tag}.direct[{k:02d}]"
        try:
            N, Mx, My = solver.integrate(eps0, cx, cy)
            rec.put(f"{key}.N", float(N))
            rec.put(f"{key}.Mx", float(Mx))
            rec.put(f"{key}.My", float(My))
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{key}.N", exc)


#: Curvature directions, in degrees, at which the scan hull is
#: recorded.  ``0`` is bending about the x-axis, the direction the
#: uniaxial domain uses, and the one on which the ``_all_ly`` hull
#: alone decides the span; ``90`` swaps the roles and exercises
#: ``_all_lx``; ``45`` mixes them, so a defect confined to one array
#: cannot hide behind a compensating error in the other.
_HULL_DIRECTIONS: Tuple[int, ...] = (0, 45, 90)


def _scan_hull(rec: Recorder, tag: str, solver) -> None:
    r"""
    Record the **scan hull** and the curvature ceiling it produces.

    Why this probe exists
    ---------------------
    Defect **N-16** (ledger ``18_0`` section 2) is that
    :class:`~gensec.solver.capacity.NMDiagram` builds its lever-arm
    arrays ``_all_lx`` / ``_all_ly`` from bulk fibres and rebars only.
    A tendon outside the fibre hull - an external, non-embedded one -
    is therefore absent from the projected depth

    .. math::

        \mathrm{span}(\theta) = \max_i p_i(\theta)
                              - \min_i p_i(\theta),
        \qquad
        p_i(\theta) = l_{y,i}\cos\theta - l_{x,i}\sin\theta

    and hence from the curvature ceiling the scan is run up to,

    .. math::

        \chi_{\max}(\theta) =
            \frac{\varepsilon_{\max,\mathrm{global}}
                  - \varepsilon_{\min,\mathrm{bulk}}}
                 {\mathrm{span}(\theta)} .

    Neither ``span`` nor :math:`\chi_{\max}` appeared in any key of
    this fingerprint before Phase 19.  The rest of the battery records
    the *outputs* of the scan - domain extrema, moment-curvature
    events - which are integrals over the scan and can absorb a
    changed ceiling without moving detectably, or can fail to move at
    all when every distributed example has its tendons inside the
    hull.  Both quantities are recorded here directly, so the ceiling
    is observable independently of what the scan then does with it.

    A tool that cannot see the quantity a repair moves reports
    ``INERT``, and an ``INERT`` from a blind instrument is silence,
    not evidence.  This probe removes that particular silence.

    Scope
    -----
    Recorded only for sections that carry at least one tendon.  On a
    section without tendons the hull is bulk + rebar by construction
    and there is nothing N-16 could move, so adding keys there would
    enlarge the file without adding discrimination.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver

    Notes
    -----
    ``span`` is a length [mm] and :math:`\chi_{\max}` a curvature
    [1/mm]; both are direct evaluations of cached arrays, so this
    probe adds no solve and no tolerance to the battery.
    """
    from gensec.solver.capacity import NMDiagram

    key = f"{tag}.scan_hull"
    sec = solver.sec
    tendons = getattr(sec, "tendons", None) or []
    if not tendons:
        return
    rec.put(f"{key}.n_tendons", int(len(tendons)))

    try:
        nm = NMDiagram(solver)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{key}.ly_min", exc)
        return

    lx = np.asarray(nm._all_lx, dtype=float)
    ly = np.asarray(nm._all_ly, dtype=float)
    rec.put(f"{key}.lx_min", float(lx.min()))
    rec.put(f"{key}.lx_max", float(lx.max()))
    rec.put(f"{key}.ly_min", float(ly.min()))
    rec.put(f"{key}.ly_max", float(ly.max()))

    # The two strain values the ceiling is built from, recorded so a
    # movement in chi_max can be attributed to the span or to the
    # envelope without re-deriving it.
    rec.put(f"{key}.eps_max_global", float(nm._exg))
    rec.put(f"{key}.eps_min_bulk", float(nm._emb))

    for deg in _HULL_DIRECTIONS:
        theta = math.radians(deg)
        sub = f"{key}.dir[{deg:03d}]"
        try:
            chi_max, span, p_min = nm._chi_max_for_direction(
                math.cos(theta), math.sin(theta), lx, ly)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{sub}.span", exc)
            continue
        rec.put(f"{sub}.span", float(span))
        rec.put(f"{sub}.chi_max", float(chi_max))
        rec.put(f"{sub}.p_min", float(p_min))


def _domain(rec: Recorder, tag: str, solver) -> None:
    r"""
    Record extrema and sampled points of the ULS interaction domain.

    The full :math:`N`–:math:`M_x` boundary is generated and reduced to
    a fixed set of scalars: the axial extrema, the maximum and minimum
    bending capacity, and the boundary point at eight evenly spaced
    positions along the generated sequence.  Recording every point
    would bloat the file without adding discrimination — a change that
    misses all eight samples and both extrema is not a change this
    project would call numeric movement.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    """
    from gensec.solver.capacity import NMDiagram

    key = f"{tag}.domain"
    try:
        dom = NMDiagram(solver).generate(n_points=61, direction="x")
        N = np.asarray(dom["N"], dtype=float)
        M = np.asarray(dom["Mx"], dtype=float)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{key}.N_min", exc)
        return

    rec.put(f"{key}.n_points", int(N.size))
    rec.put(f"{key}.N_min", float(N.min()))
    rec.put(f"{key}.N_max", float(N.max()))
    rec.put(f"{key}.Mx_min", float(M.min()))
    rec.put(f"{key}.Mx_max", float(M.max()))
    if N.size:
        idx = np.linspace(0, N.size - 1, 8).astype(int)
        for j, i in enumerate(idx):
            rec.put(f"{key}.pt[{j}].N", float(N[i]))
            rec.put(f"{key}.pt[{j}].Mx", float(M[i]))


#: Axial levels at which the moment-curvature battery is captured [N].
#: ``0`` is pure bending, where a lightly compressed section cracks
#: below the first curvature step and the event is grid-saturated;
#: the compressed level is the one on which the cracking threshold is
#: actually resolved, and therefore the one that discriminates.
_MC_LEVELS: Tuple[float, ...] = (0.0, -1000.0e3)


def _moment_curvature(rec: Recorder, tag: str, solver) -> None:
    r"""
    Record the moment-curvature key points at fixed axial levels.

    Captured because the rest of this battery cannot see them.  The
    direct probe fixes a strain plane, the domain probe walks the ULS
    boundary and the equilibrium probe solves for demands: none of the
    three evaluates a *cracking* threshold, so a change in how
    :math:`\varepsilon_{cr}` is sourced moved nothing measurable in the
    fingerprint before Phase 14 added this function.  A fingerprint
    that is inert across a change it structurally cannot observe is
    silence, not evidence.

    For each level and each sign of curvature the recorded scalars are
    the curvature and moment at first cracking, first yield and the
    ultimate point, plus the cracking diagnosis string.  The diagnosis
    is recorded as a value in its own right: the absence of a marker is
    a fact about the section, and a battery that recorded only the
    numbers would report an absent marker and a present one as the
    same blank.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    """
    from gensec.solver.capacity import NMDiagram

    for level in _MC_LEVELS:
        label = f"{level / 1e3:+.0f}kN".replace("+", "p").replace("-", "m")
        key = f"{tag}.mchi[{label}]"
        try:
            mc = NMDiagram(solver).generate_moment_curvature(
                N_fixed=level, n_chi=400, direction="x")
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{key}.cracking_chi_pos", exc)
            continue

        for suffix in ("pos", "neg"):
            for event in ("cracking", "yield", "ultimate"):
                for quantity in ("chi", "M"):
                    name = f"{event}_{quantity}_{suffix}"
                    value = mc.get(name)
                    if value is None:
                        rec.put(f"{key}.{name}", "none")
                    else:
                        rec.put(f"{key}.{name}", float(value))
            diag = mc.get(f"diagnostics_{suffix}") or {}
            rec.put(f"{key}.cracking_reason_{suffix}",
                    str(diag.get("cracking_reason")))


def _staged_moment_curvature(rec: Recorder, tag: str, data: dict) -> None:
    r"""
    Record the moment-curvature key points on the **materialized** view
    of the last stage of the construction timeline.

    Added in Phase 15, and for the same reason Phase 14 added
    :func:`_moment_curvature`: the rest of this battery builds
    ``FiberSolver(section)`` on the **base** section, where
    ``bulk_planes_active`` is absent and the imposed-strain offset
    collapses to the scalar ``bulk_eps_init`` — normally zero.  Every
    quantity that depends on the locked-in eigenstrain planes of a cast
    sequence is therefore invisible to it, and a change to how those
    planes reach a strain criterion (F-M3) moves nothing it records.

    This probe walks the timeline, resolves the stage prefix of the
    **last** anchored combination point, materializes the view — the
    object ``NMDiagram(view)`` is documented to accept — and runs the
    same event battery on it.  On a section with a cast zone the datum
    plane is of the order of :math:`10^{-4}`, i.e. larger than
    :math:`\varepsilon_{cr}` itself, so the difference between the
    sectional and the mechanical strain is not rounding.

    An example with no ``construction_history``, no anchored
    combination, or a timeline that does not resolve records nothing
    here (a failure is recorded as a value, never raised): the base
    battery already covers it.

    Parameters
    ----------
    rec : Recorder
    tag : str
    data : dict
        The parsed model.
    """
    block = data.get("construction_history")
    if not block:
        return
    combos = [c for c in (data.get("combinations") or [])
              if c.get("at") is not None]
    if not combos:
        return

    from gensec.solver.capacity import NMDiagram
    from gensec.solver.integrator import FiberSolver
    from gensec.solver.section_state import (StagedDomainManager,
                                             materialize_view)
    from gensec.solver.timeline import ConstructionTimeline

    section = data["section"]
    ddb = {d["name"]: {"N": d.get("N", 0.0), "Mx": d.get("Mx", 0.0),
                       "My": d.get("My", 0.0)}
           for d in (data.get("demands") or [])}
    try:
        tl = ConstructionTimeline.from_block(
            block,
            losses_models=data.get("losses_models"),
            zone_rheology=data.get("zone_rheology"))
        resolution = tl.resolve(section, ddb)
        views = []
        # N-5 (Phase 16): the Phase-15 probe took ``combos[0]`` and the
        # LAST compiled point of it.  Every earlier anchored point, and
        # every further combination, was unobserved -- an intermediate
        # stage is exactly where a casting datum is youngest and a
        # criterion most sensitive.  All of them are walked now.
        for combo in combos:
            compiled = tl.compile_combination(combo, resolution,
                                              section, ddb)
            for point, stages, inactive in compiled:
                mgr = StagedDomainManager(section, biaxial=False,
                                          gen_kwargs={"n_points": 12})
                states, _h, _b, _d = mgr.resolve_stages(
                    stages, initially_inactive=inactive)
                views.append((point, materialize_view(section, states[-1])))
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.staged_mchi.build", exc)
        return
    seen = set()
    for point, view in views:
        if point in seen:
            continue
        seen.add(point)
        _staged_one_view(rec, tag, point, view)


def _staged_one_view(rec: Recorder, tag: str, point, view) -> None:
    r"""
    The event battery on one materialized stage view.

    Split out of :func:`_staged_moment_curvature` in Phase 16 so the
    caller can walk **every** anchored point of **every** combination
    instead of the single last point of the first one (N-5).

    Parameters
    ----------
    rec : Recorder
    tag : str
    point : str
        The combination point the view was materialized at.
    view : GenericSection
    """
    from gensec.solver.capacity import NMDiagram
    from gensec.solver.integrator import FiberSolver

    key = f"{tag}.staged_mchi[{point}]"
    planes = getattr(view, "bulk_planes_active", None)
    if planes is not None:
        arr = np.asarray(planes, dtype=float)
        for zi in range(arr.shape[0]):
            for name, value in zip(("eps0", "chi_x", "chi_y"), arr[zi]):
                rec.put(f"{key}.plane.zone[{zi:02d}].{name}", float(value))
    rec.put(f"{key}.bulk_eps_init",
            float(getattr(view, "bulk_eps_init", 0.0)))
    try:
        _decomposition_closure(rec, tag, FiberSolver(view), f"staged:{point}")
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.decompose[staged:{point}].build", exc)

    for level in _MC_LEVELS:
        label = f"{level / 1e3:+.0f}kN".replace("+", "p").replace("-", "m")
        sub = f"{key}[{label}]"
        try:
            mc = NMDiagram(FiberSolver(view)).generate_moment_curvature(
                N_fixed=level, n_chi=200, direction="x")
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{sub}.cracking_chi_pos", exc)
            continue
        for suffix in ("pos", "neg"):
            for event in ("cracking", "yield", "ultimate"):
                for quantity in ("chi", "M"):
                    name = f"{event}_{quantity}_{suffix}"
                    value = mc.get(name)
                    rec.put(f"{sub}.{name}",
                            "none" if value is None else float(value))
            diag = mc.get(f"diagnostics_{suffix}") or {}
            rec.put(f"{sub}.cracking_reason_{suffix}",
                    str(diag.get("cracking_reason")))
            rec.put(f"{sub}.cracking_zone_{suffix}",
                    str(diag.get("cracking_zone")))
        for name in ("eps_min", "eps_max"):
            arr = np.asarray(mc.get(name), dtype=float)
            finite = arr[np.isfinite(arr)]
            if finite.size:
                rec.put(f"{sub}.{name}.min", float(finite.min()))
                rec.put(f"{sub}.{name}.max", float(finite.max()))


def _decomposition_closure(rec: Recorder, tag: str, solver,
                           label: str = "base") -> None:
    r"""
    Record the **closure defect** of :meth:`AnalysisEngine._decompose`.

    Added in Phase 16, and for the reason Phase 15 had to add the staged
    M-:math:`\chi` probe: ``_decompose`` is a public output that no
    instrument observed.  Repairing an unobserved output produces an
    ``INERT`` that is silence, not proof.

    The quantity recorded is the one the decomposition claims:

    .. math::

        \Delta N = N_{\text{integrate}} - \sum_j N_j ,

    and likewise for :math:`M_x`, :math:`M_y`.  A decomposition that
    reproduces what it decomposes reads zero to the last bit; anything
    else is the size of the omission.  The absolute residual is
    recorded, not a ratio: a percentage against a near-cancelling
    denominator is not a stable measure of a defect (``15_0`` §1).

    The probe is run at a **fixed strain plane**, not at a solved one,
    so it measures the decomposition and never the solver: a change in
    convergence cannot move it.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    label : str, optional
        ``'base'`` for the raw section, ``'staged'`` for a materialized
        construction view.  Keeps the two photographs apart.
    """
    from gensec.solver.analysis import AnalysisEngine

    # Two planes, deliberately chosen off the tension branch and off the
    # plateau of the concrete law.  ``15_1`` §3 measured that a probe
    # landing on either gives the right stress from the wrong argument,
    # and a probe that cannot discriminate is not a probe.
    planes = ((-1.0e-4, -2.0e-6, 0.0), (-6.0e-4, -8.0e-6, 0.0))
    try:
        engine = AnalysisEngine(solver)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.decompose[{label}].build", exc)
        return

    for pi, (eps0, chi_x, chi_y) in enumerate(planes):
        sub = f"{tag}.decompose[{label}][{pi}]"
        try:
            comps = engine._decompose(eps0, chi_x, chi_y)
            N, Mx, My = solver.integrate(eps0, chi_x, chi_y)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{sub}.residual.N", exc)
            continue
        rec.put(f"{sub}.n_components", len(comps))
        rec.put(f"{sub}.types",
                ",".join(sorted({str(c.get("type")) for c in comps})))
        for name, total, key in (("N", N, "N"), ("Mx", Mx, "Mx"),
                                 ("My", My, "My")):
            part = float(sum(float(c.get(key, 0.0)) for c in comps))
            rec.put(f"{sub}.sum.{name}", part)
            rec.put(f"{sub}.residual.{name}", float(total) - part)


#: Ages at which the ageing probe reads the EC2 property table.  Three
#: of them sit below the three-day branch of ``fben2``, which is the
#: whole point: no distributed example reaches it, so without these
#: keys a change there is invisible to the instrument.
_AGEING_AGES = (0.5, 1.0, 2.0, 2.9, 3.0, 7.0, 28.0, 100.0)

#: Strength classes spanning both branches of Table 3.1 (<= C50 and
#: above) and both cement classes that change ``s``.
_AGEING_CASES = ((30.0, "N"), (30.0, "R"), (60.0, "N"))


def _material_ageing(rec: Recorder) -> None:
    r"""
    Record EN 1992-1-1 Table 3.1 properties across age, including
    :math:`t < 3` d.

    Added in Phase 16 for ``f_ctm(t<3d)``.  The defect had been carried
    open through five phases, and one reason it could be is that
    **nothing measured it**: no example and no test instantiates a
    concrete younger than three days, so a correction there moves no
    key of the pre-Phase-16 instrument and would read ``INERT``.

    Recorded per case and per age: :math:`\beta_{cc}`, :math:`f_{cm}`,
    :math:`f_{ck}`, :math:`f_{ctm}`, :math:`E_{cm}` and the cracking
    strain :math:`\varepsilon_{ct} = f_{ctm}/E_{cm}` — the quantity
    through which the tensile strength actually reaches a criterion.

    Parameters
    ----------
    rec : Recorder
    """
    from gensec.materials.ec2_properties import fben2

    for fck, cem in _AGEING_CASES:
        case = f"ageing.C{int(fck)}{cem}"
        for t in _AGEING_AGES:
            sub = f"{case}[t={t:g}d]"
            try:
                p = fben2(fck=fck, ls="S", loadtype="slow",
                          TypeConc=cem, time=t)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{sub}.fctm", exc)
                continue
            for name in ("beta_cc", "fcm", "fck", "fctm", "ecm",
                         "eps_ct", "fctk_005", "fctd_005"):
                rec.put(f"{sub}.{name}", float(getattr(p, name)))


#: Reduced strain levels at which expression (3.14) is sampled.  None is
#: the peak: at :math:`\eta = 1` the fraction collapses to
#: :math:`(k-1)/(k-1)` for any shape parameter, so a probe there is
#: structurally blind to the whole F-P26-0 family (26_0 §2).
_SARGIN_ETAS = (0.15, 0.35, 0.70, 0.95)


def _service_law(rec: Recorder) -> None:
    r"""
    Record EN 1992-1-1 expression (3.14) across age.

    Added in Phase 26.  Until then the service law had **no consumer in
    src/** — only its own doctest — so no example reached it and the
    pre-Phase-26 instrument was structurally blind to it: the F-P26-0
    repair reads ``INERT`` against every key of that instrument, which
    is silence and not proof.  This probe exists so that the law's
    arrival on a production path shows up as movements on keys that
    already exist, rather than as a block of additions nobody can
    compare against anything.

    Recorded per case and per age: the initial tangent and its ratio to
    :math:`E_{cm}(t)` — the identity :math:`E_0 = 1.05\,E_{cm}` that the
    shape parameter exists to produce — the shape parameter itself read
    back by algebra from a single point of the curve, and the stress at
    four reduced strains away from the peak.

    Below three days ``fben2`` reports :math:`f_{cm} = 0` as its own
    out-of-domain marker and the law refuses.  The refusal is recorded
    through :meth:`Recorder.fail`, so that *which* exception is raised
    is itself a datum: a change from an arithmetic accident to a named
    refusal is a movement, not an addition.

    Parameters
    ----------
    rec : Recorder
    """
    from gensec.materials.ec2_properties import fben2, en2sargin

    h = 1.0e-9
    for fck, cem in _AGEING_CASES:
        case = f"law.sargin.C{int(fck)}{cem}"
        for t in _AGEING_AGES:
            sub = f"{case}[t={t:g}d]"
            try:
                p = fben2(fck=fck, ls="S", loadtype="slow",
                          TypeConc=cem, time=t)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{sub}.E0", exc)
                continue
            try:
                e0 = (en2sargin(h, p) - en2sargin(-h, p)) / (2.0 * h)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{sub}.E0", exc)
                continue
            rec.put(f"{sub}.E0", float(e0))
            rec.put(f"{sub}.E0_over_ecm", float(e0 / p.ecm))
            for eta in _SARGIN_ETAS:
                s = float(en2sargin(eta * p.eps_c1, p))
                rec.put(f"{sub}.sig[eta={eta:g}]", s)
                # k solved from (3.14) at this single point; exact
                # wherever the stress is not the peak value.
                r = s / p.fcm
                if abs(1.0 - r) > 1.0e-12:
                    k = (r * (1.0 - 2.0 * eta) + eta * eta) / (eta * (1.0 - r))
                    rec.put(f"{sub}.k[eta={eta:g}]", float(k))

#: Multiples of :math:`\varepsilon_{ct}` at which the tension branch of
#: the service law is sampled.  One below the cap, one *at* it, and two
#: above: the cap is the only place where the law is discontinuous, and
#: a probe that never crosses it cannot see whether it is still there.
#: The labels are written out rather than formatted from the value:
#: ``%g`` renders both ``1.0`` and ``1.000001`` as ``1``, which would
#: collide the two keys that straddle the cap — the one pair the probe
#: exists for.  ``Recorder.put`` refuses a duplicate key, so the
#: collision was loud; a silently overwriting recorder would have left
#: the cap unmeasured and the probe looking complete.
_SERVICE_TENSION_RATIOS = (("0.5", 0.5),
                           ("1.0", 1.0),
                           ("1+1e-6", 1.0 + 1.0e-6),
                           ("2.0", 2.0))


def _service_concrete(rec: Recorder) -> None:
    r"""
    Record the :class:`~gensec.materials.service_concrete.ServiceConcrete`
    law as an object, across age.

    Added in Phase 27 for **D26-8**.  Phase 26 built the law and probed
    the *expression* it rests on — :func:`en2sargin`, under
    ``law.sargin.*`` — but not the class that carries it.  The class was
    reachable only from its own tests, so nothing on a production path
    measured it, and a law arriving on a path the instrument cannot see
    moves no key the instrument can read.  ``INERT`` from a blind
    instrument is silence, not proof (``26_0`` §7).  This probe is
    therefore written **before** the wiring of D26-7, not after it, so
    that the wiring shows up as movement on keys that already exist on
    both trees.

    What is recorded, per strength class and per age
    ------------------------------------------------
    The **initial tangent** :math:`E_0` and its ratio to :math:`E_{cm}`.
    The identity :math:`E_0 = 1.05\,E_{cm}` is what the shape parameter
    :math:`k` exists to produce and what the tension branch is given so
    that the law is :math:`C^1` at zero strain; a drift in either branch
    breaks it, and the ratio is the single number that says so.

    The **stress at four reduced strains**, :math:`\eta = 0.15, 0.35,
    0.70, 0.95`, and never at the peak.  At :math:`\eta = 1` the
    fraction of expression (3.14),

    .. math::

        \frac{k\eta - \eta^{2}}{1 + (k-2)\eta} ,

    collapses to :math:`(k-1)/(k-1) = 1` for **every** :math:`k`, so a
    probe placed on the peak is structurally blind to the entire
    shape-parameter defect family — which is exactly how F-P26-0
    survived five phases.

    The **cracking strain** :math:`\varepsilon_{ct} =
    f_{ct,\mathrm{eff}}/(1.05\,E_{cm})`, together with
    :attr:`~gensec.materials.service_concrete.ServiceConcrete.eps_max`,
    which must equal it: the admissible range of this material is not a
    scan hint but the true edge of its contribution.

    The **behaviour across the cap**: stress and tangent at
    :math:`0.5\,\varepsilon_{ct}`, at :math:`\varepsilon_{ct}` itself,
    one part in :math:`10^{6}` above it, and at
    :math:`2\,\varepsilon_{ct}`.  The stress at the cap must be
    :math:`f_{ct,\mathrm{eff}}` and everything beyond it must be zero;
    the pair straddling the cap is what makes the brittle drop a
    measured fact rather than a described one.

    The **refusal below three days**, through :meth:`Recorder.fail`, so
    that *which* exception is raised is itself a datum.  ``fben2``
    reports :math:`f_{cm} = 0` below three days as the marker of its own
    domain; the law refuses to build a curve through a null strength,
    and a change from one exception type to another is a movement on an
    existing key rather than an addition nobody can compare.

    Notes
    -----
    ``fct_eff`` is **declared** by this probe as :math:`f_{ctm}` at the
    same age, and the declaration is part of the measurement: the class
    has no default for it, and which tensile strength is meant is a
    choice with consequences.

    Parameters
    ----------
    rec : Recorder
    """
    from gensec.materials.ec2_properties import fben2
    from gensec.materials.service_concrete import ServiceConcrete

    for fck, cem in _AGEING_CASES:
        case = f"law.service.C{int(fck)}{cem}"
        for t in _AGEING_AGES:
            sub = f"{case}[t={t:g}d]"
            try:
                p = fben2(fck=fck, ls="S", loadtype="slow",
                          TypeConc=cem, time=t)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{sub}.E0", exc)
                continue
            try:
                law = ServiceConcrete(
                    fcm=float(p.fcm), Ecm=float(p.ecm),
                    eps_c1=float(p.eps_c1), eps_cu1=float(p.eps_cu1),
                    fct_eff=float(p.fctm), reference_age=float(t),
                    name=f"C{int(fck)}{cem} service @{t:g}d")
            except Exception as exc:        # noqa: BLE001 — failure is data
                # The refusal is the datum.  Below three days fben2
                # reports fcm = 0 and eps_c1 = 0, and the law declines
                # to draw a curve through a null strength.
                rec.fail(f"{sub}.E0", exc)
                continue

            # --- the two constants the whole law is pinned on ---------
            rec.put(f"{sub}.E0", float(law.initial_tangent))
            rec.put(f"{sub}.E0_over_ecm",
                    float(law.initial_tangent / p.ecm))
            rec.put(f"{sub}.k", float(law.k))
            rec.put(f"{sub}.ref_modulus",
                    float(law.reference_modulus().value))

            # --- compression, away from the peak ----------------------
            for eta in _SARGIN_ETAS:
                e = -eta * law.eps_c1
                rec.put(f"{sub}.sig[eta={eta:g}]", float(law.stress(e)))
                rec.put(f"{sub}.Et[eta={eta:g}]", float(law.tangent(e)))

            # --- the admissible range ---------------------------------
            rec.put(f"{sub}.eps_ct", float(law.eps_ct))
            rec.put(f"{sub}.eps_max", float(law.eps_max))
            rec.put(f"{sub}.eps_min", float(law.eps_min))

            # --- tension, straddling the cap --------------------------
            for label, r in _SERVICE_TENSION_RATIOS:
                e = r * law.eps_ct
                rec.put(f"{sub}.sig[ect*{label}]", float(law.stress(e)))
                rec.put(f"{sub}.Et[ect*{label}]", float(law.tangent(e)))


#: Canonical probe section for the SLS path: the 400 x 1200 rectangle
#: every published measurement of this defect family is written on
#: (``22_0`` §1.1, ``26_0`` §3.3), with a symmetric pair of rebar
#: layers so that a tension chord exists and cracking has something to
#: hand the tension to.
_SLS_B, _SLS_H, _SLS_NFY = 400.0, 1200.0, 240
_SLS_AS, _SLS_Y1, _SLS_Y2 = 2000.0, 60.0, 1140.0

#: Bending moments [N*mm] at which the SLS path is driven, at a
#: constant axial force of -1000 kN.  The cracking moment of this
#: section sits between them: 300 kNm is below it and 900 kNm well
#: above, so the pair brackets the state change the phase is about.
_SLS_MOMENTS = ((300.0e6, "300"), (900.0e6, "900"))
_SLS_N = -1000.0e3

#: Nominal ultimate compressive strain magnitude handed to the probe's
#: :class:`~gensec.materials.service_concrete.ServiceConcrete`.  Stated
#: here rather than derived, because this file is an instrument and not
#: a normative module: it declares what it measures with, and a
#: constant that appears inside a probe body is a constant nobody can
#: find when a value moves.
_SLS_EPS_CU1 = 0.0035


def _sls_law_at(material, eps, target, np_mod):
    r"""
    The stress this law returns *near* one strain, nearest to *target*.

    Why "near" and not "at"
    -----------------------
    A cracking law is **discontinuous**: it reaches
    :math:`f_{ct,\mathrm{eff}}` at :math:`\varepsilon_{ct}` and returns
    zero immediately beyond.  The maximum of such a function over a
    region is attained *at* the jump, so the point the engine names sits
    exactly on it — and re-deriving that point's strain here, from the
    reported plane and coordinates, is a different arithmetic path from
    the one the engine used.  A few ulps to the wrong side and this
    probe reads zero where the engine correctly read
    :math:`f_{ct,\mathrm{eff}}`, and the fingerprint reports a defect
    that is its own.

    Evaluating on both sides and keeping the value nearest the reported
    one measures what is meant: **how far the reported stress is from
    the graph of the law** in the neighbourhood of the named point.  It
    does not weaken the probe — a stress genuinely off the curve is off
    it on both sides, which is what the falsification runs confirm.

    Parameters
    ----------
    material : Material
    eps : float
    target : float
        The reported stress the comparison is against [MPa].
    np_mod : module
        The ``numpy`` module, passed in because the probes import it
        locally.

    Returns
    -------
    float
    """
    cand = [float(np_mod.asarray(material.stress_array(
        np_mod.array([e], dtype=float)))[0])
        for e in (eps, eps * (1.0 - 1.0e-12), eps * (1.0 + 1.0e-12))]
    return min(cand, key=lambda v: abs(v - target))


def _sls_consistency_kwargs(fn, value=False):
    r"""
    The keyword this build of ``verify_sls_staged`` publishes for its
    internal consistency cross-check, as a keyword mapping.

    Read from the signature rather than assumed.  Phase 28 removes the
    check — the two bookkeepings it compared became one — so on the
    repaired tree there is no keyword and the mapping is empty.  An
    instrument that hard-coded the name would raise ``TypeError`` on one
    of the two trees, and a probe that cannot run on both trees measures
    nothing.

    Parameters
    ----------
    fn : callable
    value : bool, optional

    Returns
    -------
    dict
    """
    import inspect
    params = inspect.signature(fn).parameters
    for flag in ("debug_check_strain_field", "debug_check_affine"):
        if flag in params:
            return {flag: value}
    return {}


def _sls_consistency_flag_name(fn):
    r"""
    The same keyword, as a token, or ``"absent"``.

    Recorded as a value so that its removal is a movement on a key that
    exists on both trees rather than a key that vanishes from one.

    Parameters
    ----------
    fn : callable

    Returns
    -------
    str
    """
    import inspect
    params = inspect.signature(fn).parameters
    for flag in ("debug_check_strain_field", "debug_check_affine"):
        if flag in params:
            return flag
    return "absent"


def _sls_staged(rec: Recorder) -> None:
    r"""
    Record :func:`~gensec.solver.sls.verify_sls_staged` on a section
    that crosses its own cracking moment.

    Added in Phase 27, and synthetic on purpose.  Reachability was
    measured rather than assumed: over a whole capture the instrument
    crosses :func:`~gensec.solver.sls.sls_view` **80 times** — 48 at
    ``posttension.py:1280``, 22 at ``posttension.py:1733``, 6 at
    ``losses.py:983`` and 4 at ``timeline.py:1416`` — and **zero**
    times at either of the two sites inside ``verify_sls_staged``.
    The reason is structural and not accidental: Phase 7 closed with
    decision D5, *API only, no YAML wiring* (``9_0`` §1), so no
    distributed model reaches the stress verification at all.  "PRE on
    every distributed model" therefore cannot cover it, and a probe
    driven from ``examples/`` never will.

    Without this probe the removal of the linear substitution inside
    ``verify_sls_staged`` would read ``INERT`` on all three
    fingerprints, which is silence and not proof (``26_0`` §7).

    What is recorded
    ----------------
    Two single-stage runs at :math:`N = -1000` kN and
    :math:`M_x = 300` and :math:`900` kNm, and one two-stage run that
    reaches the same 900 kNm as :math:`300 + 600`.  The pair brackets
    the cracking moment, and the two-stage run exercises the
    incremental accumulation of decision D2 — stage stresses as sums of
    per-stage increments — which the single-stage runs do not.

    Per stage: the solved plane :math:`(\varepsilon_0, \chi_x)`, the
    extreme concrete stresses and the coordinates they occur at, the
    accumulated stress in every element, and the verdict.

    The flag ``uncracked_basis_violated`` is recorded through
    :meth:`dict.get` with a literal ``"absent"``, **not** conditionally
    on its presence.  Phase 27 removes the flag; recorded this way its
    removal is a *movement* on a key that exists on both trees rather
    than a key that vanishes from one of them.

    Notes
    -----
    On the tree this probe was written against, the 900 kNm run reports
    a maximum concrete stress of :math:`+6.53` MPa on a C35/45 whose
    :math:`f_{ctm}` is :math:`3.21` MPa.  That is the defect of this
    phase expressed as a number: a state no concrete is in, produced by
    a straight line substituted for the material behind the model's
    back.

    Parameters
    ----------
    rec : Recorder
    """
    import numpy as _np

    from gensec.geometry.fiber import RebarLayer
    from gensec.geometry.section import RectSection
    from gensec.materials.concrete import Concrete
    from gensec.materials.ec2_properties import fben2
    from gensec.materials.elastic import LinearElastic
    from gensec.materials.steel import Steel
    from gensec.materials.verification_limits import StressLimits
    from gensec.solver.section_state import SectionState
    from gensec.solver.sls import verify_sls_staged

    try:
        p = fben2(fck=35.0, ls="S", loadtype="slow", TypeConc="N",
                  time=28.0)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail("sls.build", exc)
        return

    ecm, fctm = float(p.ecm), float(p.fctm)
    rec.put("sls.declared_Ecm", ecm)
    rec.put("sls.declared_fct_eff", fctm)

    conc = Concrete(fck=35.0, gamma_c=1.5,
                    long_term_reduction_factor=0.85)
    conc.name = "C35svc"
    steel = Steel(fyk=450.0)
    steel.name = "B450C"
    xr, yr = _SLS_B / 2.0, _SLS_H / 2.0
    rebars = [RebarLayer(y=_SLS_Y1, As=_SLS_AS, material=steel, x=xr),
              RebarLayer(y=_SLS_Y2, As=_SLS_AS, material=steel, x=xr)]
    section = RectSection(_SLS_B, _SLS_H, conc, rebars,
                          n_fibers_y=_SLS_NFY)
    moduli = {"C35svc": ecm}
    # Phase 30: fct_eff removed from StressLimits.  ``fctm`` is still
    # recorded under sls.declared_fct_eff above, and still reaches the
    # engine through the service law, which is the only place it was
    # ever read.
    # Phase 32: the coefficient, not the product.  On this bench the
    # zone is C35, so the derived limit is 0.6 * 35 = 21.0 -- the
    # exact number the deleted field carried.  These keys must stay
    # INERT across the repair, and that inertness is a discriminant:
    # a movement here would mean the derivation changed a value it
    # was supposed to reproduce.
    limits = StressLimits(k_c=0.6,
                          sigma_s_tens=0.8 * 450.0)

    def _state(idx, label):
        return SectionState(idx,
                            _np.ones(2, dtype=bool),
                            _np.ones(2, dtype=bool),
                            _np.zeros(2, dtype=float),
                            bulk_eps_init=0.0, label=label)

    def _record(prefix, res):
        rec.put(f"{prefix}.verified", str(res.get("verified")))
        for k, sr in enumerate(res["stages"]):
            sub = f"{prefix}.stage{k}"
            plane = sr["plane"]
            rec.put(f"{sub}.eps0", float(plane["eps0"]))
            rec.put(f"{sub}.chi_x", float(plane["chi_x"]))
            conc_r = sr["concrete"]
            rec.put(f"{sub}.sig_c_min", float(conc_r["sigma_min_MPa"]))
            rec.put(f"{sub}.sig_c_max", float(conc_r["sigma_max_MPa"]))
            rec.put(f"{sub}.y_at_sig_c_max",
                    float(conc_r["at_max"][1]))
            for el in sr["elements"]:
                rec.put(f"{sub}.sig_el[{el['union_index']}]",
                        float(el["sigma_MPa"]))
            # Recorded with a literal default rather than a presence
            # test: the flag is removed in this phase, and a movement
            # to "absent" is readable where a vanished key is not.
            rec.put(f"{sub}.basis_violated",
                    str(sr.get("uncracked_basis_violated", "absent")))

    for m, label in _SLS_MOMENTS:
        prefix = f"sls.single[M={label}]"
        try:
            res = verify_sls_staged(
                section,
                [{"name": "svc", "state": _state(0, "svc"),
                  "increment": (_SLS_N, m, 0.0), "limits": limits}],
                moduli=moduli, x_ref=xr, y_ref=yr)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{prefix}.verified", exc)
            continue
        _record(prefix, res)

    prefix = "sls.staged"
    try:
        res = verify_sls_staged(
            section,
            [{"name": "a", "state": _state(0, "a"),
              "increment": (_SLS_N, 300.0e6, 0.0), "limits": limits},
             {"name": "b", "state": _state(1, "b"),
              "increment": (0.0, 600.0e6, 0.0), "limits": limits}],
            moduli=moduli, x_ref=xr, y_ref=yr)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{prefix}.verified", exc)
    else:
        _record(prefix, res)

    # ==============================================================
    #  Phase 28 — the staged accumulation, probed on a law that is
    #  not a straight line.
    # ==============================================================
    # Everything above declares a *modulus*, which since Phase 27
    # means ``LinearElastic`` at that modulus (``27_0`` §4).  On a
    # straight line the stress superposition of decision D2 is exact,
    # so the block above cannot see D27-1 and is not meant to: it is
    # the **discriminator**.  Its values must not move when the
    # accumulation is rewritten; if they do, the rewrite has an
    # implementation error and not a modelling one.
    #
    # The block below declares a ``ServiceConcrete`` — the same
    # concrete, the same age, its own law — so the same three runs go
    # through the general path with a curve instead of a line.
    #
    # What is recorded, and why this quantity and not the one the
    # phase prompt proposed
    # ---------------------------------------------------------------
    # The prompt proposed the difference between the accumulated
    # stress and the stress re-read from the law at the final solved
    # plane.  Measured before anything was written, that difference is
    # **2.220446e-16 MPa** on the two-stage run above with the service
    # law, over 1200 fibres, with zero fibres moved: with an unchanging
    # view the per-stage increments telescope at the level of the
    # *plane*, and the plane is affine whatever the material is,
    # because the kinematics are linear even when the law is not.  It
    # becomes non-zero only under ageing moduli, and there it is
    # non-zero on the straight line too (1.966954e-02 MPa), where D2
    # says it should be.  It therefore discriminates nothing, and a
    # probe built on it would have read INERT and called it proof.
    #
    # The quantity recorded instead is the **law residual**: the
    # extreme concrete stress the engine reports, minus the stress the
    # zone's own law returns at the strain of the point the engine says
    # it occurred at.  A reported stress that is not a point of the
    # constitutive law is the defect stated as a number, and it does
    # not depend on how the bookkeeping is organised internally.
    # Measured on the pristine tree: **-1.526836 MPa** at the
    # compressed edge and **+58.762052 MPa** at the cracked edge of the
    # 900 kNm run, on a concrete whose f_ctm is 3.209962 MPa.  On the
    # straight line it is zero, before and after.
    #
    # ``debug_check_affine`` is recorded as its own outcome token
    # rather than left to abort the run: with its default of ``True``
    # the pristine engine raises ``AssertionError`` on the *first*
    # stage of the service-law run, so every value key of this family
    # would be absent from one tree and present on the other.  Which
    # diagnosis arrives is itself a datum, so it is recorded; the value
    # keys are then produced with the check switched off, so that they
    # exist on both trees and can move.
    from gensec.materials.service_concrete import ServiceConcrete

    try:
        svc = ServiceConcrete(
            fcm=float(p.fcm), Ecm=ecm, eps_c1=abs(float(p.eps_c1)),
            eps_cu1=_SLS_EPS_CU1, fct_eff=fctm, reference_age=28.0,
            name="C35svc")
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail("sls.svc.build", exc)
        return
    rec.put("sls.svc.k", float(svc.k))
    rec.put("sls.svc.eps_ct", float(svc.eps_ct))

    def _law_residual(prefix_, res_, law):
        r"""
        Record, per stage, how far the reported extremes are from the
        material law.

        The strain at a point is read from the stage's own solved
        plane, which is what both the affine stress field and the
        accumulated strain field telescope to on this history; the
        stress is then the law evaluated there.  Zero means the engine
        reported a stress the declared concrete can actually be in.
        """
        for k_, sr_ in enumerate(res_["stages"]):
            sub = f"{prefix_}.stage{k_}"
            pl = sr_["plane"]
            for tag, skey, akey in (("min", "sigma_min_MPa", "at_min"),
                                    ("max", "sigma_max_MPa", "at_max")):
                x_a, y_a = sr_["concrete"][akey]
                eps = (float(pl["eps0"])
                       + float(pl["chi_x"]) * (float(y_a) - yr)
                       - float(pl["chi_y"]) * (float(x_a) - xr))
                rep = float(sr_["concrete"][skey])
                sig_law = _sls_law_at(law, eps, rep, _np)
                rec.put(f"{sub}.eps_at_{tag}", eps)
                rec.put(f"{sub}.law_sigma_{tag}", sig_law)
                rec.put(f"{sub}.law_residual_{tag}", rep - sig_law)

    _lin_law = LinearElastic(E=ecm)
    for m, label in _SLS_MOMENTS:
        for family, mat, law_obj in (("res", moduli["C35svc"], _lin_law),
                                     ("svc", svc, svc)):
            prefix = f"sls.{family}.single[M={label}]"
            try:
                r = verify_sls_staged(
                    section,
                    [{"name": "svc", "state": _state(0, "svc"),
                      "increment": (_SLS_N, m, 0.0), "limits": limits}],
                    moduli={"C35svc": mat}, x_ref=xr, y_ref=yr,
                    **_sls_consistency_kwargs(verify_sls_staged))
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{prefix}.verified", exc)
                continue
            if family == "svc":
                _record(prefix, r)
            _law_residual(prefix, r, law_obj)

    _staged_stages = [
        {"name": "a", "state": _state(0, "a"),
         "increment": (_SLS_N, 300.0e6, 0.0), "limits": limits},
        {"name": "b", "state": _state(1, "b"),
         "increment": (0.0, 600.0e6, 0.0), "limits": limits},
    ]
    for prefix, mat, law_obj in (
            ("sls.res.staged", moduli["C35svc"], _lin_law),
            ("sls.svc.staged", svc, svc)):
        try:
            r = verify_sls_staged(section, _staged_stages,
                                  moduli={"C35svc": mat},
                                  x_ref=xr, y_ref=yr,
                                  **_sls_consistency_kwargs(
                                      verify_sls_staged))
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{prefix}.verified", exc)
            continue
        if prefix.startswith("sls.svc"):
            _record(prefix, r)
        _law_residual(prefix, r, law_obj)

    # The outcome of the internal consistency check at its own default,
    # on both materials.  A token, because *which* diagnosis arrives is
    # the datum: on the pristine tree the line passes and the curve
    # aborts on the first stage.
    for tok, mat in (("lin", moduli["C35svc"]), ("svc", svc)):
        try:
            verify_sls_staged(section, _staged_stages,
                              moduli={"C35svc": mat},
                              x_ref=xr, y_ref=yr)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"sls.selfcheck[{tok}]", exc)
        else:
            rec.put(f"sls.selfcheck[{tok}]", "passed")


_SLS_NL_AGE = 28.0


def _sls_nl_section():
    r"""
    Build the reference section of the Phase-28 probe, once.

    Returns
    -------
    tuple
        ``(section, x_ref, y_ref, limits, service_law, Ecm)``.
    """
    from gensec.geometry.fiber import RebarLayer
    from gensec.geometry.section import RectSection
    from gensec.materials.concrete import Concrete
    from gensec.materials.ec2_properties import fben2
    from gensec.materials.service_concrete import ServiceConcrete
    from gensec.materials.steel import Steel
    from gensec.materials.verification_limits import StressLimits

    p = fben2(fck=35.0, ls="S", loadtype="slow", TypeConc="N",
              time=_SLS_NL_AGE)
    law = ServiceConcrete(fcm=float(p.fcm), Ecm=float(p.ecm),
                          eps_c1=abs(float(p.eps_c1)), eps_cu1=0.0035,
                          fct_eff=float(p.fctm),
                          reference_age=_SLS_NL_AGE, name="C35svc")
    conc = Concrete(fck=35.0, gamma_c=1.5,
                    long_term_reduction_factor=0.85)
    conc.name = "C35svc"
    steel = Steel(fyk=450.0)
    steel.name = "B450C"
    xr, yr = _SLS_B / 2.0, _SLS_H / 2.0
    rebars = [RebarLayer(y=_SLS_Y1, As=_SLS_AS, material=steel, x=xr),
              RebarLayer(y=_SLS_Y2, As=_SLS_AS, material=steel, x=xr)]
    section = RectSection(_SLS_B, _SLS_H, conc, rebars,
                          n_fibers_y=_SLS_NFY)
    # Phase 30: fct_eff is no longer a stress limit; the law above
    # carries it, which is where the engine reads it.
    # Phase 32: the coefficient, not the product.  This bench is
    # single-zone C35, so 0.6 * 35 = 21.0 is derived and these keys
    # must stay INERT -- the derivation reproducing the number the
    # deleted field carried is the discriminant.
    limits = StressLimits(k_c=0.6,
                          sigma_s_tens=0.8 * 450.0)
    return section, xr, yr, limits, law, float(p.ecm)


def _sls_nonlinear(rec: Recorder) -> None:
    r"""
    Probe the staged SLS accumulation on a **non-linear** declaration.

    Added in Phase 28 for defect D27-1.  :func:`_sls_staged` (Phase 27)
    declares its zone with a bare **number**, which since Phase 27 means
    :class:`~gensec.materials.elastic.LinearElastic`; that run is
    therefore a straight line from end to end and cannot see an
    accumulation scheme that is exact on straight lines.  This probe runs
    the same history twice — once declaring the line, once declaring
    :class:`~gensec.materials.service_concrete.ServiceConcrete` — so that
    the linear run is the **discriminator** (it must not move) and the
    service run is the **defect** (it must).

    What is recorded, per declaration and per history
    -------------------------------------------------
    ``report.sig_min`` / ``report.sig_max``
        The extreme concrete stresses ``verify_sls_staged`` reports.
    ``law.sig_at_min`` / ``law.sig_at_max``
        The **independent re-read**: the declared material evaluated at
        the strain the reported solved plane produces at the very point
        the report names.  Computed here, from the plane and the
        material, and touching none of the machinery under repair — so
        it is the same number before and after, and the *gap* below is
        the defect expressed as a number.
    ``gap.sig_min`` / ``gap.sig_max``
        ``report - law``.  Zero on the discriminator before and after;
        non-zero on the service declaration today and zero after the
        repair, to the declared tolerance.
    ``check.value`` / ``check.eta``
        What ``concrete_compression`` actually verified, which is not
        always what the report printed (F6 is applied to the report and
        not to the check; that is a **separate, open** defect and this
        probe measures it rather than repairing it).
    ``outcome``
        The exception class name — or ``ok`` — of a run made with the
        function's own **default** consistency flag.  Today the affine
        cross-check is on by default and the service run aborts, so this
        key is the measure of "the function cannot complete on the law
        Phase 27 delivered".

    ``consistency_flag`` names which keyword the function publishes for
    its internal cross-check, read from the signature rather than
    guessed, so that the rename is a movement on a key that exists on
    both trees rather than a ``TypeError`` in the instrument.

    Parameters
    ----------
    rec : Recorder
    """
    import numpy as _np

    from gensec.materials.elastic import LinearElastic
    from gensec.solver.section_state import SectionState
    from gensec.solver.sls import verify_sls_staged

    try:
        (section, xr, yr, limits,
         law, ecm) = _sls_nl_section()
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail("sls_nl.build", exc)
        return

    flag = _sls_consistency_flag_name(verify_sls_staged)
    rec.put("sls_nl.consistency_flag", flag)

    def _state(idx, label):
        return SectionState(idx,
                            _np.ones(2, dtype=bool),
                            _np.ones(2, dtype=bool),
                            _np.zeros(2, dtype=float),
                            bulk_eps_init=0.0, label=label)

    def _histories():
        return {
            "single": [{"name": "one", "state": _state(0, "one"),
                        "increment": (_SLS_N, 900.0e6, 0.0),
                        "limits": limits}],
            "staged": [{"name": "a", "state": _state(0, "a"),
                        "increment": (_SLS_N, 300.0e6, 0.0),
                        "limits": limits},
                       {"name": "b", "state": _state(1, "b"),
                        "increment": (0.0, 600.0e6, 0.0),
                        "limits": limits}],
        }

    def _eps_at(plane, x, y):
        # The fibre kernel's strain field about (x_ref, y_ref).
        return (plane["eps0"] + plane["chi_x"] * (y - yr)
                - plane["chi_y"] * (x - xr))

    for decl, mat in (("lin", LinearElastic(E=ecm)), ("svc", law)):
        moduli = {"C35svc": mat}
        for hist, stages in _histories().items():
            pre = f"sls_nl.{decl}.{hist}"

            # 1. The default-flag run: does the function complete at all?
            try:
                verify_sls_staged(section, stages, moduli=moduli,
                                  x_ref=xr, y_ref=yr)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.put(f"{pre}.outcome", type(exc).__name__)
            else:
                rec.put(f"{pre}.outcome", "ok")

            # 2. The numeric run, with the cross-check switched off so
            #    that the numbers exist on both trees.  A key that
            #    vanishes from one tree is not a movement.
            kw = _sls_consistency_kwargs(verify_sls_staged)
            try:
                res = verify_sls_staged(section, stages, moduli=moduli,
                                        x_ref=xr, y_ref=yr, **kw)
            except Exception as exc:        # noqa: BLE001 — failure is data
                rec.fail(f"{pre}.numeric", exc)
                continue
            sr = res["stages"][-1]
            plane = sr["plane"]
            rec.put(f"{pre}.plane.eps0", float(plane["eps0"]))
            rec.put(f"{pre}.plane.chi_x", float(plane["chi_x"]))
            conc_r = sr["concrete"]
            s_min = float(conc_r["sigma_min_MPa"])
            s_max = float(conc_r["sigma_max_MPa"])
            rec.put(f"{pre}.report.sig_min", s_min)
            rec.put(f"{pre}.report.sig_max", s_max)
            rec.put(f"{pre}.report.y_at_min", float(conc_r["at_min"][1]))
            rec.put(f"{pre}.report.y_at_max", float(conc_r["at_max"][1]))
            for tag, pt, rep in (("min", conc_r["at_min"], s_min),
                                 ("max", conc_r["at_max"], s_max)):
                e = _eps_at(plane, float(pt[0]), float(pt[1]))
                sig = _sls_law_at(mat, e, rep, _np)
                rec.put(f"{pre}.law.sig_at_{tag}", sig)
                rec.put(f"{pre}.gap.sig_{tag}", rep - sig)
            for el in sr["elements"]:
                rec.put(f"{pre}.sig_el[{el['union_index']}]",
                        float(el["sigma_MPa"]))
            ck = [c for c in sr.get("checks", [])
                  # Phase 32: the check is named per zone
                  # (``concrete_compression[base]``), so the bare name
                  # is matched on the stem.  Without this the probe
                  # reports ``absent`` for a check that ran, which is
                  # the instrument going blind at exactly the moment
                  # the thing it watches changed shape.
                  if (c.get("name", "").split("[")[0]
                      == "concrete_compression")]
            if ck:
                rec.put(f"{pre}.check.value", float(ck[0]["value_MPa"]))
                rec.put(f"{pre}.check.eta", float(ck[0]["eta"]))
            else:
                rec.put(f"{pre}.check.value", "absent")
                rec.put(f"{pre}.check.eta", "absent")



# ----------------------------------------------------------------------
#  Phase 29 -- the decompression record, and the governing utilisation
# ----------------------------------------------------------------------

#: The Phase-7 prestressed reference: 300x500, one bonded tendon at
#: y = 100, two rebar layers.  Chosen because it is the section on which
#: the decompression verdict was originally pinned, so the probe measures
#: the same object the existing validators measure.
_DEC_B, _DEC_H, _DEC_NFY = 300.0, 500.0, 200
_DEC_EC, _DEC_ES, _DEC_EP = 32000.0, 200000.0, 195000.0
_DEC_AS, _DEC_YS1, _DEC_YS2 = 628.0, 50.0, 450.0
_DEC_AP, _DEC_YT = 1500.0, 100.0
#: Low enough that a modest hogging increment carries the probe point
#: past the cracking strain.  Measured on the pristine tree: the probe
#: is uncracked at M = -80 kNm and cracked at M = -90 kNm.
_DEC_EPS_PE = 0.0006
_DEC_CDEC = 25.0


def _dec_section():
    r"""
    The prestressed reference section for the decompression probe.

    Returns
    -------
    tuple
        ``(section, x_ref, y_ref)``.
    """
    from gensec.geometry.fiber import RebarLayer, Tendon
    from gensec.geometry.section import RectSection
    from gensec.materials.concrete import Concrete
    from gensec.materials.steel import PrestressingSteel, Steel

    conc = Concrete(fck=35.0, gamma_c=1.5, long_term_reduction_factor=0.85)
    conc.name = "C35"
    st = Steel(fyk=450.0)
    st.name = "B450C"
    ps = PrestressingSteel(f_p01d=1391.3, Ep=_DEC_EP)
    ps.name = "Y1860"
    xr, yr = _DEC_B / 2.0, _DEC_H / 2.0
    reb = [RebarLayer(y=_DEC_YS1, As=_DEC_AS, material=st, x=xr),
           RebarLayer(y=_DEC_YS2, As=_DEC_AS, material=st, x=xr)]
    ten = [Tendon(y=_DEC_YT, Ap=_DEC_AP, material=ps, x=xr,
                  eps_pe=_DEC_EPS_PE, name="T1")]
    section = RectSection(_DEC_B, _DEC_H, conc, reb,
                          n_fibers_y=_DEC_NFY, tendons=ten)
    return section, xr, yr


def _decompression(rec: Recorder) -> None:
    r"""
    Probe the decompression record: one verdict, and how many numbers.

    Why this probe exists
    ---------------------
    Before Phase 29 the decompression record carried **two** numbers for
    one question -- ``eps_probe``, on which the verdict is taken, and
    ``sigma_probe_MPa``, read from the zone's law at the same point.  On
    a cracking law the two give *opposite* answers as soon as the probe
    point cracks: the law returns zero there, so a stress read
    :math:`\sigma \le 0` passes while the strain correctly fails.
    Measured on the pristine tree, at the section built above:

    .. code-block:: text

        M = -80 kNm   eps 4.3911e-05   sigma  1.571179   agree
        M = -90 kNm   eps 1.6766e-04   sigma  0.000000   DISAGREE
        M = -160 kNm  eps 6.8024e-04   sigma  0.000000   DISAGREE

    The quantity was measured **before** the probe was written around it
    (``28_0`` §3, E28-2): a probe built on an assumed discriminator can
    record a silence as a proof.

    What is recorded, per demand
    ----------------------------
    ``eps_probe``
        The strain at the probe point.  Unchanged by the repair -- it is
        the quantity the verdict was already taken on -- so it is the
        control: if it moves, something other than the record changed.
    ``passed``
        The verdict.  Also a control.
    ``sigma_probe``
        The second number, or the string ``absent`` once it is gone.
        Recorded as a **string on both trees** so that its removal is a
        movement on a key that exists in both fingerprints rather than a
        key that vanishes from one, which is not a comparison.
    ``value`` / ``limit`` / ``eta``
        The magnitude, threshold and utilisation the check publishes.
        ``absent`` on the pristine tree, where decompression is the only
        check that carries no magnitude at all.
    ``governing.check`` / ``governing.eta``
        Which check the run names as governing, and at what utilisation.
        On the pristine tree a run that **fails** decompression names a
        check that **passed**, because a record with no ``eta`` never
        enters the pool the governing check is drawn from.

    Parameters
    ----------
    rec : Recorder
    """
    import numpy as _np

    from gensec.materials.elastic import LinearElastic
    from gensec.materials.service_concrete import ServiceConcrete
    from gensec.materials.ec2_properties import fben2
    from gensec.materials.verification_limits import StressLimits
    from gensec.solver.section_state import SectionState
    from gensec.solver.sls import verify_sls_staged

    try:
        section, xr, yr = _dec_section()
        p = fben2(fck=35.0, ls="S", loadtype="slow", TypeConc="N",
                  time=28.0)
        law = ServiceConcrete(fcm=float(p.fcm), Ecm=float(p.ecm),
                              eps_c1=abs(float(p.eps_c1)),
                              eps_cu1=0.0035, fct_eff=float(p.fctm),
                              reference_age=28.0, name="C35")
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail("dec.build", exc)
        return

    rec.put("dec.eps_ct", float(p.fctm) / (1.05 * float(p.ecm)))
    limits = StressLimits(name="dec", decompression=True,
                          c_dec=_DEC_CDEC, k_c=0.6,
                          sigma_s_tens=0.8 * 450.0)
    state = SectionState(0, _np.ones(3, dtype=bool),
                         _np.ones(3, dtype=bool),
                         _np.array([0.0, 0.0, _DEC_EPS_PE], dtype=float),
                         bulk_eps_init=0.0, label="d")

    for decl, mat in (("lin", LinearElastic(E=_DEC_EC, name="C35")),
                      ("svc", law)):
        for m_kn in (-40.0, -80.0, -90.0, -160.0):
            pre = f"dec.{decl}[M={m_kn:.0f}]"
            stages = [{"name": "d", "state": state,
                       "increment": (0.0, m_kn * 1.0e6, 0.0),
                       "limits": limits}]
            try:
                res = verify_sls_staged(section, stages,
                                        moduli={"C35": mat},
                                        x_ref=xr, y_ref=yr)
            except Exception as exc:        # noqa: BLE001 -- failure is data
                rec.fail(f"{pre}.run", exc)
                continue
            sr = res["stages"][0]
            ck = [c for c in sr.get("checks", [])
                  if c.get("name", "").startswith("decompression")]
            if not ck:
                rec.put(f"{pre}.present", "absent")
                continue
            c = ck[0]
            rec.put(f"{pre}.present", "yes")
            rec.put(f"{pre}.eps_probe", float(c["eps_probe"]))
            rec.put(f"{pre}.passed", bool(c.get("passed")))
            rec.put(f"{pre}.sigma_probe",
                    ("absent" if "sigma_probe_MPa" not in c
                     else float(c["sigma_probe_MPa"])))
            # The magnitude may be published in stress ("value_MPa",
            # as every capacity-bearing check does) or in strain
            # ("value", which is what decompression is verified on).
            # Both are looked for, so the key exists on a tree that
            # publishes either and on one that publishes neither.
            for names, key in ((("value_MPa", "value"), "value"),
                               (("limit_MPa", "limit"), "limit"),
                               (("eta",), "eta")):
                got = [n for n in names if n in c]
                rec.put(f"{pre}.{key}",
                        ("absent" if not got else float(c[got[0]])))
                rec.put(f"{pre}.{key}.field",
                        ("absent" if not got else got[0]))
            gov = res.get("governing")
            rec.put(f"{pre}.governing.check",
                    "none" if not gov else str(gov["check"]))
            # eta is absent where the check has no capacity to divide
            # by, so it is recorded as a string on both trees rather
            # than coerced: a key that raises in the instrument is not
            # a comparison, and a key that vanishes is not a movement.
            rec.put(f"{pre}.governing.eta",
                    "none" if not gov or gov.get("eta") is None
                    else float(gov["eta"]))
            rec.put(f"{pre}.governing.failed",
                    "none" if not gov else str(gov.get("failed",
                                                       "absent")))
            rec.put(f"{pre}.verified", bool(sr.get("verified")))


def _equilibrium(rec: Recorder, tag: str, solver, demands) -> None:
    r"""
    Record the solved strain plane for every demand in the file.

    The inverse problem exercises the Newton-Raphson driver and the
    analytical tangent, so it is sensitive to changes the direct
    probe cannot see (a wrong tangent still converges to the right
    answer, but a wrong *reference stiffness* does not converge to
    the same plane).

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    demands : list of dict
        The ``demands`` block as returned by the YAML loader: one
        mapping per demand, carrying at least ``name`` and the
        components present in the file.
    """
    indexed = []
    for i, d in enumerate(demands or []):
        label = str(d.get("name", i)) if isinstance(d, dict) else str(i)
        indexed.append((label, d))
    for name, d in sorted(indexed, key=lambda t: t[0]):
        key = f"{tag}.equil[{name}]"
        try:
            get = (d.get if isinstance(d, dict)
                   else (lambda k, dflt: getattr(d, k, dflt)))
            N = float(get("N", 0.0) or 0.0)
            Mx = float(get("Mx", 0.0) or 0.0)
            My = float(get("My", 0.0) or 0.0)
            res = solver.solve_equilibrium(N, Mx, My)
            rec.put(f"{key}.converged", bool(res.get("converged", False)))
            rec.put(f"{key}.eps0", float(res.get("eps0", float("nan"))))
            rec.put(f"{key}.chi_x", float(res.get("chi_x", float("nan"))))
            rec.put(f"{key}.chi_y", float(res.get("chi_y", float("nan"))))
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{key}.eps0", exc)


#: Fractions of the section's own axial tensile capacity at which the
#: axial path is interrogated.  Two levels, not one: the lower is
#: expected to be reachable on any section, the upper sits close enough
#: to the peak that a bracket which stops short of one element class
#: cannot reach it.  Expressed as fractions rather than forces so the
#: probe means the same thing on a 200 mm slab and on a 2 m box.
_AXIAL_FRACTIONS: Tuple[float, ...] = (0.50, 0.95)


class _FastPathCounter:
    r"""
    Count entries into the zero-curvature fast path.

    Why this exists
    ---------------
    ``FiberSolver._solve_pure_axial`` is the one-unknown bisection
    ``solve_equilibrium`` uses when both target moments are negligible.
    Phase 19 widened the strain range it brackets over (N-15) and the
    numeric fingerprint recorded **no movement at all** on three of the
    four examples with tendons.  Direct instrumentation showed why:
    the fast path was entered *zero times* on two of them, and on the
    third the widened bracket moved ``eps0`` by :math:`1.7\times
    10^{-15}` relative — below the twelve significant digits the
    fingerprint writes.  An ``INERT`` produced that way is silence, not
    evidence, and the two are indistinguishable in the file.

    The count this class records is an **integer**.  It has no
    precision, which is exactly why it is worth recording: it separates
    "the path was never taken" from "the path was taken and did not
    move".

    Parameters
    ----------
    solver_cls : type
        The class whose ``_solve_pure_axial`` is wrapped.  Patched at
        class level and restored on exit, so nested use is not
        supported and is not needed.

    Attributes
    ----------
    entries : int
        Number of calls seen while the context was active.

    Examples
    --------
    >>> with _FastPathCounter(FiberSolver) as counter:   # doctest: +SKIP
    ...     solver.solve_equilibrium(1.0e5, 0.0, 0.0)
    >>> counter.entries                                  # doctest: +SKIP
    1
    """

    def __init__(self, solver_cls) -> None:
        self._cls = solver_cls
        self._original = None
        self.entries = 0

    def __enter__(self) -> "_FastPathCounter":
        r"""Install the counting wrapper.  Returns ``self``."""
        original = self._cls._solve_pure_axial
        self._original = original
        counter = self

        def _counting(self_solver, *args, **kwargs):
            counter.entries += 1
            return original(self_solver, *args, **kwargs)

        self._cls._solve_pure_axial = _counting
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        r"""Restore the original method.  Never suppresses."""
        self._cls._solve_pure_axial = self._original
        return False


def _axial_reach(solver) -> float:
    r"""
    Upper end of the section strain range, over **all three** element
    classes.

    Reconstructed here from the section rather than read off the
    solver's own bracket, on purpose: the bracket is the thing the
    probe exists to watch, so a probe that asked the bracket for its
    own extent would agree with it by construction.  A tendon's limit
    enters the *section* strain shifted by its locked-in strain,

    .. math::

        \varepsilon_{\mathrm{sec}} = \varepsilon_p - \varepsilon_{init}

    which is the same form :meth:`FiberSolver.element_limit_groups`
    uses for the strain-plane envelope.

    Parameters
    ----------
    solver : FiberSolver

    Returns
    -------
    float
        The largest tensile section strain any element can reach;
        ``0.0`` when the section has no tension element at all.
    """
    reach = 0.0
    for group in getattr(solver, "_rebar_groups", ()) or ():
        mat = group[0]
        limit = getattr(mat, "eps_max", None)
        if limit is not None:
            reach = max(reach, float(limit))
    for mat, _bulk, _idx, eps_init in getattr(
            solver, "_tendon_groups", ()) or ():
        limit = getattr(mat, "eps_max", None)
        if limit is not None:
            reach = max(reach, float(limit) - float(np.min(eps_init)))
    bulk_max = getattr(solver.sec.bulk_material, "eps_max", None)
    if bulk_max is not None:
        reach = max(reach, float(bulk_max))
    return reach


def _axial_path(rec: Recorder, tag: str, solver, fastpath_entries: int
                ) -> None:
    r"""
    Record the **axial path**: how often it was taken, and its verdict.

    Why this probe exists
    ---------------------
    Every other probe in this file records a *number*.  On the axial
    path that is not enough, for two measured reasons
    (``19_0 §2``, ``19_1 §3``):

    1. the path may not be taken at all — two of the three examples
       with tendons never entered it — and a battery that records only
       outputs cannot tell an untaken path from an inert one;
    2. when it is taken, the quantity it moves may move by less than
       the twelve digits written here, which reads in the file exactly
       like no movement.

    So this probe records, alongside the numbers, three things that
    have **no precision at all**: an integer count and two booleans.
    A verdict cannot move by :math:`10^{-15}`.

    What is recorded, per example
    -----------------------------
    ``axial.fastpath_entries``
        Integer.  Calls into ``_solve_pure_axial`` made by the other
        probes of this example, i.e. *before* this one runs.
    ``axial.reach``, ``axial.N_true``
        The element-complete tensile strain reach and the peak of
        :math:`N(\varepsilon_0)` at :math:`\chi = 0` over it.
    ``axial[NN].target``
        The interrogation level, a declared fraction of ``N_true``.
    ``axial[NN].inner_converged`` / ``axial[NN].inner_res_rel``
        Verdict and relative force residual of ``_solve_pure_axial``
        **called directly**, without its caller.
    ``axial[NN].outer_converged`` / ``axial[NN].outer_res_rel`` /
    ``axial[NN].outer_reason``
        The name the outer solve gives its own failure, or
        ``'unnamed'``.  A string, deliberately: a non-convergence that
        gains a cause moves no number, so a battery of numbers alone
        cannot see item N-17 being closed.
    ``axial[NN].outer_Mx``
        The same target put to :meth:`FiberSolver.solve_equilibrium`
        with ``Mx = My = 0``.  Recorded **separately** from the inner
        verdict because the two disagree on precisely the geometry
        that item N-17 names: the fast path converges, the outer solve
        does not.

    Parameters
    ----------
    rec : Recorder
    tag : str
    solver : FiberSolver
    fastpath_entries : int
        Count accumulated by the other probes of this example.

    Notes
    -----
    The residual is recorded as a **relative** quantity,

    .. math::

        r = \frac{|N_{\mathrm{obtained}} - N_{\mathrm{target}}|}
                 {\max(|N_{\mathrm{target}}|,\, 1)}

    so that a verdict of ``converged`` can be audited against a number
    rather than trusted: ``solver_flag`` is meaningless above certain
    residual magnitudes, which is why the dump carries the residual
    next to it and why this probe does the same.
    """
    rec.put(f"{tag}.axial.fastpath_entries", int(fastpath_entries))

    reach = _axial_reach(solver)
    rec.put(f"{tag}.axial.reach", float(reach))
    if reach <= 0.0:
        rec.put(f"{tag}.axial.N_true", "no-tension-element")
        return

    eps_lo = float(solver.sec.bulk_material.eps_min) * 1.01
    # 4000 samples: the same resolution ``tests/test_phase19_hull.py``
    # uses for ``_true_axial_tensile_capacity``, so the peak recorded
    # here and the peak the fixture asserts on are the same number
    # and not two approximations of it.
    grid = np.linspace(eps_lo, reach * 1.01, 4000)
    zeros = np.zeros_like(grid)
    N_scan, _, _ = solver.integrate_batch(grid, zeros, zeros)
    N_true = float(np.max(N_scan))
    rec.put(f"{tag}.axial.N_true", N_true)

    for k, fraction in enumerate(_AXIAL_FRACTIONS):
        key = f"{tag}.axial[{k:02d}]"
        target = fraction * N_true
        rec.put(f"{key}.target", target)
        scale = max(abs(target), 1.0)

        try:
            inner = solver._solve_pure_axial(target, 1.0, 200)
            rec.put(f"{key}.inner_converged",
                    bool(inner.get("converged", False)))
            rec.put(f"{key}.inner_res_rel",
                    abs(float(inner.get("N", float("nan"))) - target) / scale)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{key}.inner_converged", exc)

        try:
            outer = solver.solve_equilibrium(target, 0.0, 0.0)
            rec.put(f"{key}.outer_converged",
                    bool(outer.get("converged", False)))
            rec.put(f"{key}.outer_res_rel",
                    abs(float(outer.get("N", float("nan"))) - target) / scale)
            rec.put(f"{key}.outer_Mx", float(outer.get("Mx", float("nan"))))
            # The reason is a STRING, and that is the point.  A
            # non-convergence that acquires a named cause moves no
            # number at all: ``outer_converged`` is False on both
            # trees, ``outer_res_rel`` is the same residual, and the
            # whole repair would read as INERT.  An instrument blind
            # to the change it is pointed at reports silence, and
            # silence is not evidence (Phase 16 rule, ``19_1 §2``).
            # ``'unnamed'`` rather than an absent key, so the two
            # trees have the same key set and the movement shows up
            # as a movement instead of as an addition.
            rec.put(f"{key}.outer_reason",
                    str(outer.get("reason") or "unnamed"))
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{key}.outer_converged", exc)


def _properties(rec: Recorder, tag: str, section) -> None:
    r"""
    Record the homogenized polygon properties.

    Computed with :math:`E_{\mathrm{bulk}} = E_{\mathrm{ref}} = 1`, so
    the result is the *geometric* gross section: it isolates a change
    in the outline or in the rebar set from a change in the moduli,
    which the datum work will move on purpose.

    Parameters
    ----------
    rec : Recorder
    tag : str
    section : GenericSection
    """
    from gensec.geometry.properties import compute_section_properties

    key = f"{tag}.props"
    try:
        props = compute_section_properties(section.polygon)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{key}.area", exc)
        return
    for attr in ("area", "Sx", "Sy", "xg", "yg",
                 "Ix", "Iy", "Ixy", "I1", "I2", "theta_principal"):
        if hasattr(props, attr):
            try:
                rec.put(f"{key}.{attr}", float(getattr(props, attr)))
            except (TypeError, ValueError):
                pass


# ======================================================================
#  Driver
# ======================================================================

def _posttension_sequence(rec: Recorder, tag: str, data: dict) -> None:
    r"""
    Record the **post-tensioning sequence**: what resisted each jack.

    Why this probe exists
    ---------------------
    Measured at the opening of Phase 22, on the Phase-21 tree: a full
    ``numeric_fingerprint`` capture entered
    :func:`~gensec.solver.posttension.solve_posttension_sequence`
    **once**, on a single-tendon example — a geometry in which the
    quantity this probe is about cannot exist, because there is no
    second cable for the first to stiffen the section for.  And **0 of
    the 23 distributed examples** interleaved a ``stress`` with a
    ``grout``.  So the instrument was structurally blind to item D1 in
    exactly the way it had been blind to N-17 before Phase 20: it would
    have read ``INERT`` across the repair, and an ``INERT`` from a blind
    instrument is silence, not proof (``19_1 §2``).

    What is recorded, and why these quantities
    ------------------------------------------
    The repair moves stresses in their third significant figure — on the
    reference geometry, +0.46 % on a final :math:`\sigma_p`.  That is
    visible, but it is *only* visible where the sequence is staged, and
    a battery of stresses alone could not distinguish "the view is now
    per-step" from "the numbers happen to differ".  So the probe records
    two families of quantity that have **no precision to hide behind**:

    ``pt.injections_before_jack[NN]``
        Integer.  How many tendons had already been injected when jack
        *NN* was pulled, derived from the ``construction_history``
        **events alone** — no solver, no driver.  It is therefore
        available on a tree where the driver refuses, which is what
        makes the refusal→computation transition a *movement* of an
        existing key rather than an addition of a new one.
    ``pt.interleaved``
        Boolean.  Whether the history stresses anything after a grout.
    ``pt.driver.outcome``
        String: ``'ok'`` when the walk completes, otherwise the
        exception's declared ``reason`` or ``unnamed:<ExcType>``.  A
        refusal that acquires a cause moves no number at all — the
        Phase-20 ``axial.*.outer_reason`` rule (``20_1 §3``), applied to
        a second site one phase later.
    ``pt.n_bonded_at_jack[NN]``
        Integer, read from the **driver's own** per-stage report: how
        many tendons were in the resisting section at that jack.  The
        derived count above says what the history asks for; this one
        says what the driver did.  They are recorded separately on
        purpose: a driver that ignored the schedule would agree with the
        first and disagree with the second, and one key alone could not
        tell.  ``'refused'`` when the walk did not complete.
    ``pt.grout_eps_init.tendon[X]``
        The reconciled locked-in strain per tendon, or ``'refused'``.

    Parameters
    ----------
    rec : Recorder
    tag : str
    data : dict
        The loaded document.

    Notes
    -----
    Examples without tendons record nothing at all: an absent key set is
    correct for a section that has no sequence, and writing zeros there
    would put a measurement where there is no measurand.
    """
    section = data.get("section")
    tendons = list(getattr(section, "tendons", []) or [])
    if not tendons:
        return
    hist = data.get("construction_history") or []
    rec.put(f"{tag}.pt.n_tendons", len(tendons))

    # --- derived from the events alone, so it exists on every tree ----
    jacks: List[str] = []
    injections_before: List[int] = []
    grouted_count = 0
    n_grout_events = 0
    interleaved = False
    seen_grout = False
    for ev in hist:
        if not isinstance(ev, dict):
            continue
        if "stress" in ev:
            payload = ev["stress"] or {}
            for name in (payload.get("tendons") or []):
                jacks.append(str(name))
                injections_before.append(grouted_count)
            if seen_grout:
                interleaved = True
        elif "grout" in ev:
            payload = ev["grout"] or {}
            n_grout_events += 1
            seen_grout = True
            grouted_count += len(payload.get("tendons") or [])
    rec.put(f"{tag}.pt.n_jacks", len(jacks))
    rec.put(f"{tag}.pt.n_grout_events", n_grout_events)
    rec.put(f"{tag}.pt.interleaved", bool(interleaved))
    for k, (name, n_inj) in enumerate(zip(jacks, injections_before)):
        rec.put(f"{tag}.pt.jack[{k:02d}].tendon", name)
        rec.put(f"{tag}.pt.injections_before_jack[{k:02d}]", int(n_inj))

    # --- what the driver actually did --------------------------------
    from gensec.solver.timeline import ConstructionTimeline
    import gensec.solver.posttension as _pt

    stages: List[int] = []
    original = _pt.solve_posttension_sequence

    def _watch(*args, **kwargs):
        res = original(*args, **kwargs)
        stages.clear()
        for st in res.stages:
            stages.append(st.report["n_bonded_at_jack"]
                           if "n_bonded_at_jack" in st.report
                           else "unpublished")
        return res

    outcome = "no-history"
    eps_map: Dict[str, float] = {}
    if hist:
        _pt.solve_posttension_sequence = _watch
        try:
            tl = ConstructionTimeline.from_document(data)
            dem = data.get("demands") or []
            db = dem if isinstance(dem, dict) else {d["name"]: d for d in dem}
            res = tl.resolve(section, db)
            outcome = "ok"
            eps_map = dict(res.grout_eps_init)
        except BaseException as exc:        # noqa: BLE001 — failure is data
            outcome = str(getattr(exc, "reason", None)
                          or f"unnamed:{type(exc).__name__}")
        finally:
            _pt.solve_posttension_sequence = original
    rec.put(f"{tag}.pt.driver.outcome", outcome)
    for k in range(len(jacks)):
        # ``'refused'``  the walk did not complete;
        # ``'unpublished'``  it did, on a tree whose driver does not
        # publish the count -- an honest statement about the instrument
        # rather than a sentinel integer that would read as a datum.
        rec.put(f"{tag}.pt.n_bonded_at_jack[{k:02d}]",
                stages[k] if k < len(stages) else "refused")
    for name in sorted({str(t.name or f"tendon_{i}")
                        for i, t in enumerate(tendons)}):
        rec.put(f"{tag}.pt.grout_eps_init.tendon[{name}]",
                eps_map.get(name, "refused"))


def _reduction_provenance(spec: dict, attr_name: str) -> str:
    r"""
    Where a material's long-term reduction factor came from.

    A **name**, never a number, and deliberately so: this probe exists
    to make the passage of a normative constant from the container to
    the code that owns it a *movement* in the fingerprint rather than
    an addition, and a movement is only readable if the key exists on
    both trees.  Recording the value alone would be blind to the
    change that matters here, because the Eurocode's recommended
    :math:`\alpha_{cc} = 0.85` and a declared 0.85 are the same float.

    Parameters
    ----------
    spec : dict
        The material's raw YAML mapping, before any construction.
    attr_name : str
        The attribute the container ends up carrying.

    Returns
    -------
    str
        ``'yaml:<key>'`` when the input declares it, ``'default'``
        when nothing in the input names it and the value can only
        have come from a container-side default, ``'bridge'`` when
        the material is built by a normative code's own module and
        the input never sees the factor at all.
    """
    mat_type = str(spec.get("type", "")).lower()
    if mat_type in ("concrete_ec2_gen1", "concrete_ec2"):
        # Built by the EC2 module from a class or an f_ck: the factor
        # is read off EN 1992-1-1 in its own file and the input never
        # states it.  That is the target architecture, not a default.
        return "bridge"
    for key in (attr_name, "alpha_cc"):
        if key in spec:
            return f"yaml:{key}"
    return "default"


def _design_strength(rec: Recorder, tag: str, path: str) -> None:
    r"""
    Record, per material, the design strength and **who supplied it**.

    Three quantities per concrete-like material, and only one of them
    is a number:

    ``fcd``
        the design compressive strength the container publishes,

        .. math::

           f_{cd} \;=\; k_{lt}\,\frac{f_{ck}}{\gamma_{c}},

        where :math:`k_{lt}` is the long-term reduction factor
        (EN 1992-1-1 §3.1.6(1)P calls it :math:`\alpha_{cc}`; the
        container names it neutrally because the factor is a property
        of the declared code, not of the container).

    ``code``
        the *name* of the :class:`~gensec.materials.codes.NormativeCode`
        object that governs the material, or the named refusal when no
        code answers.  A name has no precision to hide behind: two
        codes that agree to twelve digits still differ here.

    ``k_lt.from`` and ``gamma_c.from`` and ``fck.from``
        the provenance of each of the three, as
        :func:`_reduction_provenance` defines it.  These are the keys
        that move when a container-side default is taken away, and
        they are recorded precisely because the *value* does not move
        when the declared number equals the default that preceded it.

    Parameters
    ----------
    rec : Recorder
    tag : str
        Example tag.
    path : str
        Absolute path to the YAML file, re-read raw so the probe can
        see what the input declares rather than what the container
        ended up holding.

    Notes
    -----
    Failure is data.  A material that cannot answer records the
    refusal by name rather than being skipped, because a key that
    disappears from one tree to the next is indistinguishable from a
    probe that stopped looking.
    """
    import yaml as _yaml
    from gensec.io_yaml import load_yaml

    try:
        raw = _yaml.safe_load(open(path, encoding="utf-8"))
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.materials.raw", exc)
        return
    specs = (raw or {}).get("materials") or {}

    try:
        built = (load_yaml(path) or {}).get("materials") or {}
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.materials.built", exc)
        return

    for name in sorted(specs):
        mat = built.get(name)
        if mat is None:
            rec.put(f"{tag}.mat[{name}].built", "absent")
            continue
        if not hasattr(mat, "fcd"):
            # Not a concrete-like container: recorded so the key set
            # is the same on every tree, and skipped for the rest.
            rec.put(f"{tag}.mat[{name}].fcd", "n/a")
            continue

        spec = specs[name] or {}
        rec.put(f"{tag}.mat[{name}].fcd", mat.fcd)

        k_lt = getattr(mat, "long_term_reduction_factor", None)
        held_as = "long_term_reduction_factor"
        if k_lt is None:
            k_lt = getattr(mat, "alpha_cc", None)
            held_as = "alpha_cc" if k_lt is not None else "absent"
        rec.put(f"{tag}.mat[{name}].k_lt", "absent" if k_lt is None
                else k_lt)
        rec.put(f"{tag}.mat[{name}].k_lt.held_as", held_as)
        rec.put(f"{tag}.mat[{name}].k_lt.from",
                _reduction_provenance(spec, "long_term_reduction_factor"))
        rec.put(f"{tag}.mat[{name}].gamma_c.from",
                _reduction_provenance(spec, "gamma_c"))
        rec.put(f"{tag}.mat[{name}].fck.from",
                _reduction_provenance(spec, "fck"))

        code = getattr(mat, "code", None)
        rec.put(f"{tag}.mat[{name}].code",
                "absent" if code is None else str(getattr(code, "key", code)))
        try:
            rm = mat.reference_modulus()
            rec.put(f"{tag}.mat[{name}].modulus.answered_by",
                    str(getattr(rm, "source", "unnamed"))[:60])
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.put(f"{tag}.mat[{name}].modulus.answered_by",
                    f"refused:{type(exc).__name__}")


def _undeclared_container(rec: Recorder) -> None:
    r"""
    What a bare container does when the input declares nothing.

    Synthetic, tied to no example, and the counterpart of
    :func:`_design_strength`: the distributed battery can only show
    what happens when an input *does* declare, and the defect this
    probe watches is what happens when it does not.

    Four constructions, each recording either the value the container
    invented or the refusal it raised, by name.  On a tree that
    carries container-side defaults these read ``accepted:<value>``;
    on a tree that has taken them away they read ``refused:<Error>``.
    The transition is therefore a **movement** of four existing keys,
    not the appearance of four new ones.

    Parameters
    ----------
    rec : Recorder
    """
    import dataclasses

    from gensec.materials.concrete import Concrete

    # The container's own name for the long-term factor, read off the
    # dataclass rather than assumed: a probe that hard-coded one name
    # would report ``TypeError: unexpected keyword argument`` on the
    # tree that uses the other, which demonstrates that a name is
    # missing and NOT that the defect under test is present.
    fields = {f.name for f in dataclasses.fields(Concrete)}
    k_name = ("long_term_reduction_factor"
              if "long_term_reduction_factor" in fields else "alpha_cc")
    rec.put("Concrete.k_lt.field_name", k_name)

    cases = {
        "nothing": {},
        "fck_only": {"fck": 40.0},
        "fck_gamma": {"fck": 40.0, "gamma_c": 1.5},
        "all_three": {"fck": 40.0, "gamma_c": 1.5, k_name: 0.85},
    }
    for label, kwargs in cases.items():
        try:
            mat = Concrete(**kwargs)
        except TypeError as exc:
            # A missing required argument is a refusal too, but an
            # unnamed one: recorded as its own outcome so it is never
            # mistaken for a reasoned refusal.
            rec.put(f"Concrete.undeclared[{label}]",
                    f"refused:TypeError:{str(exc)[:48]}")
            continue
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.put(f"Concrete.undeclared[{label}]",
                    f"refused:{type(exc).__name__}")
            continue
        rec.put(f"Concrete.undeclared[{label}]", f"accepted:{_fmt(mat.fcd)}")


def _retrofit_laws(EC: float, EP: float):
    r"""
    Linear-elastic bulk and strand laws for the synthetic retrofit probe.

    One home for one fact: :func:`_retrofit_declaration` and
    :func:`datum_fingerprint.probe_retrofit_datum` measure the **same**
    declared member, so they must not each declare their own idea of
    what its concrete is.  Two copies of a constitutive law drift, and
    a drift between two instruments watching one repair is unreadable
    as either a movement or an error.

    The laws are declared here and not built through
    :class:`~gensec.materials.concrete.Concrete`: a fingerprint probe
    routed through the normative surface would move whenever a
    normative constant moved, which is a different fact from the one
    these probes watch.

    Parameters
    ----------
    EC, EP : float
        Concrete and strand moduli [MPa].

    Returns
    -------
    tuple
        ``(bulk_law, strand_law)``.
    """
    import numpy as _np

    class _LinearElastic:
        r"""Constant-modulus law :math:`\sigma = E\varepsilon`."""

        def __init__(self, E, eps_lim=1.0):
            self.E = float(E)
            self._lim = float(eps_lim)

        @property
        def eps_min(self):
            return -self._lim

        @property
        def eps_max(self):
            return self._lim

        def stress(self, eps):
            return self.E * eps

        def stress_array(self, eps):
            return self.E * _np.asarray(eps, dtype=float)

        def tangent(self, eps):
            return self.E

        def tangent_array(self, eps):
            return _np.full_like(_np.asarray(eps, dtype=float), self.E)

        def content_token(self):
            from gensec.materials.base import digest_bytes, encode_value
            return digest_bytes(
                encode_value("tools.numeric_fingerprint._LinearElastic"),
                encode_value(self.E), encode_value(self._lim))

    return _LinearElastic(EC), _LinearElastic(EP)


def _retrofit_declaration(rec: Recorder) -> None:
    r"""
    What the driver does when a **retrofit** is declared.

    Synthetic, tied to no example, run once from :func:`capture` —
    the same shape as :func:`_undeclared_container`, and for the same
    reason.  The distributed battery carries no retrofit and cannot
    carry one: a section already in service, with grouted tendons at
    some effective stress, is not a model GenSec could load before it
    could answer it.  So the instrument was structurally blind to D1b
    exactly as it was blind to D1 before Phase 22 — measured at the
    opening of Phase 24, on the Phase-23 tree:

    .. code-block:: text

        keys containing 'preexisting'    : 0
        keys containing 'already_bonded' : 0
        keys containing 'retrofit'       : 0

    on 5074.  An ``INERT`` from a blind instrument is silence, not
    proof (``19_1 §2``).

    The key set is identical on both trees
    -------------------------------------
    Every quantity below is recorded under a key that **exists before
    and after** the repair.  On a tree that refuses the retrofit the
    value is the string ``'refused:<reason>'``; on a tree that models
    it the value is a number.  The transition is therefore a
    *movement* of existing keys, which is readable, and not an
    addition of new ones, which would prove nothing (``23_0 §4``).

    Nothing here hard-codes a name that exists on only one of the two
    trees.  The declaration class is fetched with :func:`getattr` and
    its fields are read off the dataclass, so the probe reports
    ``'absent'`` rather than dying of :class:`AttributeError` — an
    error would say a name is missing, which is not the fact under
    measurement.

    What is recorded, and why
    -------------------------
    ``retrofit.declaration.type`` / ``.fields``
        The name of the declaration object and its field names, read
        from the module.  ``'absent'`` where there is none.
    ``retrofit.bare.reason``
        The named reason raised when the pre-existing set is declared
        **as a bare sequence of indices** — which says *which* tendons
        are already grouted and not *at what stress*.  This refusal
        does not disappear with the repair: it changes cause, from
        "the physics is not modelled" to "the state is not declared",
        and a reason string is how a refusal that moves no number is
        made visible at all (the Phase-20 ``outer_reason`` rule,
        ``20_1 §3``).
    ``retrofit.declared.*``
        The stresses, losses, concrete strains and per-jack bonded
        counts of a fully declared retrofit.  ``'refused:<reason>'``
        on a tree that will not answer.
    ``retrofit.control.*`` and ``retrofit.staged.*``
        **Numbers on both trees.**  The same section and the same
        jacks with *no* pre-existing tendon: once under the
        deferred-single-grouting model, once under the Phase-22 staged
        schedule.  They are the immobility evidence — a repair that
        moved them would have changed a case it was not asked to
        change, and no count of moved keys would show that on its own.

    Parameters
    ----------
    rec : Recorder

    Notes
    -----
    The geometry is the one every published measurement of this defect
    family uses (``22_0 §1.1``, ``6_8-WARNING``): a 400 x 1200
    rectangle, three tendons :math:`A_p = 1500\,\mathrm{mm^2}` at
    :math:`y = 150/200/250`, :math:`E_c = 35\,220.462`,
    :math:`E_p = 195\,000`.  A number without its geometry is not a
    measure.

    The constitutive laws are declared **here**, linear elastic, and
    deliberately not built from :class:`~gensec.materials.concrete.Concrete`:
    a fingerprint probe that went through the normative surface would
    move whenever a normative constant moved, which is a different
    fact from the one it is watching.
    """
    import dataclasses

    from gensec.geometry.fiber import Tendon
    from gensec.geometry.section import RectSection
    import gensec.solver.posttension as _pt

    B, H, N_Y = 400.0, 1200.0, 240
    EC, EP, AP, SP0 = 35220.462, 195000.0, 1500.0, 1300.0
    Y_TENDONS = (150.0, 200.0, 250.0)
    # The declared state of the existing member: tendon 0 grouted long
    # ago at 1100 MPa, the concrete carrying a compression plane.
    SIGMA_PE, EPS0_EX, CHIX_EX = 1100.0, -3.0e-4, 1.5e-7
    XREF_D, YREF_D, AGE_C, AGE_P = 0.0, 0.0, 14600.0, 14200.0

    bulk_law, strand_law = _retrofit_laws(EC, EP)

    def _section():
        tendons = [Tendon(y=float(yt), x=B / 2.0, material=strand_law,
                          Ap=AP, eps_pe=0.0) for yt in Y_TENDONS]
        return RectSection(B=B, H=H, bulk_material=bulk_law, rebars=[],
                           n_fibers_y=N_Y, tendons=tendons)

    def _named_reason(exc) -> str:
        return str(getattr(exc, "reason", None)
                   or f"unnamed:{type(exc).__name__}")

    # --- the declaration object, read from the module ------------------
    decl_cls = getattr(_pt, "PreexistingState", None)
    rec.put("retrofit.declaration.type",
            "absent" if decl_cls is None else decl_cls.__name__)
    if decl_cls is None or not dataclasses.is_dataclass(decl_cls):
        rec.put("retrofit.declaration.fields", "absent")
    else:
        rec.put("retrofit.declaration.fields",
                ",".join(sorted(f.name for f in
                                dataclasses.fields(decl_cls))))

    # --- A: the pre-existing set declared as a bare sequence -----------
    # Says WHICH tendons are already grouted, and not AT WHAT stress.
    # Refused on both trees; the reason is what moves.
    try:
        _pt.solve_posttension_sequence(
            _section(), sigma_p0=[SP0] * 3, Ep=EP,
            order=[1, 2], pending=[], already_bonded=[0])
        rec.put("retrofit.bare.reason", "none")
    except BaseException as exc:            # noqa: BLE001 — outcome is data
        rec.put("retrofit.bare.reason", _named_reason(exc))

    # --- B: the fully declared retrofit --------------------------------
    keys_ten = [f"retrofit.declared.sigma_p_after[{k:02d}]" for k in range(3)]
    keys_los = [f"retrofit.declared.loss[{k:02d}]" for k in range(3)]
    keys_eps = [f"retrofit.declared.eps_c[{k:02d}]" for k in range(3)]
    keys_bnd = [f"retrofit.declared.n_bonded_at_jack[{k:02d}]"
                for k in range(2)]
    all_keys = keys_ten + keys_los + keys_eps + keys_bnd

    def _refuse_declared(token: str) -> None:
        for key in all_keys:
            rec.put(key, token)
        rec.put("retrofit.declared.outcome", token)

    if decl_cls is None:
        _refuse_declared("refused:absent")
    else:
        try:
            state = decl_cls(sigma_pe={0: SIGMA_PE}, eps0=EPS0_EX,
                             chi_x=CHIX_EX, chi_y=0.0, x_ref=XREF_D,
                             y_ref=YREF_D, concrete_age_days=AGE_C,
                             tendon_age_days={0: AGE_P})
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            state = None
            _refuse_declared(f"refused:ctor:{type(exc).__name__}")
        if state is not None:
            nan = float("nan")
            try:
                res = _pt.solve_posttension_sequence(
                    _section(), sigma_p0=[nan, SP0, SP0], Ep=EP,
                    order=[1, 2], pending=[], already_bonded=state)
            except BaseException as exc:    # noqa: BLE001 — outcome is data
                _refuse_declared(f"refused:{_named_reason(exc)}")
            else:
                rec.put("retrofit.declared.outcome", "ok")
                for k in range(3):
                    rec.put(keys_ten[k], float(res.sigma_p_after[k]))
                    rec.put(keys_los[k], float(res.loss[k]))
                    rec.put(keys_eps[k], float(res.eps_ref_grout[k]))
                for k, st in enumerate(res.stages[:2]):
                    rec.put(keys_bnd[k],
                            int(st.report.get("n_bonded_at_jack", -1)))

    # --- C: the two cases this repair must NOT move --------------------
    # Numbers on both trees.  Deferred single grouting first (no tendon
    # bonded during the sequence), then the Phase-22 staged schedule.
    for label, kwargs in (("control", {}),
                          ("staged", {"bonded_before": {0: 1, 1: 2}})):
        try:
            res = _pt.solve_posttension_sequence(
                _section(), sigma_p0=[SP0] * 3, Ep=EP, order=[0, 1, 2],
                **kwargs)
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            for k in range(3):
                rec.put(f"retrofit.{label}.sigma_p_after[{k:02d}]",
                        f"refused:{_named_reason(exc)}")
            continue
        for k in range(3):
            rec.put(f"retrofit.{label}.sigma_p_after[{k:02d}]",
                    float(res.sigma_p_after[k]))


class _EC2ServiceLaw:
    r"""
    EN 1992-1-1 §3.1.5 expression (3.14), **through its one home**.

    The formula is not written here.  It lives in
    :func:`~gensec.materials.ec2_properties.en2sargin`, and the
    constants come from :class:`~gensec.materials.ec2_properties.fben2`,
    which is the module that owns the normative document.  This class
    is an adapter and nothing else: it converts sign convention, adds
    the derivative the clause does not state, and presents the
    ``stress_array`` / ``tangent_array`` surface the fiber solver
    consumes.

    Sign
    ----
    ``en2sargin`` takes compression **positive** and returns
    compression **positive**; GenSec takes compression negative.  So

    .. math::

        \sigma_{\text{GenSec}}(\varepsilon) = -S(-\varepsilon),
        \qquad
        \frac{d\sigma_{\text{GenSec}}}{d\varepsilon}(\varepsilon)
            = S'(-\varepsilon),

    with :math:`S` the Eurocode function.

    The derivative
    --------------
    EN 1992-1-1 states :math:`\sigma(\varepsilon)` and not
    :math:`d\sigma/d\varepsilon`, so the tangent has no normative home
    to be taken from.  It is differentiated here in closed form,

    .. math::

        S'(e) = \frac{f_{cm}}{\varepsilon_{c1}}\,
            \frac{(k - 2\eta)\bigl[1 + (k-2)\eta\bigr]
                  - (k\eta - \eta^{2})(k-2)}
                 {\bigl[1 + (k-2)\eta\bigr]^{2}},
        \qquad \eta = e/\varepsilon_{c1},

    and it is **checked against a central difference of**
    ``en2sargin`` itself, so that the derivative cannot drift away from
    the function it differentiates without a red.

    Outside :math:`|\varepsilon| > \varepsilon_{cu1}` the Eurocode
    function returns zero; the tangent returns zero there too.  A law
    whose stress is flat while its tangent is not is not a law, and a
    Newton loop on it does not converge — measured, in the first
    version of this probe.

    Consequence, stated rather than hidden
    --------------------------------------
    Going through the normative surface is the opposite of the rule
    :func:`_retrofit_laws` follows (``24_0 §3``): these keys will move
    if an EN 1992-1-1 constant moves, which is a different fact from
    the one they watch.  The mitigation is that
    ``d1c.law.tangent_ratio[...]`` is recorded first and separately: if
    a normative constant moves, those five keys move with it and say
    so, and the rest of the ``d1c.*`` battery is read in that light.

    Parameters
    ----------
    fck : float, optional
        Characteristic cylinder strength [MPa].  Default 35, the
        C35/45 of every published measurement of this defect family.
    ls, loadtype, TypeConc : str, optional
        Passed through to :class:`fben2`.
    """

    def __init__(self, fck=35.0, ls="F", loadtype="LT", TypeConc="N"):
        from gensec.materials.ec2_properties import fben2
        self.props = fben2(float(fck), ls, loadtype, TypeConc)
        self.fcm = float(self.props.fcm)
        self.Ecm = float(self.props.ecm)
        self.eps_c1 = float(self.props.eps_c1)
        self.eps_cu1 = float(self.props.eps_cu1)
        # Read off expression (3.14) as ``en2sargin`` forms it; the
        # finite-difference check is what keeps the two tied.
        self.k = (1.05 * self.Ecm * abs(self.eps_c1)
                  / float(self.props.fcm_28))

    @property
    def eps_min(self):
        return -self.eps_cu1

    @property
    def eps_max(self):
        return self.eps_cu1

    def _S(self, e):
        r"""``en2sargin`` in its own sign convention, vectorised."""
        from gensec.materials.ec2_properties import en2sargin
        e = np.asarray(e, dtype=float)
        flat = e.ravel()
        out = np.array([en2sargin(float(v), self.props) for v in flat])
        return out.reshape(e.shape)

    def _dS(self, e):
        r"""Closed-form derivative of ``en2sargin``, same convention."""
        e = np.asarray(e, dtype=float)
        out = np.zeros_like(e)
        inside = np.abs(e) <= abs(self.eps_cu1)
        if np.any(inside):
            eta = e[inside] / self.eps_c1
            den = 1.0 + (self.k - 2.0) * eta
            num = self.k * eta - eta * eta
            d_num = (self.k - 2.0 * eta) / self.eps_c1
            d_den = (self.k - 2.0) / self.eps_c1
            out[inside] = self.fcm * (d_num * den - num * d_den) / (den * den)
        return out

    def stress(self, eps):
        return float(self.stress_array(np.asarray([eps], dtype=float))[0])

    def stress_array(self, eps):
        return -self._S(-np.asarray(eps, dtype=float))

    def tangent(self, eps):
        return float(self.tangent_array(np.asarray([eps], dtype=float))[0])

    def tangent_array(self, eps):
        return self._dS(-np.asarray(eps, dtype=float))

    def content_token(self):
        r"""Declared content: the constants the law was built from."""
        from gensec.materials.base import digest_bytes, encode_value
        return digest_bytes(
            encode_value("ec2_properties.en2sargin"),
            encode_value(self.fcm), encode_value(self.Ecm),
            encode_value(self.eps_c1), encode_value(self.eps_cu1))

def _analysis_combination_path(rec: Recorder) -> None:
    r"""
    Probe the **combination-resolution path** of
    :class:`~gensec.solver.analysis.AnalysisEngine`.

    Why this probe exists
    ---------------------
    ``AnalysisEngine`` is reached by exactly one probe in this
    instrument, ``_decomposition_closure``, which builds the engine and
    calls :meth:`~gensec.solver.analysis.AnalysisEngine._decompose` at
    two fixed strain planes.  That probe never enters
    :meth:`~gensec.solver.analysis.AnalysisEngine.analyze_combinations`,
    so **both** of the module's component-resolution call sites --
    the simple branch and the staged branch -- were unobserved: a
    capture over all 24 distributed examples produced **zero** keys
    naming them.

    Phase 34 merges the module's private ``_resolve_components`` into
    the canonical
    :meth:`~gensec.solver.check.VerificationEngine.resolve_components`
    (finding Z-14: two functions, one body, two homes for one fact).
    Without this bench the ``INERT`` that merge produces would be
    silence rather than proof, which is the lesson E32-1 records and
    the reason the extension lands **before** the repair.

    What is recorded, and why each family discriminates
    --------------------------------------------------
    ``analysis.combo.simple.{N,Mx,My}``
        The factored resultant of a simple combination.  The component
        list mixes a default factor, an explicit factor and a
        **negative** one, so a merge that changed the default from
        :math:`1.0` to :math:`0.0`, or dropped the sign, moves these
        three numbers.  The resultant is recorded rather than the
        rounded ``*_kNm`` echoes: those carry four decimals and would
        hide a small drift.
    ``analysis.combo.staged.cum.{N,Mx,My}[k]``
        The cumulative demand after each stage of a staged
        combination, which is the **second** call site.  A merge that
        repaired one branch and not the other moves these and leaves
        the family above still.
    ``analysis.combo.{n_results,types}``
        The roll call: how many combinations came back and of which
        kind.  A branch that stops producing a result at all is a
        disappearance, and a disappearance must be visible as a
        movement rather than as a missing key.

    Synthetic and example-free, by the rule of ``32_0`` §7: a bench
    that reads a distributed document moves when a later phase edits
    that document, for reasons that have nothing to do with its
    subject.

    Parameters
    ----------
    rec : Recorder
        Destination of the recorded values.
    """
    from gensec.solver.integrator import FiberSolver

    tag = "analysis.combo"

    #: Forces in [N], moments in [N.mm].  Deliberately not round in the
    #: same way as one another, so that a transposition of ``Mx`` and
    #: ``My`` cannot cancel in the sum.
    demand_db = {
        "G": {"N": -420.0e3, "Mx": -640.0e6, "My": 12.5e6},
        "Q": {"N": 0.0, "Mx": -520.0e6, "My": -3.25e6},
        "W": {"N": 31.0e3, "Mx": 7.5e6, "My": 88.125e6},
    }

    try:
        section, _xr, _yr = _dec_section()
        solver = FiberSolver(section)
        from gensec.solver.analysis import AnalysisEngine
        engine = AnalysisEngine(solver)
    except BaseException as exc:            # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.build", exc)
        return

    combinations = [
        {"name": "simple",
         "components": [{"ref": "G", "factor": 1.35},
                        {"ref": "Q"},
                        {"ref": "W", "factor": -0.6}]},
        {"name": "staged",
         "stages": [{"name": "s0", "components": [{"ref": "G"}]},
                    {"name": "s1",
                     "components": [{"ref": "Q", "factor": 0.5}]},
                    {"name": "s2",
                     "components": [{"ref": "W", "factor": -1.0},
                                    {"ref": "Q", "factor": 0.5}]}]},
    ]

    try:
        results = engine.analyze_combinations(combinations, demand_db)
    except BaseException as exc:            # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.run", exc)
        return

    rec.put(f"{tag}.n_results", len(results))
    rec.put(f"{tag}.types",
            ",".join(str(r.get("type")) for r in results))

    by_name = {r.get("name"): r for r in results}

    simple = by_name.get("simple")
    if simple is None:
        rec.put(f"{tag}.simple.outcome", "absent")
    else:
        rec.put(f"{tag}.simple.outcome", "ok")
        for axis in ("N", "Mx", "My"):
            # ``analyze_combinations`` publishes the resultant only as
            # the rounded ``*_kNm`` echoes on the simple branch, so the
            # unrounded value is reconstructed from them here and the
            # rounding is recorded as what it is.
            key = {"N": "N_kN", "Mx": "Mx_kNm", "My": "My_kNm"}[axis]
            rec.put(f"{tag}.simple.{key}", float(simple.get(key, 0.0)))

    staged = by_name.get("staged")
    if staged is None:
        rec.put(f"{tag}.staged.outcome", "absent")
        return
    rec.put(f"{tag}.staged.outcome", "ok")
    stages = staged.get("stages") or []
    rec.put(f"{tag}.staged.n_stages", len(stages))
    for k, st in enumerate(stages):
        cum = st.get("cumulative") or {}
        for key in ("N_kN", "Mx_kNm", "My_kNm"):
            rec.put(f"{tag}.staged.cum.{key}[{k:02d}]",
                    float(cum.get(key, 0.0)))


def _cumulative_reference(section, sigma_p0, order, Ep, tol=1e-10,
                          max_iter=200):
    r"""
    The **cumulative** increment form, written out independently.

    Not the driver, and deliberately so: ``4 §4`` of the Phase-25 brief
    forbids a reference that is the driver compared with itself.  At
    every step the whole action set applied so far is solved on the
    tendon-free resisting view; the plane read back is the **total**
    state, and the increment charged to the anchored tendons is its
    difference against the previous total,

    .. math::

        \Delta\sigma_{p,i}^{(k)}
          = -E_p\,\bigl(\varepsilon_{c,i}^{(k)}
                        - \varepsilon_{c,i}^{(k-1)}\bigr),
        \qquad
        \varepsilon_c^{(k)} = \varepsilon_c\Bigl(
            \textstyle\sum_{m\le k} \mathbf{A}_m \Bigr).

    Restricted to a **constant view**: no tendon becomes bonded during
    the sequence and none was bonded before it.  A tendon joining
    partway would have to enter the cumulative solve at the
    ``eps_init`` that preserves the stress it held when it joined, and
    that bookkeeping belongs to the driver, not to a reference.

    Parameters
    ----------
    section : GenericSection
    sigma_p0 : sequence of float
        Jacking stress per tendon [MPa].
    order : sequence of int
        Stressing order.
    Ep : float
        Tendon modulus [MPa].
    tol, max_iter : float, int, optional
        Passed to :meth:`FiberSolver.solve_equilibrium`.

    Returns
    -------
    dict
        ``sigma_p_after``, ``loss``, ``eps_c`` — the three quantities
        the driver publishes, as ``numpy.ndarray``.
    """
    from gensec.solver.integrator import FiberSolver
    from gensec.solver.section_state import PrestressAction
    import gensec.solver.posttension as _pt

    x = np.asarray(section.x_tendons, dtype=float)
    y = np.asarray(section.y_tendons, dtype=float)
    Ap = np.asarray(section.A_tendons, dtype=float)
    nt = x.size
    solver = FiberSolver(_pt._stressing_view(section, None, bonded=()))
    xr, yr = solver.x_ref, solver.y_ref
    ly, lx = y - yr, x - xr

    sp0 = np.asarray(sigma_p0, dtype=float)
    debit = np.zeros(nt)
    anchored = np.zeros(nt, dtype=bool)
    cum = np.zeros(3)
    eps_prev = np.zeros(nt)
    eps_tot = np.zeros(nt)

    for j in order:
        act = PrestressAction.from_force(
            float(sp0[j] * Ap[j]), float(x[j]), float(y[j]),
            x_ref=xr, y_ref=yr, label=f"jack{j}", origin="fingerprint")
        cum = cum + np.asarray(act.triple(), dtype=float)
        s = solver.solve_equilibrium(cum[0], cum[1], cum[2], tol=tol,
                                     max_iter=max_iter)
        eps_tot = s["eps0"] + s["chi_x"] * ly - s["chi_y"] * lx
        d_eps = eps_tot - eps_prev
        eps_prev = eps_tot
        mask = anchored.copy()
        mask[j] = False
        debit[mask] += -Ep * d_eps[mask]
        anchored[j] = True

    return {"sigma_p_after": sp0 - debit, "loss": debit, "eps_c": eps_tot}


def _closed_form_sequence(Ec, Ep, *, Ac, Sc, Ic, y_tendons, Ap,
                          sigma_p0, order, y_ref):
    r"""
    The sequential post-tension losses from the **closed form**.

    A thin call into
    :func:`gensec.solver.prestress_transfer.sequential_posttension_loss`,
    kept as a named function so that the one place this fingerprint
    reaches into that module is explicit rather than buried in a probe.

    Why the closed form beside :func:`_cumulative_reference`
    -------------------------------------------------------
    The two references are independent of the driver in different
    degrees, and the difference is not cosmetic:

    ===================== =================================================
    ``_cumulative_reference``  independent **form** (cumulative instead of
                          incremental), shared **machinery** — it builds a
                          :class:`FiberSolver` and calls the driver's own
                          private ``_stressing_view``.  A defect in the
                          integrator moves both sides together and the
                          divergence stays small.
    this one              independent form **and** machinery: pure
                          transformed-section algebra, a 2x2 solve per
                          step, no fiber model, no import from
                          ``posttension``.  A defect in the integrator
                          moves one side only.
    ===================== =================================================

    Its price is that it assumes a **constant** modulus, so it is the
    right answer on the linear law and a declared approximation on the
    service law.  Both are recorded: the linear key must read exactly
    zero, the nonlinear one prices the constant-modulus assumption on
    this member.

    Parameters
    ----------
    Ec, Ep : float
        Concrete and tendon moduli [MPa].
    Ac, Sc, Ic : float
        Transformed properties of the resisting view about *y_ref*.
    y_tendons : sequence of float
        Tendon ordinates [mm].
    Ap : float
        Tendon area, one value for all tendons [mm²].
    sigma_p0 : float
        Jacking stress, one value for all tendons [MPa].
    order : sequence of int
        Stressing order.
    y_ref : float
        Reference ordinate the driver used [mm].

    Returns
    -------
    dict
        As returned by the closed form: ``loss``, ``sigma_p_after``,
        ``eps_ref_grout``, ``order``, ``scheme``.
    """
    from gensec.solver.prestress_transfer import sequential_posttension_loss

    return sequential_posttension_loss(
        Ec, 0.0, Ep, Ac=Ac, Sc=Sc, Ic=Ic,
        tendons=[{"y": float(yt), "Ap": float(Ap),
                  "sigma_p0": float(sigma_p0)} for yt in y_tendons],
        order=list(order), y_ref=float(y_ref), scheme="one_pass")


def _nonlinear_increment(rec: Recorder) -> None:
    r"""
    Record **D1c**: the increment form of the post-tensioning driver.

    Synthetic and example-free, the same shape as
    :func:`_retrofit_declaration` and for the same reason: no
    distributed model reaches the driver on a law whose tangent varies,
    so the measurand does not exist in ``examples/`` and putting it
    there would be inventing a model to suit an instrument.

    What is recorded
    ----------------
    ``d1c.law.tangent_ratio[...]``
        The service law's own tangent against :math:`E_{cm}`, at five
        strains.  **Numbers on both trees, and immobile**: they belong
        to the law declared in this file, not to the driver.  A tree on
        which they moved would have changed the ruler, and every other
        key here would be unreadable.
    ``d1c.form``
        What the driver **says** its increment form is, fetched with
        :func:`getattr` from the result: ``'undeclared'`` where it says
        nothing.  D1c is not that the driver is wrong on the linear
        case — there it is exact — it is that it does not declare the
        premise it assumes.  A declaration that appears is a movement
        of this key, which is how a repair that moves no number is made
        visible at all (``20_1 §3``).
    ``d1c.nonlinear.{virgin,staged,retrofit}.*``
        Stresses, losses and concrete strains on the **service** law,
        for the three shapes of sequence: constant tendon-free view,
        intra-sequence injection (``bonded_before``), and a declared
        retrofit.  These are the keys the repair is expected to move.
    ``d1c.linear.{virgin,staged,retrofit}.*``
        The identical battery on a constant-modulus law.  **These must
        not move by a single bit.**  The cumulative form reduces
        exactly to the incremental one when the section is linear, so a
        movement here is an implementation error and not a model
        difference — the discriminator ``3.1`` of the Phase-25 brief
        asks for by name.
    ``d1c.divergence.virgin.*``
        The driver against :func:`_cumulative_reference` on the service
        law, as a relative figure.  This is the number that justifies
        the phase, and it is in the fingerprint rather than only in the
        ledger.  It is **large** on a tree that assumes superposition
        and goes to solver noise on one that does not.
    ``d1c.divergence.{linear,nonlinear}.max_rel_sigma_closed_form``
        The driver against :func:`_closed_form_sequence`, which shares
        no code with it at all (Phase 37).  The **linear** key must
        read exactly ``0``: the transformed-section closed form and
        the fiber model are the same linear algebra, so any movement
        there is an implementation error and not a model difference —
        the same discriminator role ``d1c.linear.*`` plays, but taken
        from outside the fiber machinery instead of inside it.  The
        **nonlinear** key reads ``2.14e-2`` on this member and is not
        a defect: it prices the constant-modulus assumption the closed
        form makes against the Sargin tangent the driver uses.  These
        two keys are also the only ones in this fingerprint that enter
        :mod:`gensec.solver.prestress_transfer`, which until Phase 37
        was the one solver module no probe reached.

    Parameters
    ----------
    rec : Recorder

    Notes
    -----
    The geometry is the one every published measurement of this defect
    family uses (``22_0 §1.1``): a 400 x 1200 rectangle, three tendons
    :math:`A_p = 1500\,\mathrm{mm^2}` at :math:`y = 150/200/250`,
    :math:`E_p = 195\,000`.  The concrete is C35/45 at
    :math:`f_{cm} = 43`, :math:`E_{cm} = 34\,077`,
    :math:`\varepsilon_{c1} = -2.2\cdot10^{-3}`, which is the material
    the Phase-24 softening table was measured on (``24_0 §2.6``).
    """
    from gensec.geometry.fiber import Tendon
    from gensec.geometry.section import RectSection
    import gensec.solver.posttension as _pt

    B, H, N_Y = 400.0, 1200.0, 240
    EP, AP, SP0 = 195000.0, 1500.0, 1300.0
    Y_TENDONS = (150.0, 200.0, 250.0)
    FCK = 35.0                          # C35/45
    SIGMA_PE, EPS0_EX, CHIX_EX = 1100.0, -3.0e-4, 1.5e-7
    XREF_D, YREF_D, AGE_C, AGE_P = 0.0, 0.0, 14600.0, 14200.0
    NAN = float("nan")

    sargin = _EC2ServiceLaw(FCK)
    ECM = sargin.Ecm
    lin_bulk, strand = _retrofit_laws(ECM, EP)

    # --- the ruler ------------------------------------------------------
    for eps in (-1.0e-4, -3.0e-4, -6.0e-4, -9.0e-4, -1.2e-3):
        rec.put(f"d1c.law.tangent_ratio[{eps:.1e}]",
                float(sargin.tangent(eps) / ECM))

    def _section(bulk):
        tendons = [Tendon(y=float(yt), x=B / 2.0, material=strand,
                          Ap=AP, eps_pe=0.0) for yt in Y_TENDONS]
        return RectSection(B=B, H=H, bulk_material=bulk, rebars=[],
                           n_fibers_y=N_Y, tendons=tendons)

    def _named_reason(exc) -> str:
        return str(getattr(exc, "reason", None)
                   or f"unnamed:{type(exc).__name__}")

    decl_cls = getattr(_pt, "PreexistingState", None)

    def _declared_state():
        if decl_cls is None:
            return None
        return decl_cls(sigma_pe={0: SIGMA_PE}, eps0=EPS0_EX,
                        chi_x=CHIX_EX, chi_y=0.0, x_ref=XREF_D,
                        y_ref=YREF_D, concrete_age_days=AGE_C,
                        tendon_age_days={0: AGE_P})

    cases = {
        "virgin": dict(sigma_p0=[SP0] * 3, order=[0, 1, 2]),
        "staged": dict(sigma_p0=[SP0] * 3, order=[0, 1, 2],
                       bonded_before={0: 1, 1: 2}),
        "retrofit": dict(sigma_p0=[NAN, SP0, SP0], order=[1, 2],
                         pending=[], already_bonded="DECLARED"),
    }

    form_seen = "undeclared"
    for law_tag, bulk in (("nonlinear", sargin), ("linear", lin_bulk)):
        for case, kwargs in cases.items():
            keys = ([f"d1c.{law_tag}.{case}.sigma_p_after[{k:02d}]"
                     for k in range(3)]
                    + [f"d1c.{law_tag}.{case}.loss[{k:02d}]"
                       for k in range(3)]
                    + [f"d1c.{law_tag}.{case}.eps_c[{k:02d}]"
                       for k in range(3)])
            kw = dict(kwargs)
            if kw.get("already_bonded") == "DECLARED":
                state = _declared_state()
                if state is None:
                    for key in keys:
                        rec.put(key, "refused:absent")
                    continue
                kw["already_bonded"] = state
            try:
                res = _pt.solve_posttension_sequence(
                    _section(bulk), Ep=EP, **kw)
            except BaseException as exc:    # noqa: BLE001 — outcome is data
                token = f"refused:{_named_reason(exc)}"
                for key in keys:
                    rec.put(key, token)
                continue
            declared = getattr(res, "increment_form", None)
            if declared is not None:
                form_seen = str(declared)
            for k in range(3):
                rec.put(keys[k], float(res.sigma_p_after[k]))
                rec.put(keys[3 + k], float(res.loss[k]))
                rec.put(keys[6 + k], float(res.eps_ref_grout[k]))

    rec.put("d1c.form", form_seen)

    # --- the driver against an independent cumulative reference ---------
    for law_tag, bulk in (("nonlinear", sargin), ("linear", lin_bulk)):
        try:
            got = _pt.solve_posttension_sequence(
                _section(bulk), sigma_p0=[SP0] * 3, Ep=EP, order=[0, 1, 2])
            ref = _cumulative_reference(_section(bulk), [SP0] * 3,
                                        [0, 1, 2], EP)
            d_sig = max(
                abs(float(ref["sigma_p_after"][k])
                    - float(got.sigma_p_after[k]))
                / abs(float(got.sigma_p_after[k]))
                for k in range(3))
            d_eps = max(
                abs(float(ref["eps_c"][k]) - float(got.eps_ref_grout[k]))
                / max(abs(float(got.eps_ref_grout[k])), 1e-30)
                for k in range(3))
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            rec.put(f"d1c.divergence.{law_tag}.max_rel_sigma",
                    f"refused:{_named_reason(exc)}")
            rec.put(f"d1c.divergence.{law_tag}.max_rel_eps_c",
                    f"refused:{_named_reason(exc)}")
            continue
        rec.put(f"d1c.divergence.{law_tag}.max_rel_sigma", float(d_sig))
        rec.put(f"d1c.divergence.{law_tag}.max_rel_eps_c", float(d_eps))

    # --- the driver against a reference that shares no code with it -----
    #: _cumulative_reference above is independent in FORM and not in
    #: MACHINERY: it builds a FiberSolver and calls the driver's own
    #: private _stressing_view.  sequential_posttension_loss shares
    #: neither -- it is 2x2 transformed-section algebra and imports
    #: nothing from posttension.py.  Phase 37 measured the consequence:
    #: it is exact to the last bit on a linear law, so the linear key
    #: below is a discriminator with no tolerance to hide behind, and
    #: it is the only key in this fingerprint that enters
    #: solver/prestress_transfer.py at all.
    for law_tag, bulk in (("nonlinear", sargin), ("linear", lin_bulk)):
        key = f"d1c.divergence.{law_tag}.max_rel_sigma_closed_form"
        try:
            sec = _section(bulk)
            got = _pt.solve_posttension_sequence(
                sec, sigma_p0=[SP0] * 3, Ep=EP, order=[0, 1, 2])
            #: No tendon is bonded during the virgin sequence, so the
            #: resisting view is the bulk alone and its transformed
            #: properties are the meshed bulk's about the same
            #: reference the driver used.
            view = _pt._stressing_view(sec, None, bonded=())
            A = np.asarray(view.A_fibers, dtype=float)
            y_ref = float(view.y_centroid)
            d = np.asarray(view.y_fibers, dtype=float) - y_ref
            ref = _closed_form_sequence(
                ECM, EP, Ac=float(np.sum(A)), Sc=float(np.sum(A * d)),
                Ic=float(np.sum(A * d * d)), y_tendons=Y_TENDONS,
                Ap=AP, sigma_p0=SP0, order=[0, 1, 2], y_ref=y_ref)
            d_sig = max(
                abs(float(ref["sigma_p_after"][k])
                    - float(got.sigma_p_after[k]))
                / abs(float(got.sigma_p_after[k]))
                for k in range(3))
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            rec.put(key, f"refused:{_named_reason(exc)}")
            continue
        rec.put(key, float(d_sig))


def _cli_run_wiring(rec: Recorder) -> None:
    r"""
    Pin the **wiring** of the ``gensec run`` verb, not its physics.

    Why this bench exists
    ---------------------
    ``src/gensec/cli.py`` is 953 lines and no key of any of the three
    captures reached it.  Every family gets to the engines through the
    Python API, so the verb could stop calling an engine altogether and
    nothing would move.  Measured in Phase 37: ``run`` calls
    :func:`~gensec.solver.timeline_run.run_timeline`, then
    :func:`~gensec.solver.timeline_run.run_sls`, then
    :func:`~gensec.output.report.print_sls_results` — and **that order
    was held by nothing**.

    The claim that fourteen test files name ``cli`` does not survive
    reading them: the matches are the substring inside *declines* and
    *client*.  Exactly one fixture mentions the verb,
    ``test_phase33_sls_yaml_surface.test_the_cli_run_verb_names_sls``,
    and it opens ``cli.py`` and asserts that the strings ``run_sls``
    and ``print_sls_results`` occur in the text.  That is a grep in a
    fixture: it passes on a tree where both names occur only inside a
    comment.  Nothing in the suite runs ``cli.main``.

    What is recorded, and what deliberately is not
    ---------------------------------------------
    ================================ ==================================
    ``cli.<case>.order``             the call sequence, consecutive
                                     repeats collapsed.  This is the
                                     key an inverted wiring moves.
    ``cli.<case>.calls.<engine>``    how many times each of the three
                                     was invoked.  **Zero is written
                                     as zero**: a skipped invocation is
                                     a recorded zero, not an absent
                                     key, because an absent key and a
                                     deleted probe look alike.
    ``cli.<case>.timeline_active``   whether ``run_timeline`` returned
                                     a timeline or ``None`` — the
                                     branch that decides whether
                                     anchored combinations are removed
                                     from the legacy loop.
    ``cli.<case>.sls_requested``     ``run_sls``'s own count of
                                     combinations declaring an ``sls``
                                     block.  ``'not invoked'`` where
                                     the engine was never reached, so
                                     "asked for nothing" and "never
                                     asked" are different values.
    ``cli.<case>.exit_code``         ``0`` on a valid document, the
                                     status of the ``SystemExit`` on a
                                     rejected one.
    ================================ ==================================

    The **printed text is not recorded**.  ``report.*`` has held what
    ``print_sls_results`` renders since Phase 36, and a second key on
    the same fact is a second thing to update and no extra
    discriminator.

    The document is :func:`_yaml_sls_doc`, already synthetic and
    already the home of the SLS surface bench, so the two move
    together and there is one document to edit rather than two.

    Parameters
    ----------
    rec : Recorder

    Notes
    -----
    ``cli.main`` imports the three engines **inside** the function
    body, so the spies are installed on the modules that define them
    and are seen at call time.  They are removed in a ``finally``: a
    bench that leaked a spy would silently instrument every probe that
    runs after it.
    """
    import contextlib
    import io as _io
    import tempfile

    import yaml as _yaml

    pre = "cli"
    engines = ("run_timeline", "run_sls", "print_sls_results")

    try:
        import gensec.cli as CLI
        import gensec.solver.timeline_run as TR
        import gensec.output.report as RP
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail(f"{pre}.build", exc)
        return

    base_limits = {"kind": "characteristic", "fyk": 450.0, "fpk": 1860.0}
    refused = _yaml_sls_doc(None)
    #: A negative characteristic strength is refused by the material
    #: layer, before any engine is reached.  The case exists to record
    #: that a rejected document reaches NONE of the three, which is a
    #: different fact from reaching them and failing.
    refused["materials"]["c_precast"]["fck"] = -1.0

    cases = (
        ("with_sls", _yaml_sls_doc({"moduli": dict(_YSLS_MODULI),
                                    "limits": dict(base_limits)})),
        ("without_sls", _yaml_sls_doc(None)),
        ("refused", refused),
    )

    for tag, doc in cases:
        calls: List[str] = []
        seen = {"timeline": "not invoked", "requested": "not invoked"}
        originals = (TR.run_timeline, TR.run_sls, RP.print_sls_results)

        def _spy(name, fn):
            def inner(*a, **k):
                calls.append(name)
                out = fn(*a, **k)
                if name == "run_timeline":
                    seen["timeline"] = bool(out is not None)
                elif name == "run_sls":
                    seen["requested"] = int(out["requested"])
                return out
            return inner

        TR.run_timeline = _spy("run_timeline", originals[0])
        TR.run_sls = _spy("run_sls", originals[1])
        RP.print_sls_results = _spy("print_sls_results", originals[2])

        code = 0
        try:
            with tempfile.TemporaryDirectory() as tmp:
                path = os.path.join(tmp, "doc.yaml")
                with open(path, "w", encoding="utf-8") as fh:
                    _yaml.safe_dump(doc, fh, sort_keys=False)
                with contextlib.redirect_stdout(_io.StringIO()):
                    CLI.main(["run", path, "--n-points", "8",
                              "--output-dir", tmp])
        except SystemExit as exc:
            code = int(exc.code or 0)
        except BaseException as exc:        # noqa: BLE001 -- failure is data
            code = f"raised:{type(exc).__name__}"
        finally:
            (TR.run_timeline, TR.run_sls,
             RP.print_sls_results) = originals

        #: Consecutive repeats collapse: the sequence is the fact, the
        #: multiplicity is held by the count keys beside it.
        order = [c for i, c in enumerate(calls)
                 if i == 0 or c != calls[i - 1]]
        rec.put(f"{pre}.{tag}.order", "|".join(order) if order else "-")
        for name in engines:
            rec.put(f"{pre}.{tag}.calls.{name}", int(calls.count(name)))
        rec.put(f"{pre}.{tag}.timeline_active", seen["timeline"])
        rec.put(f"{pre}.{tag}.sls_requested", seen["requested"])
        rec.put(f"{pre}.{tag}.exit_code", code)


def _probe_example(rec: Recorder, path: str) -> None:
    """
    Run every probe on one example file.

    Parameters
    ----------
    rec : Recorder
    path : str
        Absolute path to the YAML file.
    """
    from gensec.io_yaml import load_yaml
    from gensec.solver.integrator import FiberSolver

    tag = os.path.splitext(os.path.basename(path))[0]

    try:
        data = load_yaml(path)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.load", exc)
        return
    rec.put(f"{tag}.load", "ok")

    section = data.get("section")
    if section is None:
        rec.put(f"{tag}.section", "absent")
        return

    for probe, args in ((_mesh_moments, (section,)),
                        (_properties, (section,)),
                        (_design_strength, (path,)),
                        (_posttension_sequence, (data,))):
        try:
            probe(rec, tag, *args)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{tag}.{probe.__name__}", exc)

    try:
        solver = FiberSolver(section)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.solver", exc)
        return

    # The counter spans every probe that can reach the fast path, and
    # is read *before* ``_axial_path`` runs: that probe calls
    # ``_solve_pure_axial`` on purpose, so counting its own calls would
    # report the instrument instead of the tree.
    with _FastPathCounter(FiberSolver) as counter:
        _direct_response(rec, tag, solver)
        _scan_hull(rec, tag, solver)
        _domain(rec, tag, solver)
        _moment_curvature(rec, tag, solver)
        _decomposition_closure(rec, tag, solver, "base")
        _staged_moment_curvature(rec, tag, data)
        _equilibrium(rec, tag, solver, data.get("demands") or {})
        entries = counter.entries

    try:
        _axial_path(rec, tag, solver, entries)
    except Exception as exc:                # noqa: BLE001 — failure is data
        rec.fail(f"{tag}.axial.fastpath_entries", exc)


# ----------------------------------------------------------------------
#  Phase 30 -- the reported coordinate, and the undeclared silence
# ----------------------------------------------------------------------

#: Demands at which the reported extreme-fibre coordinate is captured.
#:
#: Each entry is ``(example file, bulk material name, [Mx in kNm])``.
#: The demands were **measured first** and chosen afterwards (E28-2):
#: on the pristine tree the first two files put the reported point
#: outside their own material at these demands, the tee is non-convex
#: and yet unaffected at its demands, and the last two are convex and
#: can never be affected.  A probe whose every case is affected cannot
#: tell a repair from a coincidence.
_COORD_CASES = (
    ("example_custom.yaml", "concrete_1", (100.0, 300.0)),
    ("example_annulus.yaml", "concrete_1", (700.0, 1000.0)),
    ("example_tee.yaml", "concrete_1", (100.0, 200.0)),
    ("example_input.yaml", "concrete_1", (50.0, 100.0, 200.0)),
    ("vcaslu_1.yaml", "C25", (50.0, 100.0)),
)


def _phase30_service_law(fck: float = 35.0):
    """
    Build the EN 1992-1-1 (3.14) service law used by the Phase-30 probes.

    Parameters
    ----------
    fck : float, optional
        Characteristic cylinder strength [MPa].  Default 35.0.

    Returns
    -------
    ServiceConcrete
        The law, at a reference age of 28 days.
    """
    from gensec.materials.ec2_bridge import fben2
    from gensec.materials.service_concrete import ServiceConcrete

    p = fben2(fck=fck, ls="F", loadtype="slow", TypeConc="N")
    return ServiceConcrete(fcm=p.fcm, Ecm=p.ecm,
                           eps_c1=abs(float(p.eps_c1)),
                           eps_cu1=0.0035, fct_eff=float(p.fctm),
                           reference_age=28.0, name="phase30 svc")


def _reported_coordinates(rec: Recorder) -> None:
    r"""
    Probe the **coordinate** the extreme-fibre record publishes.

    Why this probe exists
    ---------------------
    :func:`gensec.solver.sls._zone_candidates` adds, to the vertices of a
    zone's material region, the points where the zone's own law turns
    over -- EN 1992-1-1 (3.14) peaks at :math:`-\varepsilon_{c1}` and the
    tension branch drops to zero past :math:`\varepsilon_{ct}`.  A
    turning point is located by linear interpolation along the segment
    joining the two extreme-strain vertices:

    .. math::

        \mathbf{p}(t) = \mathbf{p}_{lo}
                      + t\,(\mathbf{p}_{hi} - \mathbf{p}_{lo}),
        \qquad
        t = \frac{\varepsilon_b - \varepsilon_{lo}}
                 {\varepsilon_{hi} - \varepsilon_{lo}} .

    On a **convex** region that point lies inside the material.  On a
    re-entrant or holed region the segment leaves the region, and the
    record then names a coordinate where there is no material at all.
    The **value** is right -- the region is connected, the strain field
    is continuous, so by the intermediate-value theorem the breakpoint
    strain is attained by real material somewhere -- but the label is
    not.  It is F6 in miniature.

    Before this probe the instrument was blind to it.  Measured on the
    pristine tree: of 5877 numeric keys, **four** carry a reported
    coordinate (``sls_nl.{lin,svc}.{single,staged}.report.y_at_*``),
    all of them the :math:`y` component only, and all of them on a
    rectangular -- hence convex -- section.  Zero keys carry an
    :math:`x`.  The magnitude was measured before the probe was built
    around it (E28-2): sweeping the strain direction over 360 angles on
    the three non-convex zones of the example set, ``example_annulus``
    puts a candidate outside its material for 360/360 directions (worst
    excursion 366.335 mm into the void), ``example_custom`` for 359/360
    (108.788 mm), and ``example_tee`` for 121/360 (17.144 mm) -- the
    last contradicting ``29_0`` §10, which recorded the tee as
    unaffected on the strength of a single bending direction.

    What is recorded, per file and demand
    -------------------------------------
    ``at_min.x``, ``at_min.y``, ``at_max.x``, ``at_max.y``
        The published coordinate, both components.  These move when the
        coordinate is repaired.
    ``at_min.dist_outside``, ``at_max.dist_outside``
        Distance from the published point to the zone's material region,
        in mm; zero when the point is material.  This is the
        discriminator: it is strictly positive on the pristine tree for
        the affected cases and must be zero on a repaired one.
    ``sigma_min``, ``sigma_max``
        The stress the record publishes at those points.  This is the
        **control**.  The repair relabels a point; it must not move a
        value.  If these move, something other than the label changed.

    The probe runs through the public entry point
    :func:`gensec.solver.sls.verify_sls_staged` on **distributed
    example files**, not through the private helper: what is at issue is
    the coordinate a user reads out of the record, so that is the
    surface that is measured.

    Parameters
    ----------
    rec : Recorder
    """
    from shapely.geometry import Point as _SPoint

    try:
        from gensec.io_yaml import load_yaml
        from gensec.materials.verification_limits import StressLimits
        from gensec.solver.section_state import SectionState
        from gensec.solver.sls import _zone_regions, verify_sls_staged
        law = _phase30_service_law(35.0)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail("coord.build", exc)
        return

    for fname, mat_name, demands in _COORD_CASES:
        path = os.path.join(ROOT, "examples", fname)
        stem = fname[:-5] if fname.endswith(".yaml") else fname
        try:
            section = load_yaml(path)["section"]
            region = _zone_regions(section)[0]
        except Exception as exc:            # noqa: BLE001 -- failure is data
            rec.fail(f"coord.{stem}.load", exc)
            continue
        # The region's own convexity is recorded, not assumed: it is the
        # property that decides whether the case can be affected at all.
        rec.put(f"coord.{stem}.convex",
                bool(region.equals(region.convex_hull)))
        parts = (region.geoms if hasattr(region, "geoms") else [region])
        rec.put(f"coord.{stem}.holes",
                int(sum(len(g.interiors) for g in parts if not g.is_empty)))

        n_el = (len(getattr(section, "rebars", []) or [])
                + len(getattr(section, "tendons", []) or []))
        state = SectionState(0, np.ones(n_el, dtype=bool),
                             np.ones(n_el, dtype=bool),
                             np.zeros(n_el, dtype=float),
                             bulk_eps_init=0.0, label="c")
        minx, miny, maxx, maxy = region.bounds
        for m_kn in demands:
            pre = f"coord.{stem}[M={m_kn:.0f}]"
            stages = [{"name": "c", "state": state,
                       "increment": (0.0, m_kn * 1.0e6, 0.0),
                       "limits": StressLimits(name="c",
                                              k_c=0.6)}]
            try:
                res = verify_sls_staged(
                    section, stages, moduli={mat_name: law},
                    x_ref=0.5 * (minx + maxx), y_ref=0.5 * (miny + maxy))
            except Exception as exc:        # noqa: BLE001 -- failure is data
                rec.fail(f"{pre}.run", exc)
                continue
            conc = res["stages"][0]["concrete"]
            for tag in ("at_min", "at_max"):
                pt = conc.get(tag)
                if pt is None:
                    rec.put(f"{pre}.{tag}.x", "absent")
                    rec.put(f"{pre}.{tag}.y", "absent")
                    rec.put(f"{pre}.{tag}.dist_outside", "absent")
                    continue
                x, y = float(pt[0]), float(pt[1])
                rec.put(f"{pre}.{tag}.x", x)
                rec.put(f"{pre}.{tag}.y", y)
                rec.put(f"{pre}.{tag}.dist_outside",
                        float(region.distance(_SPoint(x, y))))
            rec.put(f"{pre}.sigma_min", float(conc["sigma_min_MPa"]))
            rec.put(f"{pre}.sigma_max", float(conc["sigma_max_MPa"]))


#: The four element configurations the silence probe runs.
#:
#: ``_dec_section`` carries two rebar layers and one bonded tendon, so
#: the union order is ``[rebar, rebar, tendon]``.  Each entry is
#: ``(tag, active flags, bonded flags)``.
_SILENCE_CONFIGS = (
    ("bonded", (True, True, True), (True, True, True)),
    ("unbonded", (True, True, True), (True, True, False)),
    ("no_rebar", (False, False, True), (False, False, True)),
    ("no_tendon", (True, True, False), (True, True, False)),
)


# ======================================================================
#  The multi-zone check bench (Phase 31, task A)
# ======================================================================

#: Geometry of the two-zone bench: a 300 x 600 member of which the top
#: 150 mm is a topping of a **different concrete class**.
_MZ_B, _MZ_H, _MZ_HT = 300.0, 600.0, 150.0
#: The two classes.  These are not chosen for the bench: they are the
#: classes of **all five** composite sections in ``examples/`` --
#: ``composite_topping``, ``composite_losses``, ``composite_timeline``,
#: ``staged_cracking``, ``composite_losses_fb_gap`` -- every one of which
#: is base C45 over topping C30.  A bench on invented classes would
#: measure a defect nobody has.
_MZ_FCK_BASE, _MZ_FCK_TOP = 45.0, 30.0
_MZ_AS, _MZ_AP = 800.0, 1500.0
_MZ_EPS_PE = 0.0006
#: Hogging, so the **topping** carries the governing compression: the
#: weaker concrete in the more stressed place, which is the arrangement
#: a single section-wide limit gets wrong.
#:
#: The magnitude is not round-numbered for tidiness, it is **measured**.
#: Scanning the bench section:
#:
#: .. code-block:: text
#:
#:     M [kNm]   base       topping    <= 0.6*45   <= 0.6*30
#:      -250     -5.1804   -16.2936      pass        pass
#:      -300     -5.9493   -19.5415      pass        FAIL
#:      -350     -6.7273   -22.5753      pass        FAIL
#:      -400     -7.5508   -25.3984      pass        FAIL
#:      -450     -8.5307   -28.1807      FAIL        FAIL
#:
#: -350 kNm sits in the middle of the band where the two answers
#: **disagree**: the topping is at 22.5753 MPa, which is 25.4 % above its
#: own limit of 18.0 and 16.4 % below the section-wide 27.0.  Both
#: margins are far from any rounding boundary, so the discriminant is a
#: verdict flip and not a last-digit difference.
_MZ_MX = -350.0e6


# ==================================================================
#  Phase 32 -- the C5 loss bench
# ==================================================================

#: Geometry of the C5 bench beam [mm]: a post-tensioned precast girder
#: that later receives a topping.  Deliberately the shape of
#: ``examples/example_composite_losses.yaml`` and deliberately **not**
#: that file: an example belongs to whoever edits it next, and a bench
#: reading one moves when that editor moves it, for reasons that have
#: nothing to do with rheology.
_C5_B, _C5_H, _C5_HT = 600.0, 1400.0, 200.0

#: The two concretes.  The gap is the point: a precast cured in a yard
#: and a topping cast on it are different ages under different creep,
#: which is the state EN 1992-1-1 (5.46) cannot express and the state
#: this bench exists to pin.
_C5_FCK_PRECAST, _C5_FCK_TOPPING = 45.0, 30.0

#: Reinforcement areas [mm^2] and the single tendon.
_C5_AS_BOT, _C5_AS_TOP, _C5_AP = 530.9, 201.1, 2000.0

#: Jacking stress [MPa] and the two permanent demands [N, N*mm].
_C5_SIGMA_P0 = 1300.0
_C5_G1 = (-300.0e3, -220.0e6, 0.0)
_C5_G2 = (0.0, -180.0e6, 0.0)

#: The three interval lengths [d]: precast alone to 90 d, the props-in
#: window while the topping cures, then on to 70 years.
_C5_DAYS = (62.0, 3.0, 25457.0)

#: Declared ages and curing ends [d], per zone, at the moment the
#: timeline first sees each.  Every later age is derived by the walk.
_C5_AGE = {"base": (28.0, 3.0), "topping": (3.0, 1.0)}


def _c5_section():
    r"""
    The C5 bench section: precast girder plus a later topping.

    Returns
    -------
    tuple
        ``(section, losses_models, zone_rheology, history, demand_db)``
        -- everything :meth:`ConstructionTimeline.from_block` and
        :meth:`~gensec.solver.timeline.ConstructionTimeline.resolve`
        need, built in Python so that no distributed document can move
        this bench.
    """
    from shapely.geometry import Polygon as _Poly

    from gensec.geometry.fiber import RebarLayer, Tendon
    from gensec.geometry.geometry import GenericSection
    from gensec.materials.concrete import Concrete
    from gensec.materials.ec2_bridge import prestress_from_class
    from gensec.materials.steel import Steel

    precast = Concrete(fck=_C5_FCK_PRECAST, gamma_c=1.5,
                       long_term_reduction_factor=0.85)
    precast.name = "c_precast"
    topping = Concrete(fck=_C5_FCK_TOPPING, gamma_c=1.5,
                       long_term_reduction_factor=0.85)
    topping.name = "c_topping"
    st = Steel(fyk=450.0)
    st.name = "steel"
    # Through the EC2 bridge, not the bare container: the intrinsic
    # relaxation is a function of mu = sigma_pi / f_pk, and a tendon
    # with no f_pk makes the relaxation walk refuse -- correctly.
    ps = prestress_from_class("Y1860S7", ls="F", diagram="inclined", NA='EC2', eps_ud_factor=0.9)
    ps.name = "strand"

    poly = _Poly([(0.0, 0.0), (_C5_B, 0.0), (_C5_B, _C5_H), (0.0, _C5_H)])
    top = _Poly([(0.0, _C5_H - _C5_HT), (_C5_B, _C5_H - _C5_HT),
                 (_C5_B, _C5_H), (0.0, _C5_H)])
    reb = [RebarLayer(y=60.0, As=_C5_AS_BOT, material=st, x=60.0),
           RebarLayer(y=60.0, As=_C5_AS_BOT, material=st, x=540.0),
           RebarLayer(y=1340.0, As=_C5_AS_TOP, material=st, x=60.0),
           RebarLayer(y=1340.0, As=_C5_AS_TOP, material=st, x=540.0)]
    ten = [Tendon(y=150.0, Ap=_C5_AP, material=ps, x=300.0,
                  eps_pe=0.0, name="P1", bonded=True)]
    section = GenericSection(poly, precast, reb, tendons=ten,
                             bulk_materials=[(top, topping, "topping")],
                             n_grid_y=40)

    raw_models = {
        "rheo_precast": {"provider": "ec2", "fck": _C5_FCK_PRECAST,
                         "cement_class": "R", "RH": 70.0, "chi": "lump",
                         "relaxation_reduction": 0.8},
        "rheo_topping": {"provider": "ec2", "fck": _C5_FCK_TOPPING,
                         "cement_class": "N", "RH": 70.0, "chi": "lump",
                         # EN 1992-1-1 3.1.2(5) states f_ck(t) only from
                         # three days; the floor below is the bench's
                         # own, declared with its provenance rather than
                         # borrowed from a clause that does not cover
                         # the age.
                         "declared": {"linearity_limit": {
                             "value": 1.0, "domain": [0.0, 3.0],
                             "source": ("Bench declaration, outside the "
                                        "validity range of EN 1992-1-1 "
                                        "3.1.2(5).")}}},
    }
    zone_rheology = {
        z: {"model": ("rheo_precast" if z == "base" else "rheo_topping"),
            "age": a, "curing": c}
        for z, (a, c) in _C5_AGE.items()
    }
    d1, d2, d3 = _C5_DAYS
    history = [
        {"load": {"demand": "G1"}},
        {"stress": {"tendons": ["P1"], "sigma_p0": _C5_SIGMA_P0}},
        {"grout": {"tendons": ["P1"]}},
        {"point": "transfer"},
        {"interval": {"days": d1,
                      "losses": {"base": {"model": "rheo_precast",
                                          "age": _C5_AGE["base"][0],
                                          "curing": _C5_AGE["base"][1]}}}},
        {"cast": {"zone": "topping", "datum": "auto"}},
        {"interval": {"days": d2,
                      "losses": {"base": {"model": "rheo_precast"},
                                 "topping": {
                                     "model": "rheo_topping",
                                     "age": _C5_AGE["topping"][0],
                                     "curing": _C5_AGE["topping"][1]}}}},
        {"load": {"demand": "G2"}},
        {"point": "composite"},
        {"interval": {"days": d3,
                      "losses": {"base": {"model": "rheo_precast"},
                                 "topping": {"model": "rheo_topping"}}}},
        {"point": "service"},
    ]
    demand_db = {
        "G1": {"N": _C5_G1[0], "Mx": _C5_G1[1], "My": _C5_G1[2]},
        "G2": {"N": _C5_G2[0], "Mx": _C5_G2[1], "My": _C5_G2[2]},
    }
    return section, raw_models, zone_rheology, history, demand_db


def _c5_losses(rec: Recorder) -> None:
    r"""
    Pin the **time-dependent loss physics** of a composite member.

    Why this bench exists
    ---------------------
    Phase 31 measured it (finding Z-3): of the 390 keys
    ``examples/example_composite_losses.yaml`` contributes to this
    fingerprint, **zero** name :math:`\Delta\sigma_p`,
    :math:`\Delta\sigma_{pr}`, :math:`\varphi`, :math:`\chi`, shrinkage,
    creep or relaxation.  The whole C5 arc is covered by its own
    validator -- which answers *pass* or *fail* -- and by nothing that
    answers *moved by how much*.  A phase that broke the topping's creep
    would have left this instrument green.

    What is recorded, and why exactly these
    ---------------------------------------
    Nineteen keys, over the three intervals that carry losses:

    ================= ============================================
    ``d_sigma_p``     total tendon loss over the interval [MPa],
                      signed negative -- the number an engineer
                      quotes.
    ``d_sigma_pr``    the applied (reduced) intrinsic relaxation
                      [MPa].  Recorded **beside** the total because
                      it is the only part that moves the tendon's
                      prestrain: a change that shifts the split
                      without shifting the sum is a real change and
                      one key could not see it.
    ``phi``           the creep coefficient actually used, per zone.
    ``chi``           the ageing coefficient actually used, per zone.
    ``loss_fraction`` :math:`-\Delta\sigma_p / \sigma_{p0}`, the
                      dimensionless form.  It is derived, and it is
                      recorded because a reformulation that rescales
                      stresses without changing physics moves the
                      MPa keys and leaves this one still.
    ================= ============================================

    The first interval has one zone present, the other two have both:
    :math:`5 + 7 + 7 = 19`.

    The larger form was considered and refused
    ------------------------------------------
    A 42-key form was on the table: per-zone eigenstrain planes, the
    ``u`` vectors, the initial zone stresses.  Those are internal state.
    They move under reformulations that change no physics, and an
    instrument that cries at every refactoring is read less each time.
    Ratified at the minimal form (Phase 31, Andrea).

    The physical discriminant
    -------------------------
    Two further keys, declared and counted separately from the
    nineteen, record an **inequality between two keys** rather than a
    value to be trusted:

    .. math::

        \varphi(\text{topping}) > \varphi(\text{base})

    The young topping must creep more than the mature precast.  A
    reformulation can move both coefficients and keep this true; only a
    real inversion of the age dependence flips it, and a boolean has no
    precision to hide behind.

    Parameters
    ----------
    rec : Recorder
    """
    pre = "c5"
    try:
        from gensec.io_yaml import _parse_losses_models
        from gensec.solver.timeline import ConstructionTimeline
        (section, raw_models, zone_rheology,
         history, demand_db) = _c5_section()
        models = _parse_losses_models(raw_models)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail(f"{pre}.build", exc)
        return

    try:
        tl = ConstructionTimeline.from_block(
            history, losses_models=models, zone_rheology=zone_rheology,
            code="ec2")
        res = tl.resolve(section, demand_db)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail(f"{pre}.resolve", exc)
        return

    zone_names = list(section.zone_names)
    events = sorted(res.losses_trace)
    #: The interval count is pinned first: a history that silently stops
    #: producing losses would otherwise show up as absent keys, and an
    #: absent key is easier to overlook than a moved number.
    rec.put(f"{pre}.n_intervals", int(len(events)))

    for ordinal, ev_index in enumerate(events, start=1):
        trace = res.losses_trace[ev_index]
        if not trace:
            rec.put(f"{pre}.i{ordinal}.empty", True)
            continue
        step = trace[-1]
        p = f"{pre}.i{ordinal}"
        for tname in sorted(step.d_sigma_p):
            dsp = float(step.d_sigma_p[tname])
            rec.put(f"{p}.d_sigma_p[{tname}]", dsp)
            rec.put(f"{p}.d_sigma_pr[{tname}]",
                    float(step.d_sigma_pr.get(tname, float("nan"))))
            #: Derived here and nowhere else; sigma_p0 is the interval's
            #: own start value, read from the record rather than
            #: reconstructed from an earlier interval's end.
            s0 = float(step.sigma_p0.get(tname, float("nan")))
            rec.put(f"{p}.loss_fraction[{tname}]",
                    (-dsp / s0) if s0 else "no sigma_p0")
        phis = {}
        for z_index in sorted(step.phi):
            zi = int(z_index)
            zname = (zone_names[zi] if zi < len(zone_names)
                     else f"zone[{zi}]")
            phi_v = float(step.phi[z_index])
            phis[zname] = phi_v
            rec.put(f"{p}.phi[{zname}]", phi_v)
            rec.put(f"{p}.chi[{zname}]",
                    float(step.chi.get(z_index, float("nan"))))
        #: The inequality, not the values.  Recorded only where both
        #: zones are present -- inventing it on the precast-only
        #: interval would be a field filled for completeness, which is
        #: what produced F6.
        if "base" in phis and "topping" in phis:
            rec.put(f"{p}.phi_topping_gt_base",
                    bool(phis["topping"] > phis["base"]))


def _mz_section():
    r"""
    The two-zone bench section: C45 base, C30 topping.

    Returns
    -------
    tuple
        ``(section, x_ref, y_ref)``.
    """
    from shapely.geometry import Polygon as _Poly

    from gensec.geometry.fiber import RebarLayer, Tendon
    from gensec.geometry.geometry import GenericSection
    from gensec.materials.concrete import Concrete
    from gensec.materials.steel import PrestressingSteel, Steel

    base = Concrete(fck=_MZ_FCK_BASE, gamma_c=1.5,
                    long_term_reduction_factor=0.85)
    base.name = "C45"
    topping = Concrete(fck=_MZ_FCK_TOP, gamma_c=1.5,
                       long_term_reduction_factor=0.85)
    topping.name = "C30"
    st = Steel(fyk=450.0)
    st.name = "B450C"
    ps = PrestressingSteel(f_p01d=1391.3, Ep=_DEC_EP)
    ps.name = "Y1860"
    poly = _Poly([(0.0, 0.0), (_MZ_B, 0.0), (_MZ_B, _MZ_H), (0.0, _MZ_H)])
    top = _Poly([(0.0, _MZ_H - _MZ_HT), (_MZ_B, _MZ_H - _MZ_HT),
                 (_MZ_B, _MZ_H), (0.0, _MZ_H)])
    xr, yr = _MZ_B / 2.0, _MZ_H / 2.0
    reb = [RebarLayer(y=50.0, As=_MZ_AS, material=st, x=xr),
           RebarLayer(y=_MZ_H - 50.0, As=_MZ_AS, material=st, x=xr)]
    ten = [Tendon(y=100.0, Ap=_MZ_AP, material=ps, x=xr,
                  eps_pe=_MZ_EPS_PE, name="T1")]
    section = GenericSection(poly, base, reb, tendons=ten,
                             bulk_materials=[(top, topping, "topping")],
                             n_grid_y=60)
    return section, xr, yr


def _check_zones(rec: Recorder) -> None:
    r"""
    Probe whether the check block reads a limit **per zone**.

    Why this probe exists
    ---------------------
    The four ``checks.*`` benches beside it are all **single-zone**:
    ``_dec_section`` returns ``zone_names == ['base']``.  The five
    multi-zone examples in ``examples/`` never enter a check probe at
    all.  So the instrument could not see a per-zone limit land, and
    both candidate designs for that repair were measured at **zero new
    keys** (``30_2`` §2) -- not because they change nothing, but because
    nothing was watching.  INERT after a repair that ought to move
    values is silence, not proof, so the bench comes first and the
    repair second (``30_2`` §7, ratified).

    What the defect is
    ------------------
    :class:`~gensec.materials.verification_limits.StressLimits`\
    ``.sigma_c_comp`` **was** one number for the whole stage, compared
    against the largest compression anywhere in the section.  Phase 32
    deleted it and derives per zone instead; this bench is the eye that
    watched the repair land, and its docstring keeps the defect on
    record because a bench whose subject is forgotten is a bench nobody
    can read.  On a composite the zones have different concrete and
    therefore different :math:`f_{ck}`:

    .. math::

        \sigma_{\lim}(\text{zone}) = k_1\, f_{ck}(\text{zone}),
        \qquad
        k_1 f_{ck}^{\,\mathrm{base}} = 27.0,
        \quad
        k_1 f_{ck}^{\,\mathrm{top}} = 18.0 \ \text{MPa}

    -- a single figure is wrong by 50 % on one of the two, and wrong in
    the unsafe direction on whichever zone is weaker.

    What makes this bench discriminating
    ------------------------------------
    Recording two different numbers would not be enough: a reader could
    take the difference for a modelling choice.  The working point is
    chosen so that the two limits give **opposite verdicts** on the same
    stress.  At :math:`M_x = -350` kNm the topping reaches 22.5753 MPa,
    which *passes* the section-wide 27.0 and *fails* its own 18.0.  So
    ``verdict`` and ``stage_verified`` are booleans that must flip, and a
    boolean carries no precision to hide behind.

    What is recorded
    ----------------
    ``zones``, ``fck[...]``, ``sigma_min[...]``
        The inputs and the physics, pinned so that a later edit to the
        bench section shows up as a movement rather than as a silent
        change of subject.
    ``n``, ``names``, ``concrete_checks``
        What the block emitted.  ``concrete_checks`` is 1 today and must
        become 2 -- one per zone.
    ``limits_applied``, ``n_distinct_limits``
        The thresholds the records actually carry.  One distinct value
        today; two after the repair.
    ``zones_named``
        The zone labels appearing in the bracketed part of a concrete
        check name, following the per-element convention already in use
        (``decompression[tendon 0]``).  ``-`` today.
    ``zones_without_record``
        Zones present in the stage for which the block emitted neither a
        check nor a ``skipped`` entry.  Both of them today.  This is the
        measurable form of the obligation that **every branch leaves a
        record**, on the new axis, before it can be violated.
    ``error_MPa``, ``error_pct``
        The size of the defect: the gap between the threshold applied to
        the weaker zone and the one its own material prescribes.  The
        coefficient is read from
        :data:`~gensec.materials.verification_limits.EC2_RECOMMENDED`,
        never written here -- a constant copied beside an instrument is
        a constant the instrument can no longer detect.
    ``verdict``, ``stage_verified``
        The two booleans that must flip.

    Parameters
    ----------
    rec : Recorder
    """
    try:
        from gensec.materials.verification_limits import (
            EC2_RECOMMENDED, StressLimits)
        from gensec.solver.section_state import SectionState
        from gensec.solver.sls import verify_sls_staged
        section, xr, yr = _mz_section()
        law_base = _phase30_service_law(_MZ_FCK_BASE)
        law_top = _phase30_service_law(_MZ_FCK_TOP)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail("checks.multizone.build", exc)
        return

    pre = "checks.multizone"
    k1 = float(EC2_RECOMMENDED["k1"])
    #: One section-wide threshold, built from the **stronger** zone.
    #: This is the state of the tree, not a strawman: there is no other
    #: Since Phase 32 there is no section-wide threshold at all: the
    #: coefficient is declared once and each zone supplies its own
    #: strength.  The keys below are what recorded that landing.
    limits = StressLimits(name="mz", k_c=k1,
                          sigma_s_tens=0.8 * 450.0,
                          sigma_p_max=0.75 * 1860.0)
    state = SectionState(0, np.ones(3, dtype=bool), np.ones(3, dtype=bool),
                         np.array([0.0, 0.0, _MZ_EPS_PE], dtype=float),
                         bulk_eps_init=0.0, label="mz")
    stages = [{"name": "mz", "state": state,
               "increment": (0.0, _MZ_MX, 0.0), "limits": limits}]
    try:
        res = verify_sls_staged(section, stages,
                                moduli={"C45": law_base, "C30": law_top},
                                x_ref=xr, y_ref=yr)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail(f"{pre}.run", exc)
        return

    stage = res["stages"][0]
    by_zone = stage["concrete"].get("by_zone") or {}
    zone_names = list(section.zone_names)
    rec.put(f"{pre}.zones", ",".join(zone_names))
    #: The zone's own characteristic strength, read from its material.
    fck_of = {}
    mats = [section.bulk_material] + [m for (_p, m)
                                      in (section.bulk_materials or [])]
    for z, zname in enumerate(zone_names):
        fck = float(getattr(mats[z], "fck", float("nan")))
        fck_of[zname] = fck
        rec.put(f"{pre}.fck[{zname}]", fck)
        zz = by_zone.get(zname)
        rec.put(f"{pre}.sigma_min[{zname}]",
                float(zz["sigma_min_MPa"]) if zz else "absent")

    checks = stage.get("checks", []) or []
    bare = sorted({c.get("name", "?").split("[")[0] for c in checks})
    rec.put(f"{pre}.n", int(len(checks)))
    rec.put(f"{pre}.names", ",".join(bare) if bare else "-")

    conc = [c for c in checks
            if c.get("name", "").split("[")[0] == "concrete_compression"]
    rec.put(f"{pre}.concrete_checks", int(len(conc)))
    lims = sorted({round(float(c["limit_MPa"]), 9)
                   for c in conc if "limit_MPa" in c})
    rec.put(f"{pre}.limits_applied",
            ",".join(f"{v:.6f}" for v in lims) if lims else "-")
    rec.put(f"{pre}.n_distinct_limits", int(len(lims)))

    named = sorted({c["name"].split("[", 1)[1].rstrip("]")
                    for c in conc if "[" in c.get("name", "")})
    rec.put(f"{pre}.zones_named", ",".join(named) if named else "-")

    #: A zone owes a record: a check, or a ``skipped`` entry naming it.
    recorded = set(named)
    for c in checks:
        if c.get("skipped") and "[" in c.get("name", ""):
            recorded.add(c["name"].split("[", 1)[1].rstrip("]"))
    missing = [z for z in zone_names if z not in recorded]
    rec.put(f"{pre}.zones_without_record",
            ",".join(missing) if missing else "-")

    #: The size of the defect, on the zone the single limit treats worst.
    weakest = min(zone_names, key=lambda z: fck_of[z])
    own = k1 * fck_of[weakest]
    applied = None
    for c in conc:
        nm = c.get("name", "")
        if nm == "concrete_compression" or nm.endswith(f"[{weakest}]"):
            applied = float(c["limit_MPa"])
            if nm != "concrete_compression":
                break
    if applied is None:
        rec.put(f"{pre}.error_MPa", "absent")
        rec.put(f"{pre}.error_pct", "absent")
        rec.put(f"{pre}.verdict[{weakest}]", "absent")
    else:
        rec.put(f"{pre}.error_MPa", float(applied - own))
        rec.put(f"{pre}.error_pct", float(100.0 * (applied - own) / own))
        for c in conc:
            nm = c.get("name", "")
            if nm == "concrete_compression" or nm.endswith(f"[{weakest}]"):
                rec.put(f"{pre}.verdict[{weakest}]", bool(c["passed"]))
                if nm != "concrete_compression":
                    break
    rec.put(f"{pre}.stage_verified", bool(stage.get("verified")))


def _check_silences(rec: Recorder) -> None:
    r"""
    Probe which limits the check block **names**, and which it drops.

    Why this probe exists
    ---------------------
    A check that cannot run must say so.  In the staged SLS block one
    absence is declared and the others are not: when a stage carries no
    bonded tendon, ``decompression`` emits a ``skipped`` record that
    names itself, while ``tendon_stress`` simply is not appended --
    guarded by ``if ten_present.any():`` with no ``else``.  The same
    shape guards ``steel_tension`` against a stage with no reinforcing
    bar.  A reader diffing two records sees a check disappear and cannot
    tell "not applicable" from "not run".

    Before this probe the instrument was blind to it.  Measured on the
    pristine tree: of 5877 numeric keys, **zero** mention ``skipped``,
    and none enumerates the emitted check names.

    What is recorded, per configuration
    -----------------------------------
    ``n``
        Number of check records emitted.
    ``names``
        The emitted names, sorted and comma-joined, with any bracketed
        index or label stripped so the key does not move when an element
        is renumbered.
    ``skipped``
        The subset of those names carrying ``skipped``.  ``-`` when
        none do; never an absent key, because a vanishing key is not a
        movement.
    ``unnamed_limits``
        The fields of :class:`~gensec.materials.verification_limits.\
StressLimits` that are **declared** on this run and that no emitted
        check names, sorted and comma-joined.  This is the measurable
        form of the closure gate: on a tree with no undeclared silence
        it is ``-`` for every configuration.

    The ``_check_entry`` records
    ----------------------------
    Three further keys measure the record-versus-verdict disagreement at
    a limit boundary.  ``_check_entry`` rounds ``value_MPa`` and ``eta``
    to six decimals but takes ``passed`` from the unrounded comparison,
    so there is a band in which the record reads as an exact pass and
    the verdict is a fail.  The two roundings have **different** bands:
    the one on the value is a constant :math:`5\cdot 10^{-7}` MPa, while
    the one on :math:`\eta = v/\ell` is :math:`5\cdot 10^{-7}\,\ell` and
    therefore scales with the limit -- measured at
    :math:`9.449\cdot 10^{-4}` MPa on :math:`\ell = 1860`, which is
    1833 times the band on the value.

    ``entry.zero_limit`` records what a zero limit raises.  It is
    recorded as a latent property, not a live failure: all four call
    sites take their limit from a ``StressLimits`` field, and
    ``StressLimits.__post_init__`` already refuses a non-positive
    threshold, so no public path reaches the division with zero.

    Parameters
    ----------
    rec : Recorder
    """
    import dataclasses as _dc

    try:
        from gensec.materials.verification_limits import StressLimits
        from gensec.solver.section_state import SectionState
        from gensec.solver.sls import _check_entry, verify_sls_staged
        section, xr, yr = _dec_section()
        law = _phase30_service_law(35.0)
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.fail("checks.build", exc)
        return

    #: Every threshold declared, so that a limit the block never names
    #: shows up as a silence rather than as an undeclared input.
    limits = StressLimits(name="p30", k_c=0.6,
                          sigma_s_tens=0.8 * 450.0,
                          sigma_p_max=0.75 * 1860.0,
                          decompression=True, c_dec=_DEC_CDEC)
    #: Which check name answers which declared field.  ``name`` is an
    #: identifier and ``c_dec`` a parameter of the decompression probe,
    #: so neither is a threshold owing a check.
    answered_by = {"k_c": "concrete_compression",
                   "custom_zone_strengths": "concrete_compression",
                   "sigma_s_tens": "steel_tension",
                   "sigma_p_max": "tendon_stress",
                   "decompression": "decompression"}
    not_a_threshold = ("name", "c_dec")

    for tag, active, bonded in _SILENCE_CONFIGS:
        pre = f"checks.{tag}"
        state = SectionState(0, np.asarray(active, dtype=bool),
                             np.asarray(bonded, dtype=bool),
                             np.array([0.0, 0.0, _DEC_EPS_PE],
                                      dtype=float),
                             bulk_eps_init=0.0, label=tag)
        stages = [{"name": tag, "state": state,
                   "increment": (0.0, -90.0e6, 0.0), "limits": limits}]
        try:
            res = verify_sls_staged(section, stages,
                                    moduli={"C35": law},
                                    x_ref=xr, y_ref=yr)
        except Exception as exc:            # noqa: BLE001 -- failure is data
            rec.fail(f"{pre}.run", exc)
            continue
        checks = res["stages"][0].get("checks", []) or []
        bare = sorted({c.get("name", "?").split("[")[0] for c in checks})
        skipped = sorted({c.get("name", "?").split("[")[0]
                          for c in checks if c.get("skipped")})
        rec.put(f"{pre}.n", int(len(checks)))
        rec.put(f"{pre}.names", ",".join(bare) if bare else "-")
        rec.put(f"{pre}.skipped", ",".join(skipped) if skipped else "-")
        unnamed = []
        for field in _dc.fields(StressLimits):
            fn = field.name
            if fn in not_a_threshold:
                continue
            value = getattr(limits, fn)
            if value is None or value is False:
                continue
            if answered_by.get(fn) not in bare:
                unnamed.append(fn)
        rec.put(f"{pre}.unnamed_limits",
                ",".join(sorted(unnamed)) if unnamed else "-")

    # --- _check_entry: the record against its own verdict -------------
    try:
        _check_entry("probe", 5.0, 0.0)
        rec.put("entry.zero_limit", "no exception")
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.put("entry.zero_limit", type(exc).__name__)
    try:
        neg = _check_entry("probe", 5.0, -1.0)
        rec.put("entry.neg_limit", "no exception")
        rec.put("entry.neg_limit.eta", float(neg["eta"]))
    except Exception as exc:                # noqa: BLE001 -- failure is data
        rec.put("entry.neg_limit", type(exc).__name__)
        rec.put("entry.neg_limit.eta", "absent")
    for tag, value, limit in (("small", 21.0000004, 21.0),
                              ("large", 1860.0009, 1860.0)):
        try:
            r = _check_entry("probe", value, limit)
        except Exception as exc:            # noqa: BLE001 -- failure is data
            rec.fail(f"entry.boundary.{tag}", exc)
            continue
        rec.put(f"entry.boundary.{tag}.value", float(r["value_MPa"]))
        rec.put(f"entry.boundary.{tag}.limit", float(r["limit_MPa"]))
        rec.put(f"entry.boundary.{tag}.eta", float(r["eta"]))
        rec.put(f"entry.boundary.{tag}.passed", bool(r["passed"]))
        # The record agrees with its verdict only if the published
        # numbers reproduce it.  This key is the discriminator.
        rec.put(f"entry.boundary.{tag}.record_reproduces_verdict",
                bool((float(r["value_MPa"]) <= float(r["limit_MPa"]))
                     == bool(r["passed"])))
        # eta carries the wider of the two bands -- 5e-07 * limit
        # against a constant 5e-07 on the value -- so it disagrees with
        # the verdict over a range that grows with the limit.  Both
        # keys are recorded: on the pristine tree the value key is
        # false at ell = 21 and true at ell = 1860, while this one is
        # false at both, which is the band ratio made visible.
        rec.put(f"entry.boundary.{tag}.eta_reproduces_verdict",
                bool((float(r["eta"]) <= 1.0) == bool(r["passed"])))

# ==================================================================
#  Phase 33 bench: the YAML document -> SLS verdict path
# ==================================================================


def _yaml_sls_doc(sls_block, *, second_combination=True):
    r"""
    Build the synthetic two-zone document this bench measures.

    Synthetic and **not** a distributed example, for the reason
    ``32_0`` §7 records: an example belongs to whoever will edit it,
    and a bench that reads one moves when that file moves, for reasons
    that are not the thing under measurement.  The shape is modelled on
    ``example_composite_timeline.yaml`` -- a 600x1400 precast web with a
    200 mm topping cast on top -- but every number is written here.

    Parameters
    ----------
    sls_block : dict or None
        The ``sls`` block placed on the first combination.  ``None``
        omits it, which is the case that must produce an explicit
        record of absence rather than silence.
    second_combination : bool, optional
        Whether to append a second combination carrying **no** ``sls``
        block.  Default ``True``: a document in which one combination
        asks for a stress verification and another does not is the
        ordinary case, and the two records must be distinguishable.

    Returns
    -------
    dict
        The document, ready for ``yaml.safe_dump``.
    """
    combo = {
        "name": "SLS_char",
        "at": "service",
        "history_factors": {"G1": 1.0, "G2": 1.0},
        "components": [{"ref": "Q", "factor": 1.0}],
    }
    if sls_block is not None:
        combo["sls"] = sls_block
    combos = [combo]
    if second_combination:
        combos.append({
            "name": "ULS_composite",
            "at": "service",
            "history_factors": {"G1": 1.35, "G2": 1.35},
            "components": [{"ref": "Q", "factor": 1.5}],
        })
    return {
        "code": "ec2",
        "schema_version": 1,
        "materials": {
            "c_precast": {"type": "concrete", "fck": 45.0,
                          "gamma_c": 1.5,
                          "long_term_reduction_factor": 0.85},
            "c_topping": {"type": "concrete", "fck": 30.0,
                          "gamma_c": 1.5,
                          "long_term_reduction_factor": 0.85},
            "steel": {"type": "steel", "fyk": 450.0, "gamma_s": 1.15},
        },
        "section": {
            "shape": "rect",
            "params": {"B": 600, "H": 1400},
            "bulk_material": "c_precast",
            "mesh_size": 50,
            "material_zones": [{
                "shape": "custom", "name": "topping",
                "material": "c_topping",
                "params": {"exterior": [[0, 1200], [600, 1200],
                                        [600, 1400], [0, 1400]]},
            }],
            "rebars": [
                {"name": "A1", "x": 60, "y": 60, "diameter": 26,
                 "material": "steel"},
                {"name": "A2", "x": 540, "y": 60, "diameter": 26,
                 "material": "steel"},
                {"name": "T1", "x": 60, "y": 1340, "diameter": 16,
                 "material": "steel"},
                {"name": "T2", "x": 540, "y": 1340, "diameter": 16,
                 "material": "steel"},
            ],
        },
        "losses_models": {
            "rheo_precast": {"provider": "ec2", "fck": 45.0,
                             "cement_class": "N", "RH": 70.0},
            "rheo_topping": {"provider": "ec2", "fck": 30.0,
                             "cement_class": "N", "RH": 70.0},
        },
        "zone_rheology": {
            "base": {"model": "rheo_precast", "age": 28, "curing": 3},
            "topping": {"model": "rheo_topping", "age": 0, "curing": 3},
        },
        "demands": [
            {"name": "G1", "N_kN": -300, "Mx_kNm": -220},
            {"name": "G2", "Mx_kNm": -180},
            {"name": "Q", "Mx_kNm": -260},
        ],
        "construction_history": [
            {"load": {"demand": "G1"}},
            {"cast": {"zone": "topping", "datum": "auto"}},
            {"point": "transfer"},
            {"load": {"demand": "G2"}},
            {"point": "service"},
        ],
        "combinations": combos,
        "output": {"verification_top_k": 10},
    }


#: The moduli the bench declares.  Written here, not derived: an SLS
#: modulus is a normative, time-dependent choice and GenSec never
#: derives one (Phase-7 D3).  The two differ because the topping is
#: the younger and weaker concrete, and a bench in which they were
#: equal could not tell a per-zone resolution from a section-wide one.
_YSLS_MODULI = {"base": 36000.0, "topping": 31000.0}


def _yaml_sls_case(rec: Recorder, tag: str, sls_block,
                   *, second_combination=True) -> None:
    r"""
    Run one document through load -> SLS and record what came out.

    Two families of key, and the split is the point of the bench.

    ``<tag>.load`` / ``<tag>.block_carried``
        The **reachability** family, and the only one that carries
        information on both sides of this phase.  Before Phase 33 an
        ``sls`` block on a combination loads and is dropped: the
        document is accepted, the run completes, and no stress check
        is ever evaluated.  ``block_carried = false`` beside
        ``load = ok`` *is* that silence, written down as a number.
    ``<tag>.n_records`` and below
        The **verdict** family.  Absent before the surface exists;
        this is the addition the phase is measured by.

    Parameters
    ----------
    rec : Recorder
    tag : str
        Key prefix, e.g. ``"yaml_sls.full"``.
    sls_block : dict or None
        Placed on the first combination; ``None`` omits it.
    second_combination : bool, optional
        Passed to :func:`_yaml_sls_doc`.
    """
    import tempfile

    import yaml as _yaml

    doc = _yaml_sls_doc(sls_block, second_combination=second_combination)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "bench.yaml")
        with open(path, "w", encoding="utf-8") as fh:
            _yaml.safe_dump(doc, fh, sort_keys=False)

        from gensec.io_yaml import load_yaml
        try:
            data = load_yaml(path)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{tag}.load", exc)
            return
        rec.put(f"{tag}.load", "ok")

        first = data.get("combinations", [{}])[0]
        rec.put(f"{tag}.block_carried",
                bool("sls" in first or "_sls_spec" in first))

        try:
            from gensec.solver.timeline_run import run_sls
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{tag}.run", exc)
            return
        try:
            out = run_sls(data, n_points=12)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(f"{tag}.run", exc)
            return
        rec.put(f"{tag}.run", "ok")
        _yaml_sls_record(rec, tag, out)


def _yaml_sls_record(rec: Recorder, tag: str, out: dict) -> None:
    r"""
    Write the per-combination SLS outcome into the fingerprint.

    Records the **skipped** record explicitly.  A combination that
    declares no ``sls`` block must leave a record saying so; a bench
    that only counted verdicts would read that absence and the absence
    of the whole engine as the same thing, which is the very confusion
    this phase removes.

    Parameters
    ----------
    rec : Recorder
    tag : str
    out : dict
        Output of :func:`gensec.solver.timeline_run.run_sls`.
    """
    combos = out.get("combinations", [])
    rec.put(f"{tag}.n_combinations", int(len(combos)))
    skipped = sorted(c["name"] for c in combos if c.get("skipped"))
    rec.put(f"{tag}.skipped", ",".join(skipped) if skipped else "-")
    for c in combos:
        if c.get("skipped"):
            rec.put(f"{tag}.reason[{c['name']}]",
                    "named" if "sls" in str(c.get("reason", "")) else "vague")
            continue
        name = c["name"]
        points = c.get("points", {})
        rec.put(f"{tag}.n_points[{name}]", int(len(points)))
        for pname in sorted(points):
            res = points[pname]
            stages = res.get("stages", [])
            rec.put(f"{tag}.n_stages[{name}@{pname}]", int(len(stages)))
            last = stages[-1] if stages else {}
            checks = last.get("checks", []) or []
            # Stem comparison, never equality: a per-zone record is
            # ``concrete_compression[<zone>]`` and a probe that asked
            # for the bare name would report ``absent`` for a check
            # that ran (E32-2).
            conc = [k for k in checks
                    if k.get("name", "").split("[")[0]
                    == "concrete_compression"]
            rec.put(f"{tag}.n_records[{name}@{pname}]", int(len(checks)))
            rec.put(f"{tag}.concrete_checks[{name}@{pname}]",
                    int(len(conc)))
            lims = sorted({round(float(k["limit_MPa"]), 9)
                           for k in conc if "limit_MPa" in k})
            rec.put(f"{tag}.limits_applied[{name}@{pname}]",
                    ",".join(f"{v:.6f}" for v in lims) if lims else "-")
            for k in conc:
                zone = (k["name"].split("[", 1)[1].rstrip("]")
                        if "[" in k["name"] else "-")
                rec.put(f"{tag}.provenance[{zone}]",
                        str(k.get("provenance", "absent")))
                if "f_ck_MPa" in k:
                    rec.put(f"{tag}.f_ck[{zone}]", float(k["f_ck_MPa"]))
                rec.put(f"{tag}.verdict[{zone}]",
                        bool(k["passed"]) if "passed" in k
                        else "skipped")
            rec.put(f"{tag}.verified[{name}@{pname}]",
                    bool(res.get("verified")))


def _yaml_sls_refusal(rec: Recorder, tag: str, sls_block) -> None:
    r"""
    Record what a malformed ``sls`` block is answered with.

    A refusal is a physical quantity of this instrument in the sense
    that matters: it is the observable a phase changes when it turns a
    silent acceptance into a named error, and ``Recorder.fail``
    already stores the exception type and message as the value.  On the
    tree before this phase every case here records ``ok`` -- the block
    loads and nothing happens -- which is precisely the defect.

    Parameters
    ----------
    rec : Recorder
    tag : str
    sls_block : dict
        A block that must be refused.
    """
    import tempfile

    import yaml as _yaml

    doc = _yaml_sls_doc(sls_block)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "bench.yaml")
        with open(path, "w", encoding="utf-8") as fh:
            _yaml.safe_dump(doc, fh, sort_keys=False)
        from gensec.io_yaml import load_yaml
        try:
            load_yaml(path)
        except Exception as exc:            # noqa: BLE001 — failure is data
            rec.fail(tag, exc)
            return
        rec.put(tag, "accepted")


def _yaml_sls_surface(rec: Recorder) -> None:
    r"""
    The document-to-verdict bench (Phase 33).

    Why this bench exists
    ---------------------
    Before Phase 33 **no key in this fingerprint saw an SLS result
    produced from a YAML document**, because none could: the staged SLS
    engine was reachable only from the Python API.  ``grep -c 'sls'``
    on ``cli.py`` and on ``io_yaml.py`` returned ``0`` and ``0``, and
    ``print_sls_results`` had zero callers anywhere in the tree.  A
    user writing YAML received a ULS domain check and **no stress
    check at all**, and nothing said so.

    That is not a wrong number.  It is the answer to a different
    question, delivered in silence -- the same species as the false
    pass Phase 32 closed one level down, and a change detector that
    cannot see it would report green through a phase that broke the
    whole surface.

    What is recorded, and why exactly these
    ---------------------------------------
    Four cases, chosen so that each isolates one decision:

    ``full``
        A block naming ``moduli`` and ``limits``.  Records the number
        of records per stage, the distinct limits applied, and the
        per-zone ``provenance`` and verdict.  Two zones with two
        different strengths, so a section-wide limit would show as one
        entry in ``limits_applied`` instead of two.
    ``nolimits``
        No ``sls`` block at all.  Records that the combination leaves
        an explicit ``skipped`` record naming the lever, not silence.
        The distinction between *absent* and *silent* is the whole
        point of the constraint that puts it here.
    ``custom``
        ``custom_zone_strengths`` declared for one zone.  Records
        ``provenance`` per zone: ``custom`` where the caller declared
        the strength, ``material`` where GenSec derived it.  The two
        are different assertions and the report must keep them apart.
    ``refuse.*``
        Four malformed blocks, each recording the refusal it draws:
        an unknown field, a missing ``kind``, ``kind='transfer'``
        without declared strengths, and a code with no stress-limit
        provider.

    The zone strengths are C45 and C30, so the two limits are
    ``0.6 x 45 = 27`` and ``0.6 x 30 = 18`` MPa.  A resolution that
    collapsed to one limit would move ``limits_applied`` from two
    entries to one, which is a set difference and not a rounding.

    Parameters
    ----------
    rec : Recorder
    """
    base_limits = {"kind": "characteristic", "fyk": 450.0, "fpk": 1860.0}
    _yaml_sls_case(rec, "yaml_sls.full",
                   {"moduli": dict(_YSLS_MODULI),
                    "limits": dict(base_limits)})
    _yaml_sls_case(rec, "yaml_sls.nolimits", None)
    _yaml_sls_case(rec, "yaml_sls.custom",
                   {"moduli": dict(_YSLS_MODULI),
                    "limits": {**base_limits,
                               "custom_zone_strengths":
                                   {"topping": {"f_ck": 22.0}}}})
    _yaml_sls_refusal(rec, "yaml_sls.refuse.unknown_field",
                      {"moduli": dict(_YSLS_MODULI),
                       "limits": {**base_limits, "f_ckk": 30.0}})
    _yaml_sls_refusal(rec, "yaml_sls.refuse.no_kind",
                      {"moduli": dict(_YSLS_MODULI),
                       "limits": {"fyk": 450.0}})
    _yaml_sls_refusal(rec, "yaml_sls.refuse.transfer_bare",
                      {"moduli": dict(_YSLS_MODULI),
                       "limits": {"kind": "transfer"}})
    _yaml_sls_refusal(rec, "yaml_sls.refuse.unknown_code",
                      {"moduli": dict(_YSLS_MODULI),
                       "limits": {**base_limits, "code": "aci318-19"}})
    rec.put("yaml_sls.n_cases", 7)


# ==================================================================
#  Phase 36 bench: what print_sls_results RENDERS
# ==================================================================


def _sls_report_render(rec: Recorder) -> None:
    r"""
    Hold the rendered SLS table, not the dict behind it.

    Why this bench exists
    ---------------------
    ``print_sls_results`` gained a caller in Phase 33 (``cli.py``, the
    ``run`` verb) and a fixture pinning that it is reachable.  That
    closed Z-12's first half.  The second half stayed open until the
    Phase-36 observation inventory measured it: **no key of any of the
    three captures watched what the function prints**.  The verdict
    dict is observed six ways over; its rendering was observed by
    nothing, so a table that started reporting the wrong column, or
    formatting :math:`\eta` from the wrong field, would have moved no
    number anywhere.

    That is the species of ``35_0`` §4 waiting to happen -- an output
    that declares one thing and carries another -- and it is E34-1's
    shape exactly: not a wrong answer, but no observer.

    What is recorded
    ----------------
    The report is captured as text and read back.  The keys hold the
    numbers **as printed**, parsed out of the lines they were printed
    on, together with the shape of the table:

    ``report.n_lines``, ``report.n_stage_blocks``, ``report.n_checks``
        The shape.  A stage or a check silently dropped from the
        rendering moves one of these even if every value is right.
    ``report.sigma_min``, ``report.sigma_max``
        Read back from the ``concrete:`` line of the last stage.
    ``report.eta[<check>]``
        One key per check that carries an :math:`\eta`.  A renderer
        dividing by the wrong quantity moves these and nothing else.
    ``report.verified``, ``report.governing``
        The two summary lines, verbatim after the label.

    Deliberately **not** recorded: column widths and rule characters.
    They are formatting, they change for reasons that are not physics,
    and a fingerprint that fought over them would be one nobody could
    move.

    Parameters
    ----------
    rec : Recorder
    """
    import contextlib
    import io as _io
    import re
    import tempfile

    import yaml as _yaml

    tag = "report"
    # The same block the yaml_sls bench's 'full' case uses, so that a
    # move here and a move there have one common cause to look at.
    doc = _yaml_sls_doc({"moduli": dict(_YSLS_MODULI),
                         "limits": {"kind": "characteristic",
                                    "fyk": 450.0, "fpk": 1860.0}},
                        second_combination=False)
    buf = _io.StringIO()
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "render.yaml")
        with open(path, "w", encoding="utf-8") as fh:
            _yaml.safe_dump(doc, fh, sort_keys=False)
        try:
            from gensec.io_yaml import load_yaml
            from gensec.output.report import print_sls_results
            from gensec.solver.timeline_run import run_sls
            data = load_yaml(path)
            out = run_sls(data, n_points=12)
        except Exception as exc:            # noqa: BLE001 -- failure is data
            rec.fail(f"{tag}.setup", exc)
            return

        combos = [c for c in out.get("combinations", [])
                  if not c.get("skipped")]
        if not combos or not combos[0].get("points"):
            rec.put(f"{tag}.setup", "no-result")
            return
        pname = sorted(combos[0]["points"])[0]
        res = combos[0]["points"][pname]

        try:
            with contextlib.redirect_stdout(buf):
                print_sls_results(res)
        except Exception as exc:            # noqa: BLE001 -- failure is data
            rec.fail(f"{tag}.render", exc)
            return
        rec.put(f"{tag}.render", "ok")

    text = buf.getvalue()
    lines = [ln for ln in text.splitlines() if ln.strip()]
    rec.put(f"{tag}.n_lines", int(len(lines)))
    rec.put(f"{tag}.n_stage_blocks",
            int(sum(1 for ln in lines if ln.startswith("Stage: "))))
    # A check name repeats across stages, so the key carries the stage
    # it was printed under.  Without it the bench would record only the
    # last stage's copy of each name and read INERT on a change in any
    # earlier one -- the failure this whole bench exists to remove.
    check_lines = []
    stage = "-"
    for ln in lines:
        if ln.startswith("Stage: "):
            stage = ln[len("Stage: "):].split(",")[0].strip()
        elif ln.lstrip().startswith("- "):
            check_lines.append((stage, ln))
    rec.put(f"{tag}.n_checks", int(len(check_lines)))

    conc = [ln for ln in lines if ln.lstrip().startswith("concrete:")]
    if conc:
        got = re.findall(r"sigma_(?:min|max)=(-?\d+\.\d+)", conc[-1])
        if len(got) == 2:
            rec.put(f"{tag}.sigma_min", float(got[0]))
            rec.put(f"{tag}.sigma_max", float(got[1]))

    for stage, ln in check_lines:
        m = re.match(r"\s*-\s+(\S+)\s+.*eta=(\d+\.\d+)", ln)
        if m:
            rec.put(f"{tag}.eta[{stage}|{m.group(1)}]",
                    float(m.group(2)))
            continue
        m = re.match(r"\s*-\s+(\S+)\s+eps_probe=(\S+)", ln)
        if m:
            rec.put(f"{tag}.eps_probe[{stage}|{m.group(1)}]",
                    float(m.group(2)))

    for ln in lines:
        if ln.startswith("VERIFIED: "):
            rec.put(f"{tag}.verified", ln.split(": ", 1)[1].strip())
        elif ln.startswith("governing: "):
            rec.put(f"{tag}.governing", ln.split(": ", 1)[1].strip())


# ==================================================================
#  Phase 34 bench: the YAML document -> retrofit path
# ==================================================================


#: Geometry and materials of the retrofit bench, written here rather
#: than read from a distributed example (``32_0`` §7).  A 400x1200
#: girder carrying one forty-year-old cable and two new ones, which is
#: the smallest section on which the effect can exist at all: with a
#: single new cable there is no second jack for the existing one to be
#: debited by.
_RF_B, _RF_H, _RF_NFY = 400.0, 1200.0, 240
_RF_AP = 1500.0
_RF_Y = (150.0, 200.0, 250.0)
#: The declared state of the existing member.  Every number is a
#: declaration, because none of them is derivable: the effective stress
#: of a cable tensioned decades ago, the strain plane its concrete is
#: already in, and the two clocks that run from different origins.
_RF_SIGMA_PE = 1100.0
_RF_EPS0, _RF_CHIX = -3.0e-4, 1.5e-7
_RF_XREF, _RF_YREF = 200.0, 600.0
_RF_AGE_C, _RF_AGE_P = 14600.0, 14200.0
_RF_SIGMA_P0 = 1300.0


def _yaml_retrofit_doc(retrofit_payload, *, extra_events=()):
    r"""
    Build the synthetic retrofit document this bench measures.

    Parameters
    ----------
    retrofit_payload : dict or None
        The payload of the ``retrofit`` event placed **first** in the
        construction history.  ``None`` omits the event entirely,
        which is the control case: the same member, analysed as if it
        were virgin.
    extra_events : sequence, optional
        Events spliced in **before** the closing ``point``, for the
        cases that must be refused (a ``stress`` of a cable the
        retrofit already declares, a second ``retrofit``).

    Returns
    -------
    dict
        The document, ready for ``yaml.safe_dump``.
    """
    history = []
    if retrofit_payload is not None:
        history.append({"retrofit": retrofit_payload})
    history.extend([
        {"stress": {"tendons": ["P_new1"], "sigma_p0": _RF_SIGMA_P0}},
        {"grout": {"tendons": ["P_new1"]}},
        {"stress": {"tendons": ["P_new2"], "sigma_p0": _RF_SIGMA_P0}},
        {"grout": {"tendons": ["P_new2"]}},
    ])
    history.extend(list(extra_events))
    history.append({"point": "service"})
    return {
        "code": "ec2",
        "materials": {
            #: Every normative parameter written out.  Phase 37
            #: removed the loader's defaults, so a bench document that
            #: omitted one would be refused at load -- which is the
            #: repair working, not a regression.
            "conc": {"type": "concrete_ec2_gen1", "fck": 40.0,
                     "ls": "F", "loadtype": "slow", "TypeConc": "R",
                     "NA": "French", "time": 28},
            "strand": {"type": "prestressing_steel_ec2",
                       "class": "Y1860S7", "ls": "F",
                       "diagram": "inclined", "NA": "EC2",
                       "eps_ud_factor": 0.9},
        },
        "section": {
            "B": _RF_B, "H": _RF_H, "bulk_material": "conc",
            "n_fibers_y": _RF_NFY,
            "tendons": [
                {"name": "P_old", "y": _RF_Y[0], "x": _RF_XREF,
                 "Ap": _RF_AP, "material": "strand", "eps_pe": 0.0,
                 "bonded": True},
                {"name": "P_new1", "y": _RF_Y[1], "x": _RF_XREF,
                 "Ap": _RF_AP, "material": "strand", "eps_pe": 0.0,
                 "bonded": True},
                {"name": "P_new2", "y": _RF_Y[2], "x": _RF_XREF,
                 "Ap": _RF_AP, "material": "strand", "eps_pe": 0.0,
                 "bonded": True},
            ],
        },
        "demands": [{"name": "Q", "Mx_kNm": -300.0}],
        "construction_history": history,
        "combinations": [{"name": "SLS_char", "at": "service",
                          "components": [{"ref": "Q", "factor": 1.0}]}],
    }


def _rf_full_payload():
    r"""
    The fully declared retrofit payload, all eight facts present.

    Returns
    -------
    dict
    """
    return {
        "tendons": {"P_old": {"sigma_pe": _RF_SIGMA_PE,
                              "age_days": _RF_AGE_P}},
        "concrete": {"eps0": _RF_EPS0, "chi_x": _RF_CHIX, "chi_y": 0.0,
                     "x_ref": _RF_XREF, "y_ref": _RF_YREF,
                     "age_days": _RF_AGE_C},
    }


def _yaml_retrofit_case(rec: Recorder, tag: str, payload,
                        *, extra_events=()) -> None:
    r"""
    Load one bench document and record what the walk makes of it.

    Two families are recorded, and the separation is the point.

    **Reachability** — ``load``, ``event_carried`` — carries
    information on *both* sides of the repair, so the PRE registers
    the silence as a number rather than as a wall of ``!ImportError``.
    On the pristine tree ``load`` records the refusal of an unknown
    event kind, which is what the surface being absent looks like from
    outside.

    **Verdict** — ``run``, ``sigma_p[...]``, ``eps_init[...]``,
    ``n_grouted`` — is absent on the PRE by construction, because
    there is no verdict to have.

    Parameters
    ----------
    rec : Recorder
    tag : str
        Key prefix for this case.
    payload : dict or None
        Passed to :func:`_yaml_retrofit_doc`.
    extra_events : sequence, optional
        Passed to :func:`_yaml_retrofit_doc`.
    """
    import tempfile
    import yaml as _yaml

    doc = _yaml_retrofit_doc(payload, extra_events=extra_events)
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "retrofit.yaml")
        with open(path, "w", encoding="utf-8") as fh:
            _yaml.safe_dump(doc, fh, sort_keys=False)

        # Every verdict key of this case, declared up front so that a
        # refusal records a TOKEN on each rather than removing the key.
        # A key that disappears reads as `only in before` in the
        # comparison, which is a different fact from `the verdict was
        # refused`, and the two must not be confused (the model is
        # `_yaml_sls_surface`).
        verdict_keys = ([f"{tag}.{k}" for k in
                         ("n_grouted", "grouted", "eta",
                          "pre_post[P_old]")]
                        + [f"{tag}.eps_init[{n}]"
                           for n in ("P_old", "P_new1", "P_new2")])

        def _refuse_verdict(token: str) -> None:
            for key in verdict_keys:
                rec.put(key, token)

        from gensec.io_yaml import load_yaml
        try:
            data = load_yaml(path)
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            rec.fail(f"{tag}.load", exc)
            rec.put(f"{tag}.event_carried", "absent")
            rec.put(f"{tag}.run", "absent")
            _refuse_verdict("refused:load")
            return
        rec.put(f"{tag}.load", "ok")

        # Does the event survive the parse at all?  A history that
        # drops the block silently and one that carries it are the two
        # sides of this repair, and this key is the discriminator.
        hist = data.get("construction_history") or []
        rec.put(f"{tag}.event_carried",
                bool(any(isinstance(e, dict) and "retrofit" in e
                         for e in hist)))

        try:
            from gensec.solver.timeline_run import run_timeline
            out = run_timeline(data)
        except BaseException as exc:        # noqa: BLE001 — outcome is data
            rec.fail(f"{tag}.run", exc)
            _refuse_verdict("refused:run")
            return
        rec.put(f"{tag}.run", "ok")

        res = out.get("resolution")
        grouted = sorted(getattr(res, "grouted", ()) or ())
        rec.put(f"{tag}.n_grouted", len(grouted))
        rec.put(f"{tag}.grouted", ",".join(grouted) if grouted else "-")
        eps = dict(getattr(res, "grout_eps_init", {}) or {})
        for name in ("P_old", "P_new1", "P_new2"):
            rec.put(f"{tag}.eps_init[{name}]",
                    float(eps[name]) if name in eps else "absent")
        pre_post = dict(getattr(res, "pre_post", {}) or {})
        rec.put(f"{tag}.pre_post[P_old]", pre_post.get("P_old", "absent"))
        anchored = out.get("anchored") or {}
        combo = anchored.get("SLS_char") or {}
        rec.put(f"{tag}.eta", float(combo["eta_governing"])
                if "eta_governing" in combo else "absent")


def _yaml_retrofit_surface(rec: Recorder) -> None:
    r"""
    The retrofit's YAML surface, measured from the document inward.

    Why this bench exists
    ---------------------
    The physics of the retrofit landed in Phase 24:
    :class:`~gensec.solver.posttension.PreexistingState` makes
    declarable the four facts GenSec cannot derive — at what stress an
    existing cable sits, how strained its concrete already is, and the
    two clocks that run from different origins.  Every field is
    required and none has a default, which is the right shape.

    No document could reach it.  Measured at the opening of Phase 34:
    ``grep -c retrofit`` returns 0 on ``io_yaml.py`` and 0 on
    ``cli.py``, ``PreexistingState`` is constructed nowhere in ``src/``
    and nowhere in ``tests/``, and the three places
    ``timeline.py`` names the retrofit are **all prose inside
    docstrings** — the case was not refused, it was inexpressible.  A
    document describing a retrofit therefore loaded, ran, and returned
    the analysis of a **virgin** section with the existing cable
    silently demoted to "not yet stressed".  Measured on this bench's
    own geometry before the repair: the existing cable appears in no
    output at all, and 1500 mm² of steel at 1100 MPa is neither a
    demand action nor a resisting element.

    The instrument had no key that saw any of that.  This bench is the
    eye, and it is added **before** the repair, so that the ``INERT``
    a wrong repair would produce cannot be mistaken for proof
    (E32-1).

    What the cases are
    ------------------
    ``yaml_retrofit.virgin``
        The same document with **no** retrofit event.  The control:
        it must load and run on both trees, and its numbers must not
        move, because nothing this phase does changes a member that
        declares no history before its first jack.
    ``yaml_retrofit.full``
        The fully declared retrofit.  On the PRE its ``load`` is the
        refusal of an unknown event kind; on the POST it is a verdict,
        with the existing cable grouted, carrying an ``eps_init``, and
        named ``post``.
    ``yaml_retrofit.refuse.*``
        The refusals that must exist and be named: a payload missing a
        required fact, an unknown field, a cable both declared
        pre-existing and stressed by the history, a retrofit that is
        not the first event, and two retrofit events.  Each records
        the refusal by type and by whether the message names the
        lever it is about -- the missing field, the unknown tendon,
        the ordinal -- because a refusal that does not name the lever
        is only a different silence.

    Parameters
    ----------
    rec : Recorder
    """
    _yaml_retrofit_case(rec, "yaml_retrofit.virgin", None)
    _yaml_retrofit_case(rec, "yaml_retrofit.full", _rf_full_payload())

    import tempfile
    import yaml as _yaml

    def _refusal(tag, payload, lever, extra_events=()):
        doc = _yaml_retrofit_doc(payload, extra_events=extra_events)
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "retrofit.yaml")
            with open(path, "w", encoding="utf-8") as fh:
                _yaml.safe_dump(doc, fh, sort_keys=False)
            from gensec.io_yaml import load_yaml
            try:
                data = load_yaml(path)
                from gensec.solver.timeline_run import run_timeline
                run_timeline(data)
            except BaseException as exc:    # noqa: BLE001 — outcome is data
                rec.put(f"yaml_retrofit.refuse.{tag}",
                        type(exc).__name__)
                # The discriminator is the LEVER, not the block name.
                # On the pristine tree every one of these cases dies on
                # the same generic "unknown event kind 'retrofit'",
                # which does name the block and would read as a
                # validated refusal.  Naming the field, the tendon or
                # the ordinal that is actually wrong is what only a
                # real validation can do.
                rec.put(f"yaml_retrofit.refuse.{tag}.names_lever",
                        bool(lever in str(exc)))
                return
            rec.put(f"yaml_retrofit.refuse.{tag}", "accepted")
            rec.put(f"yaml_retrofit.refuse.{tag}.names_lever", False)

    missing = _rf_full_payload()
    del missing["concrete"]["x_ref"]
    _refusal("missing_x_ref", missing, "x_ref")

    unknown = _rf_full_payload()
    unknown["concrete"]["eps_0"] = -3.0e-4
    _refusal("unknown_field", unknown, "eps_0")

    unknown_tendon = _rf_full_payload()
    unknown_tendon["tendons"]["P_ghost"] = {"sigma_pe": 900.0,
                                            "age_days": 100.0}
    _refusal("unknown_tendon", unknown_tendon, "P_ghost")

    both_roles = _rf_full_payload()
    both_roles["tendons"]["P_new1"] = {"sigma_pe": 900.0,
                                       "age_days": 100.0}
    _refusal("declared_and_stressed", both_roles, "P_new1")

    _refusal("second_event", _rf_full_payload(), "two 'retrofit' events",
             extra_events=({"retrofit": _rf_full_payload()},))

    _refusal("not_first", None, "must be the first entry",
             extra_events=({"retrofit": _rf_full_payload()},))


def capture(out_path: str) -> int:
    """
    Compute the fingerprint of every example and write it out.

    Parameters
    ----------
    out_path : str

    Returns
    -------
    int
        Process exit status.
    """
    rec = Recorder()
    _material_ageing(rec)
    _service_law(rec)
    # Synthetic, example-free: the service law as an object rather than
    # as an expression (D26-8).  No distributed model reaches
    # ServiceConcrete before Phase 27 wires it, so without this probe
    # the instrument is blind to the very thing this phase installs.
    _service_concrete(rec)
    # Synthetic, example-free and necessarily so: verify_sls_staged is
    # API-only (Phase 7, D5), so no distributed model reaches it.
    # Measured: 0 crossings of its two sls_view calls over a whole
    # capture, against 80 at the other four sites.
    _sls_staged(rec)
    # Phase 28, D27-1.  The probe above declares its zone with a bare
    # number, which is a straight line; the accumulation it exercises is
    # exact on straight lines and therefore invisible there.  This one
    # runs the same history on a declared ServiceConcrete beside the
    # line, so the line is the discriminator and the law is the defect.
    _sls_nonlinear(rec)
    # Phase 29.  Neither probe above carries a tendon, so neither
    # reaches the decompression record -- the one check that took its
    # verdict on one number while publishing a second that could
    # contradict it.  This one does, on the section the Phase-7
    # validators already measure.
    _decompression(rec)
    # Phase 30.  Two silences the instrument could not see.  The
    # first is the coordinate the extreme-fibre record publishes:
    # only four keys carried one before this phase, all of them the
    # y component on a rectangular section, so no non-convex zone
    # was ever measured.  The second is the check block's own roll
    # call: zero keys mentioned a skipped entry, so a check that
    # vanishes and a check that declares itself inapplicable were
    # indistinguishable to the change detector.
    _reported_coordinates(rec)
    _check_silences(rec)
    # Phase 31.  The four benches above are all single-zone, and the
    # five composite examples never reach a check probe, so a per-zone
    # limit could land without the instrument seeing it.  This bench is
    # the eye for that repair, and it is added BEFORE the repair.
    _check_zones(rec)
    # Phase 32, finding Z-3.  The whole C5 loss arc -- creep, shrinkage,
    # relaxation, the tendon loss they add up to -- had ZERO keys in
    # this fingerprint, on any bench and on any example.  Its validator
    # says pass or fail; nothing said moved by how much.  Synthetic and
    # deliberately not the distributed example: a bench that reads one
    # moves when a future phase edits it, for reasons that are not
    # rheology.
    _c5_losses(rec)
    # Phase 33.  Before this phase NO key in this fingerprint saw an
    # SLS result produced from a YAML document, because none could:
    # the staged engine was API-only, 'grep -c sls' on cli.py and
    # io_yaml.py returned 0 and 0, and print_sls_results had zero
    # callers.  A change detector blind to a whole surface reports
    # green through a phase that breaks it.  Added BEFORE the repair.
    _yaml_sls_surface(rec)
    # Phase 34, D1b-3.  The retrofit's physics has existed since Phase
    # 24 and no document could reach it: three mentions in timeline.py,
    # all of them prose in docstrings, and zero in io_yaml.py.  A
    # document describing a retrofit was answered as a virgin section.
    # Added BEFORE the repair, so its PRE records the silence as a
    # measurement.
    _yaml_retrofit_surface(rec)
    # Phase 36, closing Z-12's second half.  print_sls_results has
    # had a caller since Phase 33; until the observation inventory
    # measured it, nothing watched what it PRINTS.  Added so that
    # output/report.py stops being one of the DEBT entries of
    # tools/observation_reasons.py.
    _sls_report_render(rec)
    # Phase 37.  cli.py, 953 lines, was the second DEBT entry and the
    # first for clarity of repair: the run verb's wiring -- which
    # engines it calls and in what order -- was held by no key and by
    # no fixture.  This bench holds the wiring only; what the verb
    # PRINTS is report.* and stays there.
    _cli_run_wiring(rec)
    files = sorted(glob.glob(os.path.join(ROOT, "examples", "*.yaml")))
    print(f"examples: {len(files)}")
    for path in files:
        name = os.path.basename(path)
        try:
            _probe_example(rec, path)
            print(f"  ok    {name}")
        except Exception:                   # noqa: BLE001 — failure is data
            print(f"  ERROR {name}")
            traceback.print_exc(limit=3)
            rec.rows[f"{name}.__driver__"] = "!driver failure"
    # Synthetic, example-free: what a bare container does when
    # nothing is declared.  Runs once, not per example.
    _undeclared_container(rec)
    # Synthetic, example-free: what the driver does when a retrofit
    # is declared, and the two cases it must leave alone.
    _retrofit_declaration(rec)
    # Phase 34, finding Z-14.  AnalysisEngine is reached by exactly one
    # probe above (_decomposition_closure, at two fixed strain planes)
    # and its combination-resolution path by none: zero keys named it
    # over the whole capture.  The merge of that module's private
    # duplicate into the canonical resolver would therefore have read
    # INERT whatever it did.  Added BEFORE the repair (E32-1).
    _analysis_combination_path(rec)
    # Synthetic, example-free: the increment form of the
    # driver, on a law whose tangent varies.  No distributed
    # model reaches the driver on such a law (Phase 25 opening
    # measurement: 31 solver builds, tangent spread 0.0), so
    # without this probe the instrument is blind to D1c.
    _nonlinear_increment(rec)
    rec.dump(out_path)
    print(f"\n{len(rec.rows)} values -> {out_path}")
    return 0


def _load_fingerprint(path: str) -> Dict[str, str]:
    """
    Read a fingerprint file back into a mapping.

    Parameters
    ----------
    path : str

    Returns
    -------
    dict
    """
    rows: Dict[str, str] = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line or line.startswith("#"):
                continue
            key, _, value = line.partition(" = ")
            rows[key.strip()] = value.strip()
    return rows


def _relative_movement(a: str, b: str) -> float:
    """
    Relative movement between two recorded values.

    Parameters
    ----------
    a, b : str
        Formatted values from two fingerprint files.

    Returns
    -------
    float
        ``0.0`` when the two are identical; ``inf`` when they are not
        both numeric and not equal as text; otherwise
        :math:`|b-a| / \\max(|a|, |b|, 1)`.  The unit floor keeps a
        move from ``0`` to ``10^{-18}`` from being reported as a
        100 % change.
    """
    if a == b:
        return 0.0
    try:
        fa, fb = float(a), float(b)
    except ValueError:
        return float("inf")
    if math.isnan(fa) and math.isnan(fb):
        return 0.0
    denom = max(abs(fa), abs(fb), 1.0)
    return abs(fb - fa) / denom


def compare(before: str, after: str, rtol: float, top: int) -> int:
    """
    Compare two fingerprints and report movement.

    Parameters
    ----------
    before, after : str
        Paths to fingerprint files.
    rtol : float
        Relative movement below which a value counts as unchanged.
    top : int
        Number of largest movements to list.

    Returns
    -------
    int
        ``0`` when the key sets match and every value is within
        *rtol*, else ``1``.
    """
    a = _load_fingerprint(before)
    b = _load_fingerprint(after)

    only_a = sorted(set(a) - set(b))
    only_b = sorted(set(b) - set(a))
    shared = sorted(set(a) & set(b))

    moved: List[Tuple[float, str, str, str]] = []
    for k in shared:
        m = _relative_movement(a[k], b[k])
        if m > rtol:
            moved.append((m, k, a[k], b[k]))
    moved.sort(reverse=True, key=lambda t: t[0])

    width = 74
    print("=" * width)
    print("NUMERIC FINGERPRINT — COMPARISON")
    print(f"  before : {before}   ({len(a)} values)")
    print(f"  after  : {after}   ({len(b)} values)")
    print(f"  rtol   : {rtol:g}")
    print("=" * width)
    print(f"shared keys      : {len(shared)}")
    print(f"only in before   : {len(only_a)}")
    print(f"only in after    : {len(only_b)}")
    print(f"values moved     : {len(moved)}")

    for k in only_a[:top]:
        print(f"  - {k} = {a[k]}")
    for k in only_b[:top]:
        print(f"  + {k} = {b[k]}")

    if moved:
        print(f"\nlargest {min(top, len(moved))} movements:")
        for m, k, va, vb in moved[:top]:
            print(f"  {m:12.4e}  {k}")
            print(f"                before {va}")
            print(f"                after  {vb}")

    ok = not moved and not only_a and not only_b
    print("\n" + "-" * width)
    if ok:
        print("INERT — every recorded number is unchanged within "
              f"{rtol:g} and the key sets are identical.")
        print(f"        This is a claim WITHIN {rtol:g}, at {_SIG} "
              f"significant digits.  It is not a claim of identity:")
        print("        a value that moved by less than that is recorded "
              "here as unmoved,")
        print("        and a code path that was never taken is recorded "
              "here the same way.")
        print("        Where a phase touches the axial path, read the "
              "axial.* keys: the")
        print("        entry count and the two verdicts are integers and "
              "booleans, and")
        print("        carry no precision to hide behind (19_0 §2).")
    else:
        print("MOVED — see above.")
    print("-" * width)
    return 0 if ok else 1


def main(argv: List[str]) -> int:
    """
    Command-line entry point.

    Parameters
    ----------
    argv : list of str

    Returns
    -------
    int
    """
    if len(argv) >= 2 and argv[0] == "capture":
        return capture(argv[1])
    if len(argv) >= 3 and argv[0] == "compare":
        rtol = 1e-12
        top = 25
        if "--rtol" in argv:
            rtol = float(argv[argv.index("--rtol") + 1])
        if "--top" in argv:
            top = int(argv[argv.index("--top") + 1])
        return compare(argv[1], argv[2], rtol, top)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
# GENSEC-COMPLETE phase=37 utc=2026-09-11T05:30:51Z sha256=f1e12101bb22d32f1c31504344ad088771fa29d1beeaa79f4257a31a699e7349 body_lines=5604
