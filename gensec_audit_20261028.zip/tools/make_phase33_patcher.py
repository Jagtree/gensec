r"""
Build ``patchers/run_phase33_sls_yaml_surface.py``.

The mechanism is lifted verbatim from the Phase-30 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across four phases, and a
rewrite would put a verified thing back on trial for no gain.

Run from the repository root::

    python3 tools/make_phase33_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase32_zone_limits_and_top_level.py"
OUT = ROOT / "patchers" / "run_phase33_sls_yaml_surface.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    "src/gensec/io_yaml.py",
    "src/gensec/solver/timeline_run.py",
    "src/gensec/cli.py",
    "tests/test_phase33_sls_yaml_surface.py",
    "tests/run_phase33_patcher_falsification.py",
    "tools/numeric_fingerprint.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase33_patcher.py",
    ".fingerprints/33_00_numeric_PRE.txt",
    ".fingerprints/33_00_datum_PRE.txt",
    ".fingerprints/33_00_domain_PRE.txt",
    ".fingerprints/33_01_numeric_POST.txt",
    ".fingerprints/33_01_datum_POST.txt",
    ".fingerprints/33_01_domain_POST.txt",
    "handoff/33_0-GENSEC_LEDGER_33.md",
    "handoff/33_1-GENSEC_PHASE33_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 33 - the YAML surface of the SLS engine.

What this transports
--------------------
The staged SLS engine - cracking, per-zone compression limits,
decompression, tendon stresses - was reachable ONLY from the Python
API.  Measured on the incoming tree: grep -c 'sls' returned 0 on both
cli.py and io_yaml.py, verify_sls_staged had zero call sites in src/,
and print_sls_results had zero callers anywhere.  A user writing YAML
received a ULS domain check and NO stress check at all, and nothing
said so.  That is not a wrong number: it is the answer to a different
question, delivered in silence.

A combination now carries an 'sls' block with two mandatory
sub-blocks, consumed by the existing 'run' verb.  No new CLI verb, no
new top-level key, no example changed:

    sls:
      moduli: {base: 36000.0, topping: 31000.0}
      limits: {kind: characteristic, fyk: 450.0, fpk: 1860.0}

WHY THE MODULI SIT ON THE COMBINATION.  Phase 32 ratified a 'limits'
block and estimated its cost; prototyping the adapter before writing it
showed the estimate had missed 'moduli', without which the engine
answers "No modulus for zone 0 ('base', c_precast)".  An SLS modulus is
not a property of the zone alone: the same concrete has E_cm/(1+phi)
under a quasi-permanent combination and E_cm under a characteristic
one - two numbers for one zone, separated by which verification is
being performed.  Declaring them on the zone would put a
combination-dependent quantity on the material axis.  Ratified by
Andrea as option (B).

NO DEFAULTS ANYWHERE.  'kind' is mandatory.  'code' comes from the
block, else the document's top level, and there is no third source -
the same precedence resolve_code applies to a material, reused rather
than restated.  'aci318-19' has no stress-limit provider and is refused
by name, as 'aci' is absent from _RHEO_PROVIDERS.  kind='transfer'
still refuses without custom_zone_strengths, through YAML too: the
surface is a way TO the provider, never AROUND it.

ABSENCE IS A RECORD.  A combination declaring no 'sls' block leaves an
explicit skipped entry naming the lever.  "No stress verification was
requested here" and "no stress verification exists" were the same
observable until this phase.

Z-12 closed: print_sls_results has a caller.

WHERE THE PER-STAGE INCREMENT LIVES.  Measured, not assumed.  The ULS
walk's increment has three addends; verify_sls_staged already sums the
third itself and REFUSES the precondition of the second, so the SLS
path needs only the first - resolve_components, already a single home.
Zero lines written in check.py, and the POST confirms zero of the 6044
pre-existing fingerprint keys moved.

THE INSTRUMENT WAS EXTENDED FIRST.  numeric_fingerprint gains a
synthetic document-to-verdict bench, 14 keys, purely additive against a
capture taken with the unextended tool on the same pristine tree
(6044 shared, 0 moved).  Its PRE records the silence as a measurement:
block_carried = false beside load = ok, and every malformed block
'accepted'.

Idempotent, all-or-nothing, CRLF preserved per file.  --selfcheck
compares bytes.  See handoff/33_0-GENSEC_LEDGER_33.md.
"""'''

def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
# GENSEC-COMPLETE phase=33 utc=2026-09-05T19:52:31Z sha256=76d25bc9597fc56746ad7ee674d732a98cebe395afbdfdf6eaa1aceb8c759c60 body_lines=191
