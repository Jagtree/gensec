r"""
Build ``patchers/run_phase34_retrofit_yaml_surface.py``.

The mechanism is lifted verbatim from the Phase-30 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across four phases, and a
rewrite would put a verified thing back on trial for no gain.

Run from the repository root::

    python3 tools/make_phase34_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase33_sls_yaml_surface.py"
OUT = ROOT / "patchers" / "run_phase34_retrofit_yaml_surface.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    "src/gensec/solver/timeline.py",
    "src/gensec/solver/posttension.py",
    "src/gensec/solver/analysis.py",
    "tests/test_phase34_retrofit_yaml_surface.py",
    "tests/test_phase34_task_c_one_home.py",
    "tests/test_phase8_task2.py",
    "tests/run_phase34_patcher_falsification.py",
    "tests/run_phase34_archive_currency_falsification.py",
    "tools/archive_currency.py",
    "tools/numeric_fingerprint.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase34_patcher.py",
    ".fingerprints/34_00_numeric_PRE.txt",
    ".fingerprints/34_00_datum_PRE.txt",
    ".fingerprints/34_00_domain_PRE.txt",
    ".fingerprints/34_01_numeric_POST.txt",
    ".fingerprints/34_01_datum_POST.txt",
    ".fingerprints/34_01_domain_POST.txt",
    "handoff/34_0-GENSEC_LEDGER_34.md",
    "handoff/34_1-GENSEC_PHASE34_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 34 - the YAML surface of the retrofit (D1b-3), and one
home for resolve_components (Z-14).

What this transports
--------------------
The physics of the retrofit landed in Phase 24: PreexistingState makes
declarable what GenSec cannot derive - at what stress an existing cable
sits, how strained its concrete already is, and two clocks that run
from different origins - with eight required fields and no default.

NO DOCUMENT COULD REACH IT.  Measured on the incoming tree: grep -c
retrofit returned 0 on io_yaml.py and 0 on cli.py; PreexistingState was
constructed nowhere in src/ and nowhere in tests/; and the three places
timeline.py named the retrofit were ALL PROSE INSIDE DOCSTRINGS - the
case was not refused, it was inexpressible.  A document describing an
existing member with new cables loaded, ran, and returned the analysis
of a VIRGIN section with the existing cable silently demoted to "not
yet stressed".

THE SURFACE IS A construction_history EVENT, ratified by Andrea over a
top-level block: a retrofit is the state the member is already in when
the history opens, and the block that owns "how the member got here" is
the history.  Measured before the ratification: an unknown key inside
section: LOADS IN SILENCE, which ruled that placement out on evidence.
The event is constrained to be the first entry and to occur once, and
both refusals name their own reason.

THE PATH IS COMPLETE, not a named refusal.  The pre-existing cables are
seeded into the resisting section before the walk starts, at the
locked-in strain the declaration implies; the walk hands the driver
already_bonded and, because base_* is debit-free by contract while an
anchored cable IS debited, routes the cumulative sollecitazione through
applied_at[0] instead.  Measured on a 400x1200 girder with three
tendons: the existing cable enters at eps_init = 0.006008525641, and
the second new cable reconciles 3.08 per cent higher than on the same
document with no retrofit declared.

Z-14: analysis._resolve_components had the body of
VerificationEngine.resolve_components, character for character.  Merged
into the canonical home; two call sites, no third user.

THE INSTRUMENT WAS EXTENDED FIRST, TWICE.  numeric_fingerprint gains a
document-to-verdict retrofit bench and - because AnalysisEngine's
combination path had ZERO keys and the Z-14 merge would have read INERT
whatever it did - a bench on that path too.  49 keys, purely additive
(6092 shared, 0 moved).  The PRE records the silence as a measurement.

Idempotent, all-or-nothing, CRLF preserved per file.  --selfcheck
compares bytes.  See handoff/34_0-GENSEC_LEDGER_34.md.
"""'''

def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
# GENSEC-COMPLETE phase=34 utc=2026-09-06T11:02:02Z sha256=07117f52394b5c6e2c9c0739f7adaafabc051ec1de13f3698a2783432ec0a3e7 body_lines=181
