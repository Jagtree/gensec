#!/usr/bin/env python3
r"""
Generate ``patchers/run_phase19_hull.py`` from the tested tree.

The generator reads the files Phase 19 moved **from disk, as bytes**,
measures each one's line-ending convention at byte level once, and
emits a standalone patcher carrying the verified content.  The emitted
patcher's machinery (``_looks_like_root``, ``_verified``, ``_kind``,
``_write_route``, ``_commit``, ``main``) is lifted verbatim from
``run_phase18_scope.py``, so N-10's all-or-nothing commit travels
unchanged instead of being retyped.
"""

from __future__ import annotations

import base64
import hashlib
import os
import sys
import textwrap
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase18_scope.py"
OUT = ROOT / "patchers" / "run_phase19_hull.py"

FILES = [
    "src/gensec/solver/capacity.py",
    "src/gensec/solver/integrator.py",
    "tools/numeric_fingerprint.py",
    "tools/selfcheck_inventory.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tests/test_phase19_hull.py",
    "examples/example_external_tendon.yaml",
    "examples/example_staged_cracking.yaml",
    "handoff/00_BOOTSTRAP.md",
    "handoff/19_0-GENSEC_LEDGER_19.md",
    "handoff/19_1-GENSEC_PHASE19_RECAP.md",
]

DOCSTRING = r'''r"""
GenSec Phase 19 — the scan hull, the axial bracket, and a gate on
``--selfcheck`` passes that compare nothing.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64``
of exactly what was on disk in the tree the Phase 19 suite ran green
on, line endings included.

* ``src/gensec/solver/capacity.py`` — **N-16**: ``NMDiagram`` built its
  lever-arm hull, and so the projected depth and curvature ceiling of
  every sweep, from bulk fibres and rebars only.  Measured on
  ``examples/example_external_tendon.yaml``: span 594 mm where the
  section spans 747 mm, an excess ceiling of 1.257576 exactly;
* ``src/gensec/solver/integrator.py`` — **N-15**: the axial scan range
  of ``_solve_pure_axial`` had the same two-of-three assembly.  On a
  strand-only slab 26.37 % of the real axial tensile capacity had no
  bracket.  The caller's fall-through is now a stated contract rather
  than an accidental screen;
* ``tools/numeric_fingerprint.py`` — the instrument extended **before**
  the repair: ``span`` and ``chi_max`` were in no key of this
  fingerprint, so it was structurally blind to N-16;
* ``tools/selfcheck_inventory.py`` — byte comparisons counted apart
  from sentinels, and a ``--gate`` that refuses a health list
  containing a patcher which verifies zero bytes;
* two new distributed examples — the external tendon that makes N-16
  observable, and the staged section that cracks (**N-3**);
* ``tools/element_class_reasons.py`` and ``element_class_baseline.txt``
  — the gate's own record: ``_solve_pure_axial`` is no longer a partial
  signature, so the baseline drops from 191 to 190 sites and the two
  reasons for the repaired sites are rewritten to the measured state;
* ``tests/test_phase19_hull.py`` and the three handoff documents.

Completeness of this payload was **measured**, not assumed: the tree it
produces from a pristine Phase 18 checkout is compared file by file
against the tree the suite ran green on.  The first generation of this
patcher omitted the two ``element_class`` files, and only that
comparison showed it.

Why it does not import ``_patchkit``
------------------------------------
A patcher whose verification runs on the code it is repairing has a
green that depends on the repair already being in place.  The commit
here is a standalone copy of the same three-phase discipline
introduced by N-10: pre-flight every target, stage, then rename or
rewrite in place, with the originals held for rollback.

Usage
-----
::

    python patchers/run_phase19_hull.py            # apply
    python patchers/run_phase19_hull.py --selfcheck
    python patchers/run_phase19_hull.py --repair   # overwrite damaged
    python patchers/run_phase19_hull.py --dry-run

Exit status: ``0`` applied or verified, ``1`` selfcheck failure or a
refused overwrite, ``2`` the target is not a GenSec checkout or this
patcher's own payload is corrupt.
"""
'''


def measure_line_ending(data: bytes) -> str:
    """
    Classify a file's line-ending convention at byte level.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
        ``'CRLF'``, ``'LF'`` or ``'none'``.

    Raises
    ------
    ValueError
        If the file mixes conventions.  A mixed file cannot be
        transported with a single declaration, and declaring one
        anyway is the failure mode this measurement exists to prevent.
    """
    crlf = data.count(b"\r\n")
    bare_lf = data.count(b"\n") - crlf
    bare_cr = data.count(b"\r") - crlf
    if bare_cr:
        raise ValueError(f"lone CR present: {bare_cr}")
    if crlf and bare_lf:
        raise ValueError(f"mixed: {crlf} CRLF and {bare_lf} bare LF")
    if crlf:
        return "CRLF"
    if bare_lf:
        return "LF"
    return "none"


def encode(data: bytes) -> str:
    """
    ``zlib`` + ``base64``, wrapped as a Python implicit string
    concatenation.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
    """
    blob = base64.b64encode(zlib.compress(data, 9)).decode("ascii")
    chunks = textwrap.wrap(blob, 100)
    return "\n".join(f'        "{c}"' for c in chunks)


def main() -> int:
    """
    Emit the Phase 19 patcher.

    Returns
    -------
    int
    """
    src = SRC.read_text(encoding="utf-8")
    machinery = src[src.index("def _looks_like_root(root):"):
                    src.index("def main(argv=None):")]
    tail = src[src.index("def main(argv=None):"):]
    tail = tail.replace("Phase 18", "Phase 19")
    tail = tail.replace(
        '    print("GenSec Phase 19 patcher — the declared scope boundary, the "\n'
        '          "191 reasons, all-or-nothing writes")',
        '    print("GenSec Phase 19 patcher — the scan hull, the axial "\n'
        '          "bracket, the gate on vacuous selfchecks")')

    payload, digests, endings = [], [], []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"MISSING {rel}")
            return 2
        data = path.read_bytes()
        le = measure_line_ending(data)
        payload.append(f'    "{rel}":\n{encode(data)},')
        digests.append(f'    "{rel}":\n        "{hashlib.sha256(data).hexdigest()}",')
        endings.append(f'    "{rel}": "{le}",')
        print(f"  {rel:<46} {len(data):>8} bytes  {le}")

    out = [
        DOCSTRING,
        "\nfrom __future__ import annotations\n",
        "import base64",
        "import hashlib",
        "import os",
        "import sys",
        "import zlib",
        "from pathlib import Path\n",
        "ROOT = Path(__file__).resolve().parent.parent\n",
        "#: ``{relative path: zlib+base64 of the verified bytes}``.",
        "PAYLOAD = {",
        "\n".join(payload),
        "}\n",
        "#: ``{relative path: sha256 of the verified bytes}``.",
        "DIGESTS = {",
        "\n".join(digests),
        "}\n",
        "#: ``{relative path: line-ending convention as MEASURED, at byte",
        "#: level, once, before generating}``.  Recorded so a reader can",
        "#: check the transport without decoding it.  No file in this",
        "#: payload is mixed; the generator refuses to emit one that is.",
        "LINE_ENDINGS = {",
        "\n".join(endings),
        "}\n\n",
        machinery,
        tail,
    ]
    OUT.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"\nwrote {OUT} ({OUT.stat().st_size} bytes), "
          f"{len(FILES)} file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
