r"""
Build ``patchers/run_phase35_batch_memory_bound.py``.

The mechanism is lifted verbatim from the Phase-34 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across five phases, and a
rewrite would put a verified thing back on trial for no gain.

Run from the repository root::

    python3 tools/make_phase35_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase34_retrofit_yaml_surface.py"
OUT = ROOT / "patchers" / "run_phase35_batch_memory_bound.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    "src/gensec/solver/capacity.py",
    "tests/test_phase35_batch_chunking.py",
    "tests/run_phase35_patcher_falsification.py",
    "tools/element_class_reasons.py",
    "tools/element_class_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase35_patcher.py",
    ".fingerprints/35_00_numeric_PRE.txt",
    ".fingerprints/35_00_datum_PRE.txt",
    ".fingerprints/35_00_domain_PRE.txt",
    ".fingerprints/35_01_numeric_POST.txt",
    ".fingerprints/35_01_datum_POST.txt",
    ".fingerprints/35_01_domain_POST.txt",
    "handoff/35_0-GENSEC_LEDGER_35.md",
    "handoff/35_1-GENSEC_PHASE35_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 35 - a bound on the integration batch (Z-D2).

What this transports
--------------------
The polar-ductility path solved every curvature configuration of the
scan at once: NMDiagram.generate_polar_curvature builds a flat array of
n_angles * n_chi configurations and _vectorized_solve_N handed the whole
of it to FiberSolver.integrate_batch, which materialises dense
(n_configs, n_fibers) float64 arrays and holds three of them live at the
peak.  Nothing bounded that product.  The peak was set by the input
document, and MEASURED at 0.458 MiB per configuration against 0.469 MiB
predicted for three arrays.

TWO DISTRIBUTED EXAMPLES ASKED FOR ABOUT 6.4 AND 6.2 GiB AND WERE KILLED
BY THE KERNEL.  example_prestress.yaml and example_staged_injection.yaml
both exited 137 - SIGKILL - with peak RSS of 3.748 and 3.736 GiB against
3.906 GiB of RAM.  After this patch they exit 0 at 0.557 and 0.680 GiB.

THE SECOND HALF OF THE DEFECT WAS A DOCSTRING.  generate_polar_curvature
declared that a batch exceeding "the internal chunking threshold of
integrate_batch" would be "automatically split by the solver".
integrate_batch has never carried such a threshold; it allocates in one
call.  The chunking described belonged to _mega_batch_integrate, on the
resistance-surface path, which is exactly why the sentence read as true.
That sentence is why a 6.4 GiB allocation was read as impossible.

What it does NOT transport
--------------------------
No change of physics.  Configurations are integrated independently of
one another, so slicing the batch changes the order of allocation and
nothing else.  The three fingerprints read INERT across the repair:
numeric 6141 values, datum 418, domain 31, zero moved.
"""'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
# GENSEC-COMPLETE phase=35 utc=2026-09-09T21:11:49Z sha256=0c10d48adb501fee318bea3d4a5d75734a97b21b76194d9c7902646ce5d6d3fd body_lines=158
