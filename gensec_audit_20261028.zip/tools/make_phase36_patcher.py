r"""
Build ``patchers/run_phase36_observation_and_unknown_keys.py``.

The mechanism is lifted verbatim from the Phase-34 patcher: everything
above ``PAYLOAD`` and everything from ``_verify_payload`` down is copied
byte for byte, and only the header docstring and the two data blocks are
authored here.  Copying rather than re-deriving is deliberate -- the
apply/selfcheck machinery has been falsified across five phases, and a
rewrite would put a verified thing back on trial for no gain.

Run from the repository root::

    python3 tools/make_phase35_patcher.py
"""
import base64
import hashlib
import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "patchers" / "run_phase35_batch_memory_bound.py"
OUT = ROOT / "patchers" / "run_phase36_observation_and_unknown_keys.py"

#: Every file the phase changed or created, explicitly.  Never a diff,
#: never a glob: a payload built by walking the tree would carry
#: whatever happened to be there, including the residue of an
#: interrupted turn.
FILES = [
    "pyproject.toml",
    ".gitignore",
    "src/gensec/io_yaml.py",
    "tests/test_phase36_unknown_keys.py",
    "tests/run_phase36_patcher_falsification.py",
    "tests/test_phase12_domain.py",
    "tests/test_phase12_ledger.py",
    "tests/test_phase18_scope.py",
    "tools/numeric_fingerprint.py",
    "tools/observation_inventory.py",
    "tools/observation_reasons.py",
    "tools/observation_evidence.py",
    "tools/observation_baseline.txt",
    "tools/selfcheck_inventory.py",
    "tools/make_phase36_patcher.py",
    ".fingerprints/36_00_numeric_PRE.txt",
    ".fingerprints/36_00_datum_PRE.txt",
    ".fingerprints/36_00_domain_PRE.txt",
    ".fingerprints/36_01_numeric_POST.txt",
    ".fingerprints/36_01_datum_POST.txt",
    ".fingerprints/36_01_domain_POST.txt",
    "handoff/36_0-GENSEC_LEDGER_36.md",
    "handoff/36_1-GENSEC_PHASE36_RECAP.md",
    "handoff/00_BOOTSTRAP.md",
]


HEADER = r'''r"""
GenSec Phase 36 - observation declared, unknown keys unified.

What this transports
--------------------
Four subsets, and one of them is the reason for the other three being
small.

1. **The observation inventory (E34-1).**  Every module of
   ``src/gensec`` now names the fingerprint family that observes it, or
   declares itself unobserved with the reason.  A module with neither
   is refused by ``tools/observation_inventory.py --gate``.  It exists
   because a merge once read INERT on all three fingerprints and was
   not thereby correct: no probe looked at it, and the absence of a
   probe has no signal.  Measured on arrival: **17 of 52 modules were
   observed by nothing**, 13 of them carrying numbers.
2. **One mechanism for unknown keys (Z-17, Z-15).**  The six
   hand-written refusals in ``io_yaml.py`` -- not five -- are now one
   helper, and three levels that accepted an unread key in silence stop
   doing so: inside ``section:``, on a combination, on a stage.
3. **pydantic declared (Z-11).**  It arrived only as a transitive
   requirement of fastapi, itself only in the [gui] extra, while
   ``gensec/api.py`` is library code that imports it directly.
4. **Z-12 closed (D).**  Its first half -- a caller for
   ``print_sls_results`` -- closed in Phase 33.  The second half, that
   nothing watched what the function prints, closed here with a bench
   of 19 keys.

Fingerprints
------------
numeric 6141 -> 6160: +19 added, all ``report.*``; 1 moved,
``yaml_sls.refuse.unknown_field``, the wording of the sls.limits
refusal changed by the migration onto one helper -- a declared cause,
not a discovery.  Of the 6141 pre-existing keys, zero others moved.
datum 418 and domain 31 read INERT, byte-identical files.
"""
'''


def _b64(raw: bytes) -> str:
    r"""Plain ``base64``, wrapped as Python string literals.

    No compression: the patcher this one is lifted from stores the
    bytes as they are, and a second encoding would be a second thing to
    get wrong for no gain the reader can check by eye.
    """
    blob = base64.b64encode(raw).decode("ascii")
    return "\n".join(f'        "{c}"' for c in textwrap.wrap(blob, 66))


def main() -> int:
    r"""
    Write the patcher.

    Returns
    -------
    int
        ``0`` on success; ``1`` if a payload file is absent or mixes
        line endings.
    """
    src = SRC.read_text(encoding="utf-8")
    i_head = src.index("import base64")
    i_pay = src.index("#: Final content of every file this phase declares")
    i_tail = src.index("def _verify_payload() -> None:")
    head = src[i_head:i_pay]
    tail = src[i_tail:]

    missing = [f for f in FILES if not (ROOT / f).exists()]
    if missing:
        print("ABORT: payload files absent from the tree:")
        for f in missing:
            print("   ", f)
        return 1

    pay, dig = [], []
    for rel in FILES:
        raw = (ROOT / rel).read_bytes()
        pay.append(f'    "{rel}": base64.b64decode(\n{_b64(raw)}),')
        dig.append(f'    "{rel}":\n'
                   f'        "{hashlib.blake2b(raw, digest_size=16).hexdigest()}",')
        # Measured on the bytes, per file, never assumed: this tree is
        # not uniform and a patcher that normalised endings would
        # rewrite files it was not asked to change.
        crlf = raw.count(b"\r\n")
        bare = raw.count(b"\n") - crlf
        if crlf and bare:
            print(f"ABORT: {rel} mixes CRLF and bare LF "
                  f"({crlf} / {bare}); a payload cannot state one "
                  f"ending for it.")
            return 1

    out = (
        HEADER + "\n\n"
        + head
        + "#: Final content of every file this phase declares, keyed by\n"
          "#: path relative to the repository root.  Base64 so that the\n"
          "#: payload carries its own line endings unmodified.\n"
        + "PAYLOAD: Dict[str, bytes] = {\n" + "\n".join(pay) + "\n}\n\n"
        + "#: BLAKE2b-128 of each payload, computed at build time and\n"
          "#: re-checked on import.  A payload that no longer hashes to\n"
          "#: its declared digest is a corrupted patcher, and a\n"
          "#: corrupted patcher must not be allowed to write.\n"
        + "DIGEST: Dict[str, str] = {\n" + "\n".join(dig) + "\n}\n\n\n"
        + tail
    )
    OUT.write_bytes(out.encode("utf-8"))
    print(f"wrote {OUT.relative_to(ROOT)}: {len(FILES)} file(s), "
          f"{len(out.splitlines())} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
