r"""
Which fingerprint family observes which module — E34-1, closed as a gate.

Why this file exists
--------------------
E34-1 is the reference defect.  A merge of two implementations read
``INERT`` on all three fingerprints, and the reason was not that the
merge was correct: **no probe looked at that code**.  The absence of a
probe has no signal.  A repair validated against a fingerprint that
never names the repaired module is validated against nothing, and the
green is indistinguishable from the green of a repair that worked.

Line coverage does not answer this question.  Coverage says *this line
ran*; the question is *this line is watched*.  E34-1 was born in a
module that was imported, executed, and still unobserved.  A ``coverage
run`` over the capture was attempted in Phase 35, ran for over fifty
minutes without completing, and would not have decided anything had it
finished (``35_0`` §6).

The only mechanical form of "observed" is a **declaration**: every
module of ``src/gensec`` names the family of fingerprint keys that
observes it, or declares itself :data:`UNOBSERVED` with the reason it
carries nothing a fingerprint could watch.  A module with neither is
refused by the gate, exactly as a partial element-class signature with
no reason is refused by ``element_class_inventory --gate``.

What a family name is
---------------------
A family is the first ``.``-separated component of a fingerprint key,
qualified by the fingerprint it belongs to, because the same component
appears in more than one of them (``d1c`` is both a numeric bench and a
datum bench)::

    numeric:law                 law.*            in the numeric capture
    datum:d1c                   d1c.*            in the datum capture
    domain:EC2RheologicalModel  EC2Rheological…  in the domain capture

The collective ``numeric:examples`` / ``datum:examples`` stands for the
walk over ``examples/*.yaml``: it expands, mechanically, to the stem of
every distributed example that appears as a family in that capture.  It
is a spelling convenience with a measured expansion, not a wildcard —
``observation_inventory --gate`` refuses it if the expansion is empty.

How these declarations were established
---------------------------------------
Not by reading.  A single capture of each of the three fingerprints was
run under a **call-level** profiler (``sys.setprofile``, ``'call'``
events only, no line tracing), recording for every top-level probe the
set of ``src/gensec`` modules entered while that probe's keys were
being produced.  The capture under the profiler emitted the same 6141
values as the capture without it, so the instrument was not perturbed.

That trace is *evidence*, not the claim.  Entering a module is
necessary for observing it and not sufficient — which is E34-1 restated
— so a module entered by a probe still owes the sentence saying **what
of it** the family's keys would move on.  The trace's real service is
in the other direction: a module that no probe enters cannot be
observed by any key, and that half is a measurement.

The taxonomy of UNOBSERVED reasons
----------------------------------
Each unobserved entry opens with a tag naming *why* nothing watches it.
The tags separate the two very different things this file must not
conflate: a module that carries nothing observable, and a module that
carries plenty and simply has no probe.

===============  =====================================================
tag              the claim
===============  =====================================================
``CONSTANTS``    the module is declarations only — no arithmetic and no
                 branch a number could move through
``REEXPORT``     an ``__init__`` or shim whose whole body is imports
``GENERATED``    written by the build, not by hand
``DEBT``         **not absolved** — the module produces or renders
                 numbers and no key watches them.  This is the probe
                 debt, named rather than repaired
===============  =====================================================

Only ``DEBT`` is a defect.  The other three say the module has nothing
a fingerprint could hold still.

Notes
-----
This module is data plus two functions.  ``observation_inventory.py``
imports them to write and to check the baseline.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

#: Modules that a fingerprint family observes, keyed by path relative to
#: ``src/gensec``.  The value is ``(families, reason)``: the families
#: whose keys move when this module's numbers move, and the sentence
#: saying what of it they hold.
#:
#: A module is listed under **the families that would catch a change in
#: it**, not under every family that happens to enter it.  The two
#: differ: ``geometry/primitives.py`` is entered by twelve families
#: because every bench builds a section, and all twelve would catch a
#: wrong vertex — so all twelve are named.  ``solver/timeline_run.py``
#: is entered by two, and only those two see its output.
OBSERVED: Dict[str, Tuple[Tuple[str, ...], str]] = {}

#: Modules no key observes, keyed the same way, with the reason.
UNOBSERVED: Dict[str, str] = {}


def _obs(entries: Dict[str, Tuple[Tuple[str, ...], str]]) -> None:
    for k, v in entries.items():
        if k in OBSERVED or k in UNOBSERVED:
            raise KeyError(f"duplicate observation entry for {k!r}")
        OBSERVED[k] = v


def _unobs(entries: Dict[str, str]) -> None:
    for k, v in entries.items():
        if k in OBSERVED or k in UNOBSERVED:
            raise KeyError(f"duplicate observation entry for {k!r}")
        UNOBSERVED[k] = v


def entry_for(module: str):
    r"""
    The declaration for *module*, or ``None``.

    Parameters
    ----------
    module : str
        Path relative to ``src/gensec``, ``/``-separated.

    Returns
    -------
    tuple or None
        ``(families, reason)`` for an observed module, where
        ``families`` is a tuple of qualified family names;
        ``((), reason)`` for an unobserved one — the empty tuple **is**
        the statement that nothing observes it.  ``None`` when the
        module has no entry at all, which is what the gate refuses.
    """
    if module in OBSERVED:
        return OBSERVED[module]
    if module in UNOBSERVED:
        return ((), UNOBSERVED[module])
    return None


def reason_for(module: str) -> Optional[str]:
    r"""The reason text for *module*, or ``None`` if it has no entry."""
    ent = entry_for(module)
    return None if ent is None else ent[1]


# ======================================================================
#  GEOMETRY — every bench builds a section, so this family is watched
#  from many directions.  That is not an absolution by category: each
#  entry says which quantity of the module the keys hold.
# ======================================================================

_obs({
 "geometry/fiber.py": (
   ("numeric:coord", "numeric:examples", "numeric:sls", "numeric:c5",
    "numeric:d1c", "numeric:dec", "numeric:retrofit", "datum:examples",
    "datum:d1c", "datum:retrofit"),
   "The fibre and point-element carriers.  numeric:coord records fibre "
   "centroids and areas directly; every mechanical family integrates "
   "over them, so a wrong area or a wrong lever arm moves a resultant "
   "in all of them.  datum:* holds the locked-in strain carried on the "
   "element, which is a field of this module and of no other."),

 "geometry/geometry.py": (
   ("numeric:coord", "numeric:examples", "numeric:checks",
    "datum:examples"),
   "Polygon algebra and the reference point.  numeric:coord records "
   "convexity, hole count and the reported coordinates of each "
   "example; a change of reference point moves every recorded "
   "coordinate, which is the shortest path from this module to a key."),

 "geometry/primitives.py": (
   ("numeric:coord", "numeric:examples", "numeric:entry",
    "datum:examples"),
   "The shape factories.  Their output is the polygon whose vertices "
   "numeric:coord records verbatim, so a wrong primitive is a wrong "
   "recorded vertex before it is a wrong resultant."),

 "geometry/properties.py": (
   ("numeric:examples", "numeric:sls"),
   "Gross and ideal section properties.  The example walk records A, "
   "I and the elastic centroid per document; numeric:sls records the "
   "homogenised properties the stress check divides by."),

 "geometry/section.py": (
   ("numeric:coord", "numeric:examples", "numeric:checks",
    "numeric:sls", "numeric:entry", "datum:examples"),
   "The section container and its meshing.  The fibre count and the "
   "per-fibre coordinates it produces are recorded by numeric:coord; "
   "a change of mesh method or size moves every integrated resultant "
   "in the mechanical families."),

 "geometry/__init__.py": (
   ("numeric:sls",),
   "Not a re-export shim: it carries the package-level construction "
   "helpers the SLS bench calls by name.  Their return values reach "
   "numeric:sls keys."),
})

# ======================================================================
#  MATERIALS — the constitutive surface.  domain:* watches the validity
#  intervals, numeric:law and numeric:ageing the law values themselves.
# ======================================================================

_obs({
 "materials/base.py": (
   ("numeric:ageing", "numeric:examples", "numeric:c5",
    "numeric:sls", "numeric:dec", "domain:RheologicalModel",
    "domain:EC2RheologicalModel", "domain:TabulatedRheologicalModel"),
   "The material protocol and its shared arithmetic.  numeric:ageing "
   "samples what it returns against age.  All three domain families "
   "are named because this module OWNS DOMAIN, DOMAIN_SOURCE and "
   "QUANTITIES: EC2RheologicalModel overrides them, "
   "TabulatedRheologicalModel does not and publishes this module's, "
   "so an edit here moves keys of all three.  numeric:law is "
   "deliberately NOT named: measured, that bench enters only "
   "ec2_properties and service_concrete, and naming it here would be "
   "the category absolution this file exists to refuse."),

 "materials/codes.py": (
   ("numeric:examples", "numeric:c5", "numeric:yaml_sls",
    "numeric:yaml_retrofit", "datum:examples"),
   "Code registry and resolution.  Every family that loads a document "
   "resolves its code here; a wrong resolution changes which partial "
   "factors are applied and moves the verdict keys of all of them."),

 "materials/concrete.py": (
   ("numeric:Concrete", "numeric:ageing", "numeric:examples",
    "numeric:sls", "numeric:dec", "numeric:checks", "numeric:entry",
    ),
   "The concrete laws.  numeric:Concrete is the synthetic bench for "
   "the undeclared container and holds this class's refusals verbatim; "
   "numeric:dec holds the decompression strain, which is a concrete "
   "quantity; the mechanical families integrate its sigma(eps) and "
   "would move on a wrong branch of it.  numeric:law is NOT named: "
   "measured, the law bench never enters this module.  "
   "domain:EC2RheologicalModel is NOT named either: measured in Phase "
   "37, that class and every attribute the domain capture reads off "
   "it live in rheology.py and base.py, so no edit here can move a "
   "domain key."),

 "materials/ec2_properties.py": (
   ("numeric:law", "numeric:ageing", "numeric:examples", "numeric:c5",
    "numeric:sls"),
   "EN 1992-1-1 derived properties (f_cm, E_cm, eps_c1, creep and "
   "shrinkage).  numeric:ageing samples them against age directly, "
   "which is the only family that varies the argument they are "
   "functions of.  domain:EC2RheologicalModel is NOT named: the "
   "domain capture reads declared class attributes, never these "
   "functions, and Phase 37 measured that no edit here moves one."),

 "materials/ec2_bridge.py": (
   ("numeric:ageing", "numeric:c5", "numeric:examples",
    "numeric:yaml_retrofit"),
   "The adapter from the EN 1992 property set to the rheological "
   "protocol.  numeric:c5 holds the loss chain that consumes it, so a "
   "wrong creep coefficient reaches a key as a wrong loss.  "
   "domain:EC2RheologicalModel is NOT named: the adapter runs at "
   "solve time and the domain capture never calls it."),

 "materials/rheology.py": (
   ("numeric:c5", "numeric:examples", "numeric:yaml_sls",
    "domain:EC2RheologicalModel",
    "domain:TabulatedRheologicalModel"),
   "The rheological protocol and its registry.  The domain fingerprint "
   "exists for this module: its 31 declarations are the validity "
   "intervals and their normative sources, and nothing else in the "
   "tree records them.  domain:RheologicalModel is NOT named: that "
   "base class is defined in base.py and only its subclasses live "
   "here."),

 "materials/tabulated.py": (
   ("numeric:ageing",),
   "TabulatedMaterial, a tabulated constitutive law.  numeric:ageing "
   "samples its interpolation.  domain:TabulatedRheologicalModel was "
   "named here until Phase 37 and was a name collision read as a "
   "relationship: TabulatedRheologicalModel is a different class, in "
   "rheology.py, and nothing in this module reaches the domain "
   "capture."),

 "materials/service_concrete.py": (
   ("numeric:law", "numeric:sls", "numeric:sls_nl", "numeric:ageing",
    "numeric:examples", "numeric:yaml_sls"),
   "The service-level concrete law.  numeric:law samples it point by "
   "point and numeric:sls holds the stresses it returns under the "
   "verification moduli, so both the curve and its use are watched."),

 "materials/steel.py": (
   ("numeric:ageing", "numeric:examples", "numeric:analysis",
    "numeric:sls", "numeric:checks", "numeric:dec", "datum:examples"),
   "Reinforcing and structural steel laws.  The yield plateau they "
   "declare is what numeric:analysis's ductility keys are measured "
   "against, and numeric:ageing samples the material built from them. "
   "numeric:law is NOT named: measured, it never enters this module, "
   "which is why a wrong steel branch has no dedicated law key."),

 "materials/prestress_properties.py": (
   ("numeric:ageing", "numeric:c5", "numeric:examples",
    "numeric:yaml_retrofit", "datum:examples"),
   "Strand and bar properties, including relaxation.  numeric:c5 is "
   "the loss bench and holds the relaxation loss this module computes; "
   "datum:examples holds the effective prestrain that results."),

 "materials/en10025_properties.py": (
   ("numeric:ageing",),
   "EN 10025 structural-steel grades.  A table of declared values, "
   "sampled by numeric:ageing through the material it builds.  Named "
   "here rather than as CONSTANTS because the grade lookup has a "
   "branch, and a wrong branch is a wrong f_y in a recorded law.  "
   "domain:RheologicalModel is NOT named: steel grades are not a "
   "rheological provider and the domain capture never reaches here."),

 "materials/elastic.py": (
   ("numeric:examples", "numeric:sls", "numeric:sls_nl",
    "numeric:dec", "numeric:c5", "numeric:yaml_sls"),
   "The linear-elastic law.  It is the reference the non-linear "
   "families are compared against, so a wrong modulus moves the "
   "recorded stresses of numeric:sls and the recorded losses of "
   "numeric:c5.  numeric:law is NOT named: measured, it never enters "
   "this module."),

 "materials/verification_limits.py": (
   ("numeric:checks", "numeric:sls", "numeric:sls_nl",
    "numeric:entry", "numeric:yaml_sls", "numeric:dec"),
   "The limit provider.  numeric:yaml_sls records the per-zone "
   "provenance string of every limit it returns, which is the only "
   "place in the tree where a limit's origin is held still, and "
   "numeric:checks records its refusals."),

 "materials/__init__.py": (
   ("numeric:ageing",),
   "Carries the material factory, not only re-exports: the ageing "
   "bench builds materials through it, so a wrong dispatch is a wrong "
   "law.  domain:RheologicalModel was named here and is withdrawn: "
   "the domain capture imports the providers directly and builds "
   "nothing through this module."),
})

# ======================================================================
#  SOLVER
# ======================================================================

_obs({
 "solver/integrator.py": (
   ("numeric:coord", "numeric:examples", "numeric:sls",
    "numeric:sls_nl", "numeric:d1c", "numeric:dec", "numeric:c5",
    "numeric:entry", "numeric:checks", "datum:examples", "datum:d1c"),
   "The fibre integration kernel.  Every resultant in the fingerprint "
   "passes through it, and numeric:d1c exercises its increment form on "
   "a law whose tangent varies, which no distributed example reaches."),

 "solver/capacity.py": (
   ("numeric:examples", "numeric:sls", "numeric:c5",
    "numeric:yaml_sls", "numeric:yaml_retrofit", "datum:examples"),
   "The N-M domain and the moment-curvature machinery.  The example "
   "walk records the hull, the scan and the ductility ratios; the "
   "chunking added in Phase 35 is watched through the same keys, "
   "because a wrong split changes the recorded hull."),

 "solver/check.py": (
   ("numeric:examples", "numeric:analysis", "numeric:sls",
    "numeric:c5", "numeric:yaml_sls", "numeric:yaml_retrofit"),
   "The verification engine.  numeric:yaml_sls holds its verdicts "
   "produced from a document, including refusals, so a check that "
   "declines to answer is recorded as such rather than as a pass.  "
   "numeric:checks is NOT named, and the name is misleading: measured, "
   "that bench exercises the zone checks and the silences through "
   "solver/sls.py and materials/verification_limits.py and never "
   "enters this module."),

 "solver/analysis.py": (
   ("numeric:analysis", "numeric:examples", "numeric:sls"),
   "Combination and demand resolution.  numeric:analysis was added in "
   "Phase 34 for exactly this module: before it, zero keys named it, "
   "and the merge of its private duplicate resolver would have read "
   "INERT whatever it did (Z-14).  It is the worked example of what "
   "this whole inventory is for."),

 "solver/section_state.py": (
   ("numeric:c5", "numeric:examples", "numeric:sls", "numeric:d1c",
    "numeric:retrofit", "numeric:checks", "datum:examples",
    "datum:retrofit"),
   "Staged section state and stage resolution.  datum:retrofit "
   "exercises PreexistingState directly, and the locked-in strain it "
   "carries is a datum key of its own rather than an inference from a "
   "resultant."),

 "solver/sls.py": (
   ("numeric:sls", "numeric:sls_nl", "numeric:dec", "numeric:c5",
    "numeric:examples", "numeric:yaml_sls", "numeric:checks",
    "datum:examples"),
   "The service-level engine.  numeric:sls holds the per-stage stress "
   "records, numeric:sls_nl the non-linear branch, and numeric:dec the "
   "decompression search, so its three paths are watched separately "
   "rather than through one aggregate."),

 "solver/losses.py": (
   ("numeric:c5", "numeric:coord", "numeric:examples",
    "numeric:yaml_sls", "datum:examples"),
   "Prestress losses.  numeric:c5 is the loss bench and holds each "
   "contribution by name — friction, wedge, elastic, creep, shrinkage, "
   "relaxation — so a compensating pair of errors does not cancel in "
   "the recorded total."),

 "solver/posttension.py": (
   ("numeric:c5", "numeric:d1c", "numeric:retrofit",
    "numeric:examples", "numeric:yaml_retrofit", "datum:d1c",
    "datum:retrofit"),
   "The post-tension sequence solver.  datum:d1c holds the effective "
   "prestrain and the grout reference strain per tendon, which are "
   "this module's state and are not recoverable from a resultant."),

 "cli.py": (
   ("numeric:cli",),
   "The 'run' verb's wiring.  numeric:cli holds which engines the "
   "verb invokes and in what order, whether the timeline came back "
   "active, run_sls's own count of combinations that asked for a "
   "stress verification, and the exit code on a valid and on a "
   "rejected document.  What the verb PRINTS is deliberately NOT held "
   "here: report.* has held that since Phase 36, and a second key on "
   "the same fact is a second thing to update and no extra "
   "discriminator.  Argument parsing beyond the 'run' verb is still "
   "unobserved and this entry does not claim otherwise."),

 "solver/prestress_transfer.py": (
   ("numeric:d1c",),
   "The independent closed-form references for elastic-shortening "
   "losses.  numeric:d1c compares the fiber driver against "
   "sequential_posttension_loss on the linear law, where the two must "
   "agree to the last bit, and on the service law, where the gap is "
   "the constant-modulus assumption priced."),

 "solver/prestress_ledger.py": (
   ("numeric:c5", "numeric:coord", "numeric:examples",
    "numeric:yaml_sls", "numeric:yaml_retrofit", "datum:examples"),
   "The per-tendon force ledger.  numeric:c5 records its entries "
   "individually, which is what makes a loss attributed to the wrong "
   "tendon visible at all."),

 "solver/timeline.py": (
   ("numeric:c5", "numeric:coord", "numeric:examples",
    "numeric:yaml_sls", "numeric:yaml_retrofit", "datum:examples"),
   "The construction timeline compiler.  The staged examples record "
   "one set of keys per compiled stage, so a stage compiled at the "
   "wrong age moves a recorded age and not only a downstream stress."),

 "solver/timeline_run.py": (
   ("numeric:yaml_sls", "numeric:yaml_retrofit"),
   "The document-to-verdict driver.  These two families are the whole "
   "of its observation, and they exist because it had none: before "
   "Phase 33 no key saw an SLS result produced from a YAML document, "
   "and before Phase 34 none saw a retrofit declaration."),

 "solver/__init__.py": (
   ("numeric:sls",),
   "Carries the solver-level construction helpers the SLS bench calls "
   "by name; their return values reach numeric:sls keys."),
})

# ======================================================================
#  TOP LEVEL
# ======================================================================

_obs({
 "io_yaml.py": (
   ("numeric:examples", "numeric:coord", "numeric:c5",
    "numeric:yaml_sls", "numeric:yaml_retrofit", "datum:examples"),
   "The document reader.  The example walk records the parse of all "
   "24 distributed documents; numeric:yaml_sls and numeric:yaml_"
   "retrofit record the acceptance or refusal of synthetic documents "
   "key by key, including the verdict string of a refusal, so a "
   "refusal that stops refusing is a moved key and not a silence."),

 "tolerances.py": (
   ("numeric:c5", "numeric:coord", "numeric:examples",
    "numeric:yaml_sls", "numeric:yaml_retrofit"),
   "Convergence and comparison tolerances.  Every iterative family "
   "reads them, and a loosened tolerance shows up as a moved residual "
   "in numeric:c5 before it shows up as a wrong answer."),

 "output/report.py": (
   ("numeric:report",),
   "The printed verification and SLS tables.  Z-12's first half -- a "
   "caller -- closed in Phase 33; the second half stayed open until "
   "this inventory measured it, and this entry is what changed: "
   "numeric:report holds what print_sls_results RENDERS, read back "
   "out of the lines it printed, not the dict behind it.  A table "
   "that starts reporting the wrong column, or formats eta from the "
   "wrong field, moves report.eta[...] and nothing else, which is "
   "the point.  Column widths and rule characters are deliberately "
   "not recorded: they are formatting, and a fingerprint that fought "
   "over them would be one nobody could move."),

 "__init__.py": (
   ("numeric:ageing",),
   "The package surface.  The ageing bench builds its objects through "
   "the names it exports, so a re-export pointing at the wrong home "
   "is caught by the family that consumes it.  "
   "domain:RheologicalModel was named here and is withdrawn: the "
   "domain capture never resolves a provider through this module."),
})

# ======================================================================
#  UNOBSERVED — 13 of 51 modules.  Four carry nothing a fingerprint
#  could hold; nine carry numbers and have no probe.  That second
#  number is the probe debt.
#
#  The counts are measured, and this comment used to disagree with the
#  measurement: it read "16 of 52" while the gate reported fourteen
#  unobserved of fifty-two.  A stale narrative in the file the gate
#  reads from is the cheapest lie in the tree, and Phase 38 corrected
#  it while editing the table for another reason.  Run
#  `python tools/observation_inventory.py --gate` before trusting the
#  sentence above; the gate computes from the table below, this
#  paragraph does not.
#
#  It was thirteen when this table was first written.  One was
#  repaired in the same phase and only that one: output/report.py,
#  because Z-12 already named it and the bench that closes it was
#  designed rather than improvised.  The rest are named and left: a
#  probe written to make this count look better is a probe nobody
#  designed, and would be the second species of E34-1 rather than its
#  cure.  Phase 38 removed one of them outright -- _presets.py was dead
#  code duplicating the output block, so the debt went with the module
#  rather than being paid (38_2 section 7.4).
# ======================================================================

_unobs({
 "_version.py":
   "GENERATED: written by setuptools_scm at build time.  Its only "
   "content is a version string and a tuple; no arithmetic, and its "
   "value legitimately differs between two checkouts of the same "
   "commit, so pinning it would make the fingerprint depend on the "
   "build rather than on the physics.",

 "_about.py":
   "CONSTANTS: author, licence and project URLs.  No number.",

 "output/__init__.py":
   "REEXPORT: the body is imports.  A wrong re-export is caught by "
   "the family that consumes the re-exported name, not by a key of "
   "its own.",

 "__main__.py":
   "REEXPORT: a four-line shim that calls gensec.cli.main.  It has no "
   "behaviour of its own to observe; what it forwards to is DEBT "
   "below, and naming the shim would put the debt in the wrong place.",

 "api.py":
   "DEBT: the request and response schemas and the load/solve "
   "orchestration behind them.  tests/test_api.py exercises it, and a "
   "test is not a fingerprint: it asserts what its author thought to "
   "assert, whereas a key moves whether or not anyone thought of it.",

 "server.py":
   "DEBT: the HTTP surface over api.py.  Same reasoning as api.py, "
   "one layer out.  Phase 38 measured the cost and Andrea deferred it "
   "to the phase that builds the GUI: a key on this module's numbers "
   "would re-observe api.py through a transport, and would drag an "
   "HTTP client into the fingerprint tool -- a new dependency in an "
   "instrument, which is the worst place for one.  What server.py adds "
   "of its own is routing, not arithmetic (38_2 section 7.3).  The "
   "debt stands; the deferral is ratified, not forgotten.",


 "output/summary.py":
   "DEBT: the verification summary and its statistics — counts, "
   "minima, governing combination.  These are derived numbers, "
   "exactly the kind a fingerprint holds well, and none is held.",

 "output/export.py":
   "DEBT: the JSON export of verification results.  The exported "
   "documents are the artefact a user keeps; their field names and "
   "values are unobserved.",

 "output/timeline_dump.py":
   "DEBT: the per-stage timeline dump.  The staged families record "
   "the solver's state, not this module's rendering of it, so the two "
   "can disagree without any key noticing.",

 "output/timeline_projections.py":
   "DEBT: projections of timeline quantities onto the reporting axes. "
   "Arithmetic with no key on it.",

 "output/plots.py":
   "DEBT: the N-M and moment-curvature figures.  The curves plotted "
   "are observed at their source (numeric:examples records the hull "
   "and the scan); what this module does to them on the way to a PNG "
   "is not.",

 "output/geometry_plot.py":
   "DEBT: the section drawing.  Same shape as plots.py — the "
   "coordinates are observed by numeric:coord, their rendering is "
   "not.",

 "output/_polydraw.py":
   "DEBT: polygon drawing primitives, including hole handling.  "
   "Geometric arithmetic downstream of the observed geometry and "
   "upstream of nothing that is recorded.",

})
