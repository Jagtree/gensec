# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
Fingerprint of every provider's **declared validity domain**.

Why a third battery
-------------------
``numeric_fingerprint`` records physical quantities and
``datum_fingerprint`` records datum planes.  Neither records what a
provider *declares* about where it is defined -- so both are
structurally blind to a change in ``DOMAIN``, and both report ``INERT``
when one moves.

Phase 17 moved one: ``f_ctm`` left ``EC2RheologicalModel.DOMAIN``
because expression (3.4) is written on :math:`\beta_{cc}(t)` and the
28-day value and ``fben2`` evaluates it at every age.  An ``INERT`` on a
path a section touches is silence, not proof; this file is what turns
that silence into a measurement.

The battery records, per provider class:

* the closed vocabulary ``QUANTITIES``;
* every ``DOMAIN`` interval;
* every ``DOMAIN_SOURCE`` citation;
* the names declared with no attribute on the class
  (``declared_no_surface``), which is the residue of N-8 kept visible
  rather than deleted;
* the answer ``domain(name)`` gives for every name in the vocabulary,
  including the ``None`` that means *stated at every age*.

Usage
-----
::

    python tools/domain_fingerprint.py capture before.txt
    python tools/domain_fingerprint.py capture after.txt
    python tools/domain_fingerprint.py compare before.txt after.txt
"""

from __future__ import annotations

import inspect
import os
import sys

sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))


def _providers():
    """Yield ``(name, class)`` for every concrete provider."""
    from gensec.materials.base import RheologicalModel
    from gensec.materials import rheology
    for name, obj in sorted(vars(rheology).items()):
        if (inspect.isclass(obj) and issubclass(obj, RheologicalModel)
                and obj is not RheologicalModel):
            yield name, obj
    yield "RheologicalModel", RheologicalModel


def capture(path):
    """Write the declared-domain fingerprint to *path*."""
    lines = []
    for name, cls in _providers():
        # getattr, not attribute access: a pre-correction tree has no
        # QUANTITIES at all, and a battery that crashes on the "before"
        # capture cannot measure the movement it exists to measure.
        vocab = getattr(cls, "QUANTITIES", frozenset())
        lines.append(f"{name}.QUANTITIES = {sorted(vocab)!r}")
        for q in sorted(cls.DOMAIN):
            lines.append(f"{name}.DOMAIN[{q}] = "
                         f"{tuple(float(v) for v in cls.DOMAIN[q])!r}")
        for q in sorted(cls.DOMAIN_SOURCE):
            lines.append(f"{name}.DOMAIN_SOURCE[{q}] = "
                         f"{cls.DOMAIN_SOURCE[q]!r}")
        if hasattr(cls, "check_vocabulary"):
            rep = cls.check_vocabulary()
            lines.append(f"{name}.declared_no_surface = "
                         f"{rep['declared_no_surface']!r}")
        for q in sorted(set(vocab) | set(cls.DOMAIN)):
            lines.append(f"{name}.declares[{q}] = "
                         f"{cls.DOMAIN.get(q)!r}")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(sorted(lines)) + "\n")
    print(f"captured {len(lines)} declarations -> {path}")
    return 0


def compare(a, b):
    """Compare two fingerprints and report every moved declaration."""
    def load(p):
        out = {}
        for ln in open(p, encoding="utf-8"):
            ln = ln.rstrip("\n")
            if " = " in ln:
                k, v = ln.split(" = ", 1)
                out[k] = v
        return out
    A, B = load(a), load(b)
    gone = sorted(set(A) - set(B))
    new = sorted(set(B) - set(A))
    moved = sorted(k for k in set(A) & set(B) if A[k] != B[k])
    print(f"only in before : {len(gone)}")
    for k in gone:
        print(f"  - {k} = {A[k]}")
    print(f"only in after  : {len(new)}")
    for k in new:
        print(f"  + {k} = {B[k]}")
    print(f"declarations moved : {len(moved)}")
    for k in moved:
        print(f"  ~ {k}: {A[k]}  ->  {B[k]}")
    if not (gone or new or moved):
        print("INERT — every declaration is unchanged.")
        return 0
    return 1


def main(argv=None):
    """Command-line entry point."""
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) == 2 and argv[0] == "capture":
        return capture(argv[1])
    if len(argv) == 3 and argv[0] == "compare":
        return compare(argv[1], argv[2])
    print(__doc__)
    return 2


if __name__ == "__main__":                             # pragma: no cover
    raise SystemExit(main())
