r"""
Evidence for :mod:`observation_reasons` — which modules each fingerprint
family actually enters.

Why this is a separate tool
---------------------------
``observation_inventory --gate`` checks that every module carries a
declaration and that every family named exists.  It cannot check that a
named family would really move on a change in the module: that is the
claim the reason makes, and no cheap static check establishes it.

This tool supplies the half that *is* mechanical.  It runs one capture
of each of the three fingerprints under a **call-level** profiler
(:func:`sys.setprofile`, ``'call'`` events only — no line tracing) and
records, for every top-level probe of the numeric capture, the set of
``src/gensec`` modules entered while that probe's keys were produced.

Entering a module is **necessary** for observing it and not sufficient
— which is E34-1 restated.  So the trace is used in one direction only:

- a family that never enters a module **cannot** observe it, and a
  declaration naming it is refused;
- a family that does enter a module *may* observe it, and the reason
  still has to say what of it the keys hold.

Run in Phase 36, this direction alone caught five declarations that
reading had produced and measurement contradicted — among them the two
findings the phase reports: ``numeric:law`` enters only
``materials/ec2_properties.py`` and ``materials/service_concrete.py``
(not the constitutive surface its name suggests), and ``numeric:checks``
never enters ``solver/check.py``.

Why not coverage
----------------
``coverage run`` over the capture was attempted in Phase 35: past fifty
minutes without completing, and the number would have answered a
different question (``35_0`` §6).  Call-level profiling costs a fraction
of line tracing; the capture under it emitted the same 6141 values as
the capture without it, so the instrument is not perturbed.

Cost
----
Roughly the cost of the three captures plus a small profiling overhead
— about half an hour.  It is **not** in the closing checklist, and is
not meant to be: it is re-run when declarations are rewritten, and its
output is read by a human.

Usage
-----
::

    python tools/observation_evidence.py --out evidence.json
    python tools/observation_evidence.py --out evidence.json --check

``--check`` cross-reads :mod:`observation_reasons` and prints every
declaration naming a family that the trace shows never enters the
module.  Exit 1 if there is one.

Run it from **outside** the working tree (E35-2): the captures deposit
files in the current directory.
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from typing import Dict, List, Set

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
PKG = os.path.join(SRC, "gensec")
TOOLS = os.path.dirname(os.path.abspath(__file__))

#: The top-level probes of the numeric capture.  One entry per probe
#: whose keys form one or more families; the walk over the distributed
#: documents is ``_probe_example``, called once per document.
NUMERIC_PROBES = (
    "_material_ageing", "_service_law", "_service_concrete",
    "_sls_staged", "_sls_nonlinear", "_decompression",
    "_undeclared_container", "_retrofit_declaration",
    "_analysis_combination_path", "_nonlinear_increment",
    "_reported_coordinates", "_c5_losses", "_check_zones",
    "_check_silences", "_yaml_sls_surface", "_yaml_retrofit_surface",
    "_sls_report_render", "_cli_run_wiring", "_probe_example",
)

_hits: Set[str] = set()


def _profiler(frame, event, arg):
    r"""Record the package module of every call.  ``'call'`` only."""
    if event == "call":
        fn = frame.f_code.co_filename
        if fn.startswith(PKG + os.sep):
            _hits.add(os.path.relpath(fn, PKG).replace(os.sep, "/"))
    return None


def _example_stems() -> Set[str]:
    return {os.path.basename(p)[:-5]
            for p in glob.glob(os.path.join(ROOT, "examples", "*.yaml"))}


def trace_numeric(out_dir: str) -> Dict[str, Dict[str, List[str]]]:
    r"""
    Profile one numeric capture, probe by probe.

    Parameters
    ----------
    out_dir : str
        Where the capture writes its file.  Must be outside the working
        tree (E35-2).

    Returns
    -------
    dict
        ``{probe: {'fams': [...], 'mods': [...]}}``.  ``fams`` is read
        from the keys the probe actually added to the recorder, not
        assumed from its name: a probe that stops emitting a family is
        then visible as an empty list rather than as a stale label.
    """
    global _hits
    for p in (SRC, TOOLS):
        if p not in sys.path:
            sys.path.insert(0, p)
    os.environ.setdefault("MPLBACKEND", "Agg")
    import numeric_fingerprint as NF

    result: Dict[str, Dict[str, Set[str]]] = {}

    def wrap(name: str) -> None:
        orig = getattr(NF, name)

        def inner(*a, **k):
            global _hits
            rec = a[0] if a and hasattr(a[0], "rows") else None
            before = set(rec.rows) if rec is not None else set()
            _hits = set()
            sys.setprofile(_profiler)
            try:
                return orig(*a, **k)
            finally:
                sys.setprofile(None)
                new = (set(rec.rows) - before) if rec is not None else set()
                fams = {key.split(".")[0].split("[")[0] for key in new}
                ent = result.setdefault(name, {"fams": set(), "mods": set()})
                ent["fams"].update(fams)
                ent["mods"].update(_hits)

        setattr(NF, name, inner)

    for probe in NUMERIC_PROBES:
        wrap(probe)
    NF.capture(os.path.join(out_dir, "evidence_numeric.txt"))
    return {k: {"fams": sorted(v["fams"]), "mods": sorted(v["mods"])}
            for k, v in result.items()}


def trace_whole(module_name: str, out_dir: str) -> List[str]:
    r"""
    Profile one capture as a whole, without per-probe attribution.

    Used for the datum and domain captures, whose families are few
    enough that per-probe attribution adds nothing: the question there
    is only *is this module entered at all*.

    Parameters
    ----------
    module_name : {'datum_fingerprint', 'domain_fingerprint'}
    out_dir : str

    Returns
    -------
    list of str
        Modules entered, sorted.
    """
    global _hits
    for p in (SRC, TOOLS):
        if p not in sys.path:
            sys.path.insert(0, p)
    mod = __import__(module_name)
    _hits = set()
    sys.setprofile(_profiler)
    try:
        mod.capture(os.path.join(out_dir, f"evidence_{module_name}.txt"))
    finally:
        sys.setprofile(None)
    return sorted(_hits)


#: The class attributes ``domain_fingerprint.capture`` reads.  An edit
#: to the module that *owns* one of them moves a domain key; an edit
#: anywhere else cannot.
_DOMAIN_ATTRS = ("DOMAIN", "DOMAIN_SOURCE", "QUANTITIES")


def domain_declaration_sites() -> Dict[str, List[str]]:
    r"""
    The modules whose edit can move a ``domain:<Class>`` key.

    Why this exists, and why the call trace cannot supply it
    -------------------------------------------------------
    :func:`domain_fingerprint.capture` does not *run* the providers: it
    reads ``DOMAIN``, ``DOMAIN_SOURCE`` and ``QUANTITIES`` off the
    classes by attribute access, and enumerates the classes out of
    :mod:`gensec.materials.rheology`'s namespace.  A class-attribute
    read raises no ``'call'`` event, so :func:`_profiler` records
    nothing for it — the profiler saw exactly one module for the whole
    domain capture, ``materials/base.py``, and only because
    ``check_vocabulary()`` is a method and therefore a call.

    Measured in Phase 37: on that evidence alone the cross-check
    refused ``materials/rheology.py``, which is the module the domain
    fingerprint exists for.  The rejection was an artefact of the
    instrument, not of the declaration.

    So for the domain families the evidence is collected structurally
    instead, and the structure is *stronger* than entry rather than
    weaker: the sites of a class are its own definition module — delete
    the class there and every key of that family disappears — together
    with every module in its MRO that **owns** one of the read
    attributes.  Inheriting an attribute is not owning it: a subclass
    that declares no ``DOMAIN`` of its own publishes its base's, and
    the base's module is where an edit would move it.

    Returns
    -------
    dict
        ``{class name: [module, ...]}``, paths relative to
        ``src/gensec``, sorted.  Classes defined outside the package
        contribute no site.

    Notes
    -----
    The class set is taken from ``domain_fingerprint._providers()``, so
    the evidence and the capture cannot drift apart: a provider added
    to one is seen by the other in the same run.
    """
    import inspect

    for p in (SRC, TOOLS):
        if p not in sys.path:
            sys.path.insert(0, p)
    import domain_fingerprint as DF

    def _rel(obj) -> str | None:
        try:
            fn = os.path.abspath(inspect.getfile(obj))
        except TypeError:                   # pragma: no cover — builtins
            return None
        if not fn.startswith(PKG + os.sep):
            return None
        return os.path.relpath(fn, PKG).replace(os.sep, "/")

    sites: Dict[str, Set[str]] = {}
    for name, cls in DF._providers():
        here = sites.setdefault(name, set())
        own = _rel(cls)
        if own is not None:
            here.add(own)
        for base in cls.__mro__:
            if any(a in base.__dict__ for a in _DOMAIN_ATTRS):
                mod = _rel(base)
                if mod is not None:
                    here.add(mod)
    return {k: sorted(v) for k, v in sorted(sites.items())}


def qualified_coverage(evidence: Dict) -> Dict[str, Set[str]]:
    r"""
    Fold the raw trace into ``{module: {qualified family, ...}}``.

    Example stems are folded into ``<capture>:examples``, the collective
    :mod:`observation_reasons` and ``observation_inventory`` both use.
    """
    stems = _example_stems()
    cover: Dict[str, Set[str]] = {}
    for _probe, v in evidence["numeric"].items():
        fams = {("numeric:examples" if f in stems else f"numeric:{f}")
                for f in v["fams"]}
        for m in v["mods"]:
            cover.setdefault(m, set()).update(fams)
    for kind in ("datum", "domain"):
        for m in evidence[kind]:
            cover.setdefault(m, set()).add(f"{kind}:*")
    return cover


def cross_check(evidence: Dict) -> int:
    r"""
    Refuse every declaration naming a family the trace never enters.

    Returns
    -------
    int
        ``0`` when every declared family is at least *reachable*,
        ``1`` otherwise.  A pass here does **not** assert that the
        families observe what the reasons claim; it asserts only that
        none of them is impossible.
    """
    if TOOLS not in sys.path:
        sys.path.insert(0, TOOLS)
    import observation_reasons as R

    if "domain_sites" not in evidence:
        print("this evidence file predates the structural domain "
              "evidence of Phase 37 and carries no 'domain_sites'.  "
              "Re-capture: the domain families cannot be checked "
              "against a call trace alone, and guessing them from the "
              "trace is the artefact this key was added to remove.")
        return 1

    cover = qualified_coverage(evidence)
    datum = set(evidence["datum"])
    domain = set(evidence["domain"])
    sites: Dict[str, Set[str]] = {k: set(v)
                                  for k, v in evidence["domain_sites"].items()}
    bad = 0
    for module, (fams, _reason) in sorted(R.OBSERVED.items()):
        entered = cover.get(module, set())
        for f in fams:
            if f.startswith("numeric:"):
                ok = f in entered
            elif f.startswith("datum:"):
                ok = module in datum
            elif f.startswith("domain:"):
                cls = f.split(":", 1)[1]
                if cls not in sites:
                    print(f"  NO SUCH PROVIDER  {module:32s} {f}")
                    bad += 1
                    continue
                #: A module counts if it owns part of the class's
                #: declaration, or if the capture entered it — the
                #: latter keeps ``check_vocabulary``'s home evidence.
                ok = module in sites[cls] or module in domain
            else:
                ok = module in domain
            if not ok:
                print(f"  NEVER ENTERED  {module:34s} {f}")
                bad += 1
    if bad:
        print(f"\n{bad} declaration(s) name a family that never enters "
              f"the module.  A family that does not run through a "
              f"module cannot observe it, whatever the reason says.")
        return 1
    print(f"  every family named by {len(R.OBSERVED)} observed "
          f"module(s) is reachable in the trace.")
    return 0


def main(argv=None) -> int:
    r"""CLI entry point.  Returns the process exit code."""
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--out", required=True,
                    help="where to write the evidence JSON")
    ap.add_argument("--check", action="store_true",
                    help="cross-read observation_reasons and refuse a "
                         "declaration naming an unreachable family")
    ap.add_argument("--load", default=None,
                    help="skip the captures and read an existing "
                         "evidence JSON (for --check alone)")
    args = ap.parse_args(argv)

    if args.load:
        with open(args.load, encoding="utf-8") as fh:
            evidence = json.load(fh)
    else:
        out_dir = os.path.dirname(os.path.abspath(args.out)) or "."
        evidence = {
            "numeric": trace_numeric(out_dir),
            "datum": trace_whole("datum_fingerprint", out_dir),
            "domain": trace_whole("domain_fingerprint", out_dir),
            "domain_sites": domain_declaration_sites(),
        }
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(evidence, fh, indent=1, sort_keys=True)
        print(f"evidence -> {args.out}")

    if args.check:
        return cross_check(evidence)
    return 0


if __name__ == "__main__":                               # pragma: no cover
    raise SystemExit(main())
