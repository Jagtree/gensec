# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
Inventory of the verification mechanism carried by every patcher.

Why this tool exists
--------------------
Ledger ``16_0`` section 6 records defect **N-6** as *"``--selfcheck`` is
vacuous on a transport-only patcher"* and concludes that *"every earlier
transport-only patcher has the same vacuous ``--selfcheck``"*.  That
conclusion was written without measuring the earlier patchers.  This
tool measures them.

The measurement is deliberately **structural, not lexical**: it imports
each patcher and inspects the objects it actually builds, rather than
grepping for the word ``selfcheck``.  A patcher that prints
``SELFCHECK PASS`` proves nothing about what it compared; what it
compared is visible only in the declared payload, sentinels and edits.

Mechanism taxonomy
------------------
Five distinct things are called a "selfcheck" across ``patchers/``, and
they carry very different guarantees:

``bytes``
    The patcher owns a ``PAYLOAD`` of verified file content and compares
    ``target.read_bytes()`` against it.  Detects every corruption mode,
    line endings included.
``sentinel``
    :meth:`_patchkit.Patcher._selfcheck`: substring presence/absence of
    ``require``/``retire`` markers.  Detects content loss at the marked
    sites only, and is **blind to line endings**, because
    :func:`_patchkit._read` normalises ``\r\n`` to ``\n`` before the
    comparison.
``sentinel_local``
    The same idea reimplemented inside a single patcher against a
    module-level ``REQUIRED`` list.
``bytes_wrapped``
    A ``sentinel`` patcher whose bound ``_selfcheck`` has been replaced
    at run time by a byte comparison (Phase 16's mitigation).
``none``
    No ``--selfcheck`` option at all.

Vacuity
-------
A selfcheck is **vacuous** when the number of things it compares is
zero.  For the ``sentinel`` mechanism that happens exactly when a
patcher declares no ``require`` and no ``retire`` -- which is the shape
a transport-only (``create``-only) patcher naturally has.  Vacuity is
therefore a property of the *declaration*, not of the mechanism, and is
reported as a separate column.

Usage
-----
``python tools/selfcheck_inventory.py``
    Print the inventory table.
``python tools/selfcheck_inventory.py --json``
    Emit the same data as JSON for downstream tools.
"""

from __future__ import annotations

import importlib.util
import io
import json
import os
import re
import sys
from contextlib import redirect_stdout, redirect_stderr
from typing import Dict, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PATCHERS = os.path.join(ROOT, "patchers")

#: Files in ``patchers/`` that are libraries, not runnable patchers.
_LIBRARIES = ("_patchkit.py",)


#: The patchers ``handoff/00_BOOTSTRAP.md`` section 4 prescribes as
#: green, i.e. the ones a session opener is told to run and to expect
#: exit 0 from.  Rule **F-B14**: only the most recent patcher is on
#: this list; every earlier one stays in the tree as history, not as a
#: gate.  Each phase that closes removes its predecessor, adds its own,
#: and records the measured reason for the new red in section 4.1.
#:
#: This constant is what :func:`gate` enforces, and it is the reason
#: the gate is meaningful: a list of everything would be a list of
#: nothing.
HEALTH_LIST = ("run_phase38_remove_block_and_annex.py",)


def _load(path: str):
    """
    Import a patcher module by path without executing ``__main__``.

    Parameters
    ----------
    path : str
        Absolute path to the ``.py`` file.

    Returns
    -------
    module or None
        ``None`` when the import itself raises, which is recorded
        rather than hidden.
    """
    name = "patcher_" + os.path.basename(path)[:-3]
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    if PATCHERS not in sys.path:
        sys.path.insert(0, PATCHERS)
    try:
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            spec.loader.exec_module(mod)
    except Exception:                                # pragma: no cover
        return None
    return mod


def _capture_patcher(mod):
    """
    Run a ``_patchkit``-based patcher in dry-run and capture its object.

    The ``Patcher`` instance is built inside ``main()``, so the only way
    to see its declarations is to intercept :meth:`Patcher.run`.

    Parameters
    ----------
    mod : module

    Returns
    -------
    _patchkit.Patcher or None
    """
    try:
        import _patchkit                              # noqa: F401
    except Exception:                                 # pragma: no cover
        return None
    captured: List[object] = []
    original = _patchkit.Patcher.run

    def _spy(self, argv=None):
        captured.append(self)
        return 0

    _patchkit.Patcher.run = _spy
    try:
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            # Two entry-point shapes exist in this tree: ``main(argv)``
            # and a bare ``build()`` that the ``__main__`` guard runs.
            builder = getattr(mod, "build", None)
            if builder is not None:
                try:
                    obj = builder()
                    if obj is not None and hasattr(obj, "_required"):
                        return obj
                except Exception:
                    pass
            main = getattr(mod, "main", None)
            if main is not None:
                try:
                    main(["--dry-run"])
                except TypeError:
                    try:
                        main()
                    except BaseException:
                        pass
                except BaseException:
                    pass
    finally:
        _patchkit.Patcher.run = original
    return captured[0] if captured else None


def classify(path: str) -> Dict[str, object]:
    """
    Classify one file in ``patchers/``.

    Parameters
    ----------
    path : str
        Absolute path to the candidate patcher.

    Returns
    -------
    dict
        Keys: ``name``, ``mechanism``, ``n_checked``, ``vacuous``,
        ``line_ending_aware``, ``files``, ``note``.
    """
    name = os.path.basename(path)
    with open(path, "rb") as fh:
        src = fh.read().decode("utf-8", "replace")

    out: Dict[str, object] = {
        "name": name, "mechanism": "none", "n_checked": 0,
        "n_bytes": 0,
        "vacuous": None, "line_ending_aware": None,
        "files": [], "note": "",
    }

    if name in _LIBRARIES:
        out["mechanism"] = "library"
        out["note"] = ("provides Patcher._selfcheck; not runnable as a "
                       "patcher")
        return out

    if "--selfcheck" not in src:
        # Zero byte comparisons, and not because the comparison found
        # nothing: because there is nothing to invoke.  This is the
        # bottom of the vacuity scale, not an exemption from it.
        out["vacuous"] = True
        out["note"] = "no --selfcheck option is offered"
        return out

    mod = _load(path)
    if mod is None:
        out["mechanism"] = "unimportable"
        out["note"] = "module raised on import; classified lexically only"
        return out

    payload = getattr(mod, "PAYLOAD", None)
    if isinstance(payload, dict) and payload:
        out["mechanism"] = "bytes"
        out["n_checked"] = len(payload)
        out["n_bytes"] = len(payload)
        out["vacuous"] = False
        out["line_ending_aware"] = True
        out["files"] = sorted(payload)
        out["note"] = "target.read_bytes() == want, over the whole payload"
        return out

    required = getattr(mod, "REQUIRED", None)
    if required:
        files = sorted({r[0] for r in required}) if isinstance(
            required[0], (tuple, list)) else []
        out["mechanism"] = "sentinel_local"
        out["n_checked"] = len(required)
        out["n_bytes"] = 0
        out["vacuous"] = True
        out["line_ending_aware"] = False
        out["files"] = files
        out["note"] = "module-level REQUIRED substring list"
        return out

    patch = _capture_patcher(mod)
    if patch is not None:
        n = len(patch._required) + len(patch._retired)
        wrapped = not hasattr(patch._selfcheck, "__self__")
        out["mechanism"] = "bytes_wrapped" if wrapped else "sentinel"
        out["n_checked"] = (
            len(getattr(patch, "_creates", [])) if wrapped else n)
        out["n_bytes"] = (
            len(getattr(patch, "_creates", [])) if wrapped else 0)
        out["vacuous"] = (out["n_bytes"] == 0)
        out["line_ending_aware"] = bool(wrapped)
        files = sorted({r for r, _ in patch._required}
                       | {r for r, _ in patch._retired}
                       | {c[0] for c in patch._creates})
        out["files"] = files
        out["note"] = (
            "bound _selfcheck replaced by a byte comparison over the "
            "transported files" if wrapped else
            f"_patchkit sentinels: {len(patch._required)} require, "
            f"{len(patch._retired)} retire; substring on newline-"
            f"normalised text")
        return out

    out["mechanism"] = "unclassified"
    out["note"] = "offers --selfcheck but no recognised declaration"
    return out


def inventory() -> List[Dict[str, object]]:
    """
    Classify every ``.py`` file in ``patchers/``.

    Returns
    -------
    list of dict
    """
    names = sorted(f for f in os.listdir(PATCHERS) if f.endswith(".py"))
    return [classify(os.path.join(PATCHERS, n)) for n in names]


def _latest_patcher() -> Optional[str]:
    r"""
    The highest-numbered phase patcher present in ``patchers/``.

    Parameters
    ----------
    None

    Returns
    -------
    str or None
        File name of the patcher whose ``run_phaseNN_`` prefix carries
        the largest ``NN``, or ``None`` when no file matches the
        convention.  Ties cannot arise: two patchers of the same phase
        would be a different defect, and the sort is then by name so the
        result stays deterministic rather than accidental.

    Notes
    -----
    The phase number is read from the file **name**, not from the
    modification time.  A patcher transported by a payload takes the
    mtime of the moment it was written, so ordering by time would call
    whichever file the patcher wrote last the most recent one.
    """
    best: Optional[Tuple[int, str]] = None
    for name in sorted(os.listdir(PATCHERS)):
        m = re.match(r"run_phase(\d+)_", name)
        if not name.endswith(".py") or m is None:
            continue
        key = (int(m.group(1)), name)
        if best is None or key > best:
            best = key
    return None if best is None else best[1]


def _run_selfcheck(name: str):
    r"""
    Execute one patcher's ``--selfcheck`` and read its exit code **from
    the process**.

    The exit code is taken from :func:`subprocess.run`'s ``returncode``,
    never from a pipeline: ``cmd | tail; echo $?`` reads ``tail``'s
    status, which is a mistake this project has made in a command whose
    only purpose was to read an exit code (``30_0`` §3, E30-9).  A tool
    that answers the question is the remedy; a rule that should have
    been remembered is not.

    Parameters
    ----------
    name : str
        File name of the patcher inside ``patchers/``.

    Returns
    -------
    tuple
        ``(returncode, last_line)``.  ``returncode`` is ``None`` when
        the process could not be started at all, in which case
        ``last_line`` carries the reason.
    """
    import subprocess
    path = os.path.join(PATCHERS, name)
    try:
        proc = subprocess.run(
            [sys.executable, path, "--selfcheck"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=300, check=False)
    except Exception as exc:                # noqa: BLE001 -- reported
        return None, f"{type(exc).__name__}: {exc}"
    out = proc.stdout.decode("utf-8", "replace").strip().splitlines()
    return proc.returncode, (out[-1].strip() if out else "(no output)")


def gate(run_selfcheck: bool = False) -> int:
    """
    Refuse a health list that contains a patcher verifying zero bytes.

    Why this gate exists
    --------------------
    ``handoff/00_BOOTSTRAP.md`` section 4.2 states the rule: a
    ``SELFCHECK PASS`` that does not declare **how many files it
    compared** is not a verification.  Six patchers in this tree
    satisfy that description today, and five of them
    (``p03a_part1`` ... ``p03a_part5``) print nothing at all under
    ``--selfcheck`` while exiting 0.

    Those six are history and are deliberately **not** repaired: rule
    F-B14 keeps only the most recent patcher on the health list, so an
    old patcher's vacuous PASS is never read as a health signal.  What
    this gate prevents is the future case -- a patcher entering
    :data:`HEALTH_LIST` while its ``--selfcheck`` compares nothing, so
    that a session opener is instructed to read a green that means
    nothing.

    The second obligation, added in Phase 30
    ----------------------------------------
    The list must also name the **current** patcher.  Phase 30 closed
    with ``HEALTH_LIST`` still naming the Phase-29 patcher, whose
    ``--selfcheck`` by then exited 1 because nine of the files it
    transported had changed.  This gate was green throughout: the
    Phase-29 patcher does declare byte comparisons, so the only
    obligation the gate carried was satisfied.  A session opener
    following ``00_BOOTSTRAP.md`` would have been sent to a red patcher
    by a green gate.

    Nor could the byte-identical rebuild catch it, and that is worth
    stating: a rebuild proves the payload transports everything that
    **was** changed, never that everything that **should have been**
    changed was.  It compares the tree with a copy of itself, stale
    list included.

    Returns
    -------
    int
        ``0`` when every patcher on :data:`HEALTH_LIST` declares at
        least one byte comparison; ``1`` otherwise.

    Notes
    -----
    "Byte comparison" is counted from the patcher's own declaration,
    not from the word ``selfcheck`` in its source: a ``PAYLOAD``
    entry, or a transported file behind a wrapped ``_selfcheck``.
    Sentinel ``require`` / ``retire`` markers count **zero**.  They
    are a real check, but a substring check on newline-normalised
    text, so they are blind to line endings and to every byte the
    marker does not name -- which is exactly the difference the rule
    in section 4.2 is drawing.
    """
    rows = {str(r["name"]): r for r in inventory()}
    failures: List[str] = []
    print(f"health list ({len(HEALTH_LIST)} patcher(s)): "
          f"{', '.join(HEALTH_LIST)}")

    latest = _latest_patcher()
    if latest is None:
        failures.append(
            "NO PATCHER: patchers/ contains no run_phaseNN_*.py; the "
            "health list cannot be checked against a current patcher")
    elif latest not in HEALTH_LIST:
        failures.append(
            f"STALE {latest}: it is the highest-numbered patcher in "
            f"patchers/ but is absent from HEALTH_LIST, which names "
            f"{', '.join(HEALTH_LIST)}.  Rule F-B14 keeps the current "
            f"patcher on the list; a list naming only older ones sends "
            f"a session opener to a selfcheck that is expected to be "
            f"red")
    else:
        print(f"  ok  {latest:<32} {'currency':<14} "
              f"highest-numbered patcher is on the list")
    for name in HEALTH_LIST:
        row = rows.get(name)
        if row is None:
            failures.append(
                f"ABSENT {name}: named in HEALTH_LIST but not present "
                f"in patchers/")
            continue
        n_bytes = int(row["n_bytes"])
        mech = str(row["mechanism"])
        if n_bytes == 0:
            failures.append(
                f"VACUOUS {name}: mechanism {mech!r} declares 0 byte "
                f"comparison(s); a PASS from it would assert nothing")
        else:
            print(f"  ok  {name:<32} {mech:<14} "
                  f"{n_bytes} byte comparison(s)")
    if run_selfcheck:
        for name in HEALTH_LIST:
            if rows.get(name) is None:
                continue                     # already reported ABSENT
            code, tail = _run_selfcheck(name)
            if code is None:
                failures.append(
                    f"UNRUNNABLE {name}: its --selfcheck could not be "
                    f"executed ({tail})")
            elif code != 0:
                failures.append(
                    f"RED {name}: it is on the health list and its "
                    f"--selfcheck exits {code}.  Last line: {tail!r}.  "
                    f"On a delivered archive this is a payload that no "
                    f"longer matches the tree it transports; MID-PHASE "
                    f"IT IS EXPECTED, because the phase has changed "
                    f"files the previous payload carries -- use "
                    f"'--gate' there, which checks the declaration and "
                    f"not the run")
            else:
                print(f"  ok  {name:<32} {'run':<14} "
                      f"--selfcheck exits 0 ({tail})")
    if failures:
        for line in failures:
            print(f"  {line}")
        print(f"\ngate: REFUSED — {len(failures)} finding(s) on the "
              f"health list.")
        return 1
    if run_selfcheck:
        print(f"\ngate: every patcher on the health list declares at "
              f"least one byte comparison, AND its --selfcheck was run "
              f"and exits 0.")
    else:
        print(f"\ngate: every patcher on the health list declares at "
              f"least one byte comparison.  The run itself is NOT "
              f"checked here; '--gate-archive' checks it.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """
    Command-line entry point.

    Returns
    -------
    int
        ``0`` from the plain inventory and from ``--json``; the verdict
        of :func:`gate` under ``--gate`` and under
        ``--gate-archive``, which additionally RUNS each
        listed patcher's ``--selfcheck``.
    """
    argv = list(sys.argv[1:] if argv is None else argv)
    if "--gate-archive" in argv:
        return gate(run_selfcheck=True)
    if "--gate" in argv:
        return gate()
    rows = inventory()
    if "--json" in argv:
        print(json.dumps(rows, indent=2))
        return 0

    print(f"{'patcher':<32} {'mechanism':<15} {'n':>4} {'bytes':>6} "
          f"{'vacuous':>8} {'LE-aware':>9}")
    print("-" * 79)
    for r in rows:
        vac = ("-" if r["vacuous"] is None
               else ("YES" if r["vacuous"] else "no"))
        le = ("-" if r["line_ending_aware"] is None
              else ("yes" if r["line_ending_aware"] else "NO"))
        print(f"{r['name']:<32} {r['mechanism']:<15} {r['n_checked']:>4} "
              f"{r['n_bytes']:>6} {vac:>8} {le:>9}")
    print("-" * 79)
    by_mech: Dict[str, int] = {}
    for r in rows:
        by_mech[str(r["mechanism"])] = by_mech.get(str(r["mechanism"]), 0) + 1
    print("  " + ", ".join(f"{k}: {v}" for k, v in sorted(by_mech.items())))
    vacuous = [r["name"] for r in rows if r["vacuous"]]
    blind = [r["name"] for r in rows
             if r["line_ending_aware"] is False]
    print(f"  verify zero bytes: {len(vacuous)}  {vacuous}")
    print(f"  line-ending blind: {len(blind)}  {blind}")
    print(f"  on health list   : {len(HEALTH_LIST)}  {list(HEALTH_LIST)}")
    return 0


if __name__ == "__main__":                            # pragma: no cover
    raise SystemExit(main())
# GENSEC-COMPLETE phase=38 utc=2026-09-11T16:04:37Z sha256=9ce5065cbf6dc3017b9857b623b13c897a3d0b55dfd16b6cafd98c12eec7c737 body_lines=555
