#!/usr/bin/env python3
r"""
Generate ``patchers/run_phase20_axial.py`` from the tested tree.

The generator reads the files Phase 20 moved **from disk, as bytes**,
measures each one's line-ending convention at byte level **once**, and
emits a standalone patcher carrying the verified content.  The emitted
patcher's machinery (``_looks_like_root``, ``_verified``, ``_kind``,
``_write_route``, ``_commit``, ``main``) is lifted verbatim from
``run_phase19_hull.py``, so N-10's all-or-nothing commit travels
unchanged instead of being retyped.

``measure_line_ending`` refuses to emit a mixed file rather than
declaring one convention for it.  That behaviour is taken from
``make_phase19_patcher.py``, which is kept in the tree as provenance:
a lone ``\r`` is an error, not a line ending, and a file that mixes
CRLF and LF cannot be transported under a single declaration.
"""

from __future__ import annotations

import base64
import hashlib
import textwrap
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase19_hull.py"
OUT = ROOT / "patchers" / "run_phase20_axial.py"

#: The payload, in the order a reader should meet it: the repair, the
#: instruments, the gates' own records, the fixtures, the example, the
#: documents.  Completeness is **measured** after generation by
#: comparing the tree this produces against the tree the suite ran
#: green on -- never assumed.
FILES = [
    "src/gensec/solver/integrator.py",
    "tools/numeric_fingerprint.py",
    "tools/getattr_inventory.py",
    "tools/getattr_reasons.py",
    "tools/element_class_inventory.py",
    "tools/element_class_reasons.py",
    "tools/selfcheck_inventory.py",
    "tests/test_phase19_hull.py",
    "tests/test_phase20_axial.py",
    "examples/example_strand_only_slab.yaml",
    "handoff/00_BOOTSTRAP.md",
    "handoff/20_0-GENSEC_LEDGER_20.md",
    "handoff/20_1-GENSEC_PHASE20_RECAP.md",
]

DOCSTRING = r'''r"""
GenSec Phase 20 — N-17 closed as a named refusal, the axial path made
visible, and a reason owed for every substituting ``getattr``.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64``
of exactly what was on disk in the tree the Phase 20 suite ran green
on, line endings included.

* ``src/gensec/solver/integrator.py`` — **N-17**.  Phase 19 measured
  that ``solve_equilibrium`` returns ``converged = False`` for a
  pure-tension target near a strand-only section's axial capacity, and
  left the item open because it had not measured whether the state
  exists.  Phase 20 measured that: on the 1200x200 slab the largest
  axial force compatible with ``|Mx| <= M_tol`` is **317 016.36 N**,
  30.0 % of the 1 056 673.4679 N target, and on the locus
  ``N = target`` the smallest ``|Mx|`` is **6.340041e+07 N.mm**, which
  is ``T * e`` exactly -- a plateau, not a minimum.  The state does not
  exist, so the closure is a refusal that names the reason and not a
  repair.  ``solve_equilibrium`` now labels one of five outcomes and
  carries the residual, the tolerance and the scan resolution with the
  verdict; ``require_equilibrium`` is the opt-in that raises, kept
  separate because a solver that raised would abort a whole diagram on
  one unattainable point;
* ``tools/numeric_fingerprint.py`` — the instrument extended **before**
  the repair.  ``axial.*`` records an integer entry count, two boolean
  verdicts and a **string** reason, because a non-convergence that
  gains a cause moves no number at all: measured, zero numbers move at
  12, 15, 16 or 17 significant digits, so a battery of numbers alone
  would read this whole phase as ``INERT``;
* ``tools/getattr_inventory.py`` and ``tools/getattr_reasons.py`` — a
  reason per substituting site, on the model of the element-class gate.
  28 of 125 sites read line by line; the other 97 on a register that
  carries a **count per module**, so a module already in debt cannot
  hide a new site behind the old one.  Seen exiting 1 on three
  corruptions before being shipped green;
* ``tools/element_class_inventory.py`` and
  ``tools/element_class_reasons.py`` — the archive rule: a reason whose
  site stops being partial is **moved** to ``REPAIRED`` with the phase
  that repaired it, never deleted and never left in ``REASONS``.  The
  gate enforces the move;
* ``tools/selfcheck_inventory.py`` — ``HEALTH_LIST`` updated to this
  patcher (F-B14);
* ``tests/test_phase20_axial.py`` — eleven fixtures in four classes,
  separated by standing: the measurement (guard, green on both trees),
  the three discriminating tests (red on the pristine tree, all three
  ``AssertionError``, zero ``ImportError``, zero ``AttributeError``),
  the distribution check, and the strict-form contract, which names
  Phase 20 symbols and is declared as contract rather than evidence;
* ``tests/test_phase19_hull.py`` — one Phase 19 fixture read
  ``outer["converged"]`` inside its own failure message.  The outer
  outcome is now captured as either a mapping or a refusal, so the
  claim it makes about ``_solve_pure_axial`` does not become sensitive
  to how its caller reports an unrelated fact;
* ``examples/example_strand_only_slab.yaml`` — the first distributed
  model with strands and **no** ordinary reinforcement, so that this
  corridor is reachable from the battery and not only from a fixture;
* ``handoff/00_BOOTSTRAP.md`` with section 4.1 **re-measured in full**,
  and the ledger and recap.

Completeness of this payload was **measured**, not assumed: the tree it
produces from a pristine Phase 19 checkout is compared file by file
against the tree the suite ran green on, and what stays outside is
listed with its reason in ``handoff/20_1``.

Usage
-----
::

    python3 patchers/run_phase20_axial.py --selfcheck
    python3 patchers/run_phase20_axial.py --repair
"""'''


def measure_line_ending(data: bytes) -> str:
    r"""
    The line-ending convention of *data*, measured at byte level.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
        ``'CRLF'``, ``'LF'``, or ``'none'`` for a file with no line
        break at all.

    Raises
    ------
    ValueError
        If the file mixes conventions or carries a lone ``\r``.  A
        mixed file cannot be transported with a single declaration,
        and declaring one anyway is the failure mode this measurement
        exists to prevent.
    """
    crlf = data.count(b"\r\n")
    bare_lf = data.count(b"\n") - crlf
    bare_cr = data.count(b"\r") - crlf
    if bare_cr:
        raise ValueError(f"lone CR present: {bare_cr}")
    if crlf and bare_lf:
        raise ValueError(f"mixed: {crlf} CRLF and {bare_lf} bare LF")
    if crlf:
        return "CRLF"
    if bare_lf:
        return "LF"
    return "none"


def encode(data: bytes) -> str:
    r"""
    ``zlib`` + ``base64``, wrapped as a Python implicit concatenation.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
    """
    blob = base64.b64encode(zlib.compress(data, 9)).decode("ascii")
    chunks = textwrap.wrap(blob, 100)
    return "\n".join(f'        "{c}"' for c in chunks)


def main() -> int:
    r"""
    Emit the Phase 20 patcher.

    Returns
    -------
    int
        ``0`` on success, ``2`` when a payload file is missing.
    """
    src = SRC.read_text(encoding="utf-8")
    machinery = src[src.index("def _looks_like_root(root):"):
                    src.index("def main(argv=None):")]
    tail = src[src.index("def main(argv=None):"):]
    tail = tail.replace("Phase 19", "Phase 20")
    tail = tail.replace(
        '    print("GenSec Phase 19 patcher — the scan hull, the axial "\n'
        '          "bracket, the gate on vacuous selfchecks")',
        '    print("GenSec Phase 20 patcher — N-17 as a named refusal, "\n'
        '          "the axial path, a reason per substituting getattr")')

    payload, digests, endings = [], [], []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"MISSING {rel}")
            return 2
        data = path.read_bytes()
        le = measure_line_ending(data)
        payload.append(f'    "{rel}":\n{encode(data)},')
        digests.append(
            f'    "{rel}":\n        "{hashlib.sha256(data).hexdigest()}",')
        endings.append(f'    "{rel}": "{le}",')
        print(f"  {rel:<46} {len(data):>8} bytes  {le}")

    out = [
        DOCSTRING,
        "\nfrom __future__ import annotations\n",
        "import base64",
        "import hashlib",
        "import os",
        "import sys",
        "import zlib",
        "from pathlib import Path\n",
        "ROOT = Path(__file__).resolve().parent.parent\n",
        "#: ``{relative path: zlib+base64 of the verified bytes}``.",
        "PAYLOAD = {",
        "\n".join(payload),
        "}\n",
        "#: ``{relative path: sha256 of the verified bytes}``.",
        "DIGESTS = {",
        "\n".join(digests),
        "}\n",
        "#: ``{relative path: line-ending convention as MEASURED, at byte",
        "#: level, once, before generating}``.  Recorded so a reader can",
        "#: check the transport without decoding it.  No file in this",
        "#: payload is mixed; the generator refuses to emit one that is.",
        "LINE_ENDINGS = {",
        "\n".join(endings),
        "}\n\n",
        machinery,
        tail,
    ]
    OUT.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"\nwrote {OUT} ({OUT.stat().st_size} bytes), "
          f"{len(FILES)} file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
