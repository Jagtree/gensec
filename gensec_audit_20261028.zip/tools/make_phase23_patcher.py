#!/usr/bin/env python3
r"""
Generate ``patchers/run_phase21_codes.py`` from the tested tree.

The generator reads the files Phase 21 moved **from disk, as bytes**,
measures each one's line-ending convention at byte level **once**, and
emits a standalone patcher carrying the verified content.  The emitted
patcher's machinery (``_looks_like_root``, ``_verified``, ``_kind``,
``_write_route``, ``_commit``, ``main``) is lifted verbatim from
``run_phase19_hull.py``, so N-10's all-or-nothing commit travels
unchanged instead of being retyped.

``measure_line_ending`` refuses to emit a mixed file rather than
declaring one convention for it.  That behaviour is taken from
``make_phase20_patcher.py``, which is kept in the tree as provenance:
a lone ``\r`` is an error, not a line ending, and a file that mixes
CRLF and LF cannot be transported under a single declaration.
"""

from __future__ import annotations

import base64
import hashlib
import textwrap
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "patchers" / "run_phase22_staged.py"
OUT = ROOT / "patchers" / "run_phase23_declared_reduction.py"

#: The payload, in the order a reader should meet it: the repair, the
#: instruments, the gates' own records, the fixtures, the example, the
#: documents.  Completeness is **measured** after generation by
#: comparing the tree this produces against the tree the suite ran
#: green on -- never assumed.
FILES = [
    "docs/construction_timeline.rst",
    "examples/P60-60_1_update.yaml",
    "examples/example_aci318.yaml",
    "examples/example_composite_losses.yaml",
    "examples/example_composite_losses_fb_gap.yaml",
    "examples/example_composite_timeline.yaml",
    "examples/example_custom.yaml",
    "examples/example_input.yaml",
    "examples/test_exotic.yaml",
    "examples/yaml_reference_example.yaml",
    "src/gensec/io_yaml.py",
    "src/gensec/materials/concrete.py",
    "src/gensec/materials/ec2_bridge.py",
    "tests/run_bulk_prestrain_validation_new.py",
    "tests/run_material_identity_falsification.py",
    "tests/run_p01_digest_validation.py",
    "tests/run_p02_modulus_validation.py",
    "tests/run_phase3_validation.py",
    "tests/run_phase7_sls_validation.py",
    "tests/run_phase8_task1_validation.py",
    "tests/run_posttension_sequence_validation.py",
    "tests/test_analysis.py",
    "tests/test_capacity_v2.py",
    "tests/test_check.py",
    "tests/test_infrastructure.py",
    "tests/test_materials.py",
    "tests/test_phase12_p2.py",
    "tests/test_phase12_p3_closure.py",
    "tests/test_phase12_p3_red.py",
    "tests/test_phase13_dump.py",
    "tests/test_phase14_cracking.py",
    "tests/test_phase15_mechanical_strain.py",
    "tests/test_phase21_codes.py",
    "tests/test_phase23_declared_reduction.py",
    "tests/test_phase7_sls.py",
    "tests/test_phase8_task1.py",
    "tests/test_section_state.py",
    "tests/test_solver_biaxial.py",
    "tests/test_solver_uniaxial.py",
    "tests/test_v030_regressions.py",
    "tests/test_validate_prestress_phase1.py",
    # The instrument, extended BEFORE the repair.  It is absent
    # from a diff of the working tree against the bundle only
    # because the PRE capture had to be taken with the extended
    # tool on a pristine checkout, which left the two copies
    # identical.  Listing it by hand is the remedy; the check
    # that caught the omission is the tree comparison after a
    # --repair onto a fresh clone, which is why that check is
    # not optional.
    "tools/numeric_fingerprint.py",
    "tools/make_phase23_patcher.py",
    # F-B14: the health list names the most recent patcher and
    # only that one, so this file changes every phase and must
    # travel with the phase that changed it.
    "tools/selfcheck_inventory.py",
    # I documenti di consegna e la procedura d'apertura.  Un albero
    # ricostruito dal patcher senza di loro sarebbe verde e muto.
    "handoff/00_BOOTSTRAP.md",
    "handoff/23_0-GENSEC_LEDGER_23.md",
    "handoff/23_1-GENSEC_PHASE23_RECAP.md",
    # Le impronte: la PRE su albero pristino con lo strumento
    # esteso, e le tre POST.  Il confronto e' riproducibile solo
    # se viaggiano con il patcher.
    ".fingerprints/23_00_numeric_PRE.txt",
    ".fingerprints/23_01_numeric_POST.txt",
    ".fingerprints/23_01_datum_POST.txt",
    ".fingerprints/23_01_domain_POST.txt",
]




DOCSTRING = r'''r"""
GenSec Phase 21 — F-P21-1: the input declares the normative code, and
everything code-dependent is derived from it.

What this transports
--------------------
Each file is carried as its **verified bytes**: ``zlib`` + ``base64``
of exactly what was on disk in the tree the Phase 21 suite ran green
on, line endings included.

The rule, which the project always stated and never wired: *the input
declares the code, and everything is derived from it; or the input
declares that the material is custom, and then GenSec derives
nothing.*  There is no third option and in particular no implicit one.

* ``src/gensec/materials/codes.py`` — **new**.  The registry of
  ``NormativeCode``: ``ec2``, ``ntc18`` (a subclass of the Eurocode,
  because §11.2.10.3 adopts its formulation so the value coincides and
  only the citation differs), ``aci318-19``, ``custom`` and
  ``undeclared``.  Plus ``CodeReferenceModulus``, the genuinely
  agnostic rule: it derives nothing and asks the code stamped on each
  material, so one model can mix a precast beam under EN 1992-1-1 with
  a topping under ACI 318-19;
* ``src/gensec/materials/base.py`` — ``NormativeChoiceNotDeclared``,
  beside ``OutOfDeclaredDomain`` in the scope-boundary half of the
  exception taxonomy.  A ``NotImplementedError``, so the resolver's
  existing ``except`` catches it and a Eurocode build sees nothing;
* ``src/gensec/materials/concrete.py`` — the material no longer
  derives its own modulus.  Measured: it returned EN 1992-1-1's
  35 220.5 MPa for a ``Concrete(fck=40)`` that named no code, and an
  ACI rule installed by the caller **lost to it** — 35 220.5 instead
  of 29 725.4.  A default that cannot be overridden is not a default;
* ``src/gensec/io_yaml.py`` — the loader reads ``code:`` at the top
  level and per material, and stamps the resolved ``NormativeCode``
  on every material at one application point rather than one per
  ``return``.  A material type that names a code counts as a
  declaration, which is why no existing input file changes;
* ``src/gensec/solver/timeline.py`` — ``code=`` on the timeline, read
  by ``from_document`` from the one home for top-level keys;
* ``examples/example_aci318.yaml`` — the first distributed model that
  is **not** a Eurocode model.  Until now they all were, so a
  container that had quietly become Eurocode-shaped would have looked
  identical from outside;
* the two inventories, their reason tables and the baseline — both
  gates went red on their own against this phase's code and the
  archive rule decided in Phase 20 applied unchanged;
* ``tests/test_phase21_codes.py`` (six discriminating reds on the
  pristine Phase 20 tree, zero ``ImportError``, zero
  ``AttributeError``) and ``tests/test_phase12_p3_closure.py``, two of
  whose tests pinned the defect and were rewritten.

Measured: **0 numbers move** on all three fingerprints; the 152 new
numeric keys are the ACI example and are ``ADDED``.  Nothing an EC2
build could reach has been taken away.

Usage
-----
::

    python3 patchers/run_phase21_codes.py --selfcheck
    python3 patchers/run_phase21_codes.py --repair
"""'''


def measure_line_ending(data: bytes) -> str:
    r"""
    The line-ending convention of *data*, measured at byte level.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
        ``'CRLF'``, ``'LF'``, or ``'none'`` for a file with no line
        break at all.

    Raises
    ------
    ValueError
        If the file mixes conventions or carries a lone ``\r``.  A
        mixed file cannot be transported with a single declaration,
        and declaring one anyway is the failure mode this measurement
        exists to prevent.
    """
    crlf = data.count(b"\r\n")
    bare_lf = data.count(b"\n") - crlf
    bare_cr = data.count(b"\r") - crlf
    if bare_cr:
        raise ValueError(f"lone CR present: {bare_cr}")
    if crlf and bare_lf:
        raise ValueError(f"mixed: {crlf} CRLF and {bare_lf} bare LF")
    if crlf:
        return "CRLF"
    if bare_lf:
        return "LF"
    return "none"


def encode(data: bytes) -> str:
    r"""
    ``zlib`` + ``base64``, wrapped as a Python implicit concatenation.

    Parameters
    ----------
    data : bytes

    Returns
    -------
    str
    """
    blob = base64.b64encode(zlib.compress(data, 9)).decode("ascii")
    chunks = textwrap.wrap(blob, 100)
    return "\n".join(f'        "{c}"' for c in chunks)


RESOLVER = r'''
#: Payload paths whose real location differs between the closed
#: archive and a full checkout, mapped to the candidates to resolve
#: against, most specific first.
#:
#: The archive carries ``docs/`` flattened -- it holds
#: ``docs/construction_timeline.rst`` -- while a full checkout keeps
#: the narrative pages under ``docs/theory/``.  Writing the payload
#: path blindly would create a second copy at the flat path and leave
#: the page the toctree actually resolves untouched: green selfcheck,
#: stale document.  Measured in Phase 23 and confirmed by Andrea.
PATH_ALIASES = {
    "docs/construction_timeline.rst": (
        "docs/theory/construction_timeline.rst",
        "docs/construction_timeline.rst",
    ),
}


def _resolve(rel):
    """
    The path in *this* tree that a payload entry refers to.

    Uniqueness is enforced, not assumed.  A tree that carries the file
    at more than one candidate path is ambiguous, and a patcher that
    picked one would silently update a copy and leave the other behind;
    a tree that carries it at none is not the tree this payload was
    built against.  Both abort before anything is written.

    Parameters
    ----------
    rel : str
        Payload-relative path as recorded in :data:`PAYLOAD`.

    Returns
    -------
    str
        The path to read and write, relative to :data:`ROOT`.

    Raises
    ------
    RuntimeError
        When zero or more than one candidate exists.
    """
    candidates = PATH_ALIASES.get(rel)
    if candidates is None:
        return rel
    found = [c for c in candidates if (ROOT / c).exists()]
    if len(found) == 1:
        return found[0]
    if not found:
        raise RuntimeError(
            f"ATOMIC ABORT: nothing written. {rel!r} resolves to none "
            f"of {list(candidates)} in this tree. The payload was built "
            f"against a tree that carries it; create the file at the "
            f"intended path first, or correct PATH_ALIASES.")
    raise RuntimeError(
        f"ATOMIC ABORT: nothing written. {rel!r} resolves to "
        f"{len(found)} paths at once -- {found}. Writing either one "
        f"would leave the other stale. Delete the copy that is not the "
        f"one the documentation build reads, then re-run.")
'''


def main() -> int:
    r"""
    Emit the Phase 21 patcher.

    Returns
    -------
    int
        ``0`` on success, ``2`` when a payload file is missing.
    """
    src = SRC.read_text(encoding="utf-8")
    machinery = src[src.index("def _looks_like_root(root):"):
                    src.index("def main(argv=None):")]
    tail = src[src.index("def main(argv=None):"):]
    tail = tail.replace("Phase 22", "Phase 23")
    # Every touch of the tree goes through _resolve, so a payload path
    # and the path it means can differ.  Three call sites, each
    # asserted unique: reading for comparison, and the two writes.
    for old_line, new_line in (
            ("        target = ROOT / rel\n",
             "        target = ROOT / _resolve(rel)\n"),
            ("    problems = _commit([(ROOT / rel, want)\n",
             "    problems = _commit([(ROOT / _resolve(rel), want)\n"),
            ("    bad = [rel for rel, want in content.items()\n"
             "           if (ROOT / rel).read_bytes() != want]\n",
             "    bad = [rel for rel, want in content.items()\n"
             "           if (ROOT / _resolve(rel)).read_bytes() != want]\n"),
    ):
        if tail.count(old_line) != 1:
            print(f"ABORT: {tail.count(old_line)} occurrences of a "
                  f"path-resolution site expected exactly once:\n"
                  f"  {old_line!r}")
            return 2
        tail = tail.replace(old_line, new_line, 1)
    # The resolver can refuse, and the refusal must abort the run
    # rather than escape as a traceback.
    old_guard = "    same, differ, absent = [], [], []\n"
    if tail.count(old_guard) != 1:
        print("ABORT: the comparison loop preamble is not unique.")
        return 2
    tail = tail.replace(old_guard,
                        "    try:\n"
                        "        for _rel in sorted(PAYLOAD):\n"
                        "            _resolve(_rel)\n"
                        "    except RuntimeError as exc:\n"
                        "        print(f\"ABORT — {exc}\")\n"
                        "        return 2\n"
                        "\n"
                        "    same, differ, absent = [], [], []\n", 1)
    # The source banner is a multi-line print: every continuation line
    # must go with it.  Matching only the first line leaves an orphan
    # string literal behind, which is a syntax error in the emitted
    # patcher -- measured, not hypothesised: the first generation of
    # this file produced exactly that and would not import.
    lines = tail.splitlines(keepends=True)
    starts = [i for i, ln in enumerate(lines)
              if 'print("GenSec Phase' in ln]
    if len(starts) != 1:
        print(f"ABORT: {len(starts)} banner lines in the source "
              f"patcher; expected exactly one to rewrite.")
        return 2
    i = starts[0]
    j = i
    while j < len(lines) and not lines[j].rstrip().endswith(")"):
        j += 1
    banner_old = "".join(lines[i:j + 1])
    tail = tail.replace(
        banner_old,
        '    print("GenSec Phase 23 patcher \u2014 the declared design "\n'
        '          "strength: no normative constant is invented by the "\n'
        '          "container")\n')

    payload, digests, endings = [], [], []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            print(f"MISSING {rel}")
            return 2
        data = path.read_bytes()
        le = measure_line_ending(data)
        payload.append(f'    "{rel}":\n{encode(data)},')
        digests.append(
            f'    "{rel}":\n        "{hashlib.sha256(data).hexdigest()}",')
        endings.append(f'    "{rel}": "{le}",')
        print(f"  {rel:<46} {len(data):>8} bytes  {le}")

    out = [
        DOCSTRING,
        "\nfrom __future__ import annotations\n",
        "import base64",
        "import hashlib",
        "import os",
        "import sys",
        "import zlib",
        "from pathlib import Path\n",
        "ROOT = Path(__file__).resolve().parent.parent\n",
        RESOLVER,
        "#: ``{relative path: zlib+base64 of the verified bytes}``.",
        "PAYLOAD = {",
        "\n".join(payload),
        "}\n",
        "#: ``{relative path: sha256 of the verified bytes}``.",
        "DIGESTS = {",
        "\n".join(digests),
        "}\n",
        "#: ``{relative path: line-ending convention as MEASURED, at byte",
        "#: level, once, before generating}``.  Recorded so a reader can",
        "#: check the transport without decoding it.  No file in this",
        "#: payload is mixed; the generator refuses to emit one that is.",
        "LINE_ENDINGS = {",
        "\n".join(endings),
        "}\n\n",
        machinery,
        tail,
    ]
    OUT.write_text("\n".join(out), encoding="utf-8", newline="\n")
    print(f"\nwrote {OUT} ({OUT.stat().st_size} bytes), "
          f"{len(FILES)} file(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
