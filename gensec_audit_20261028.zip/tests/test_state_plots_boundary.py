#!/usr/bin/env python3
# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
r"""
``gensec run`` no longer ends without a ``state_*.png``, and never silently.

The defect, as measured
-----------------------
``gensec run`` selects the ``fiber_details_top_k`` demands with the
highest governing :math:`\eta` and then solves for the strain plane at
each.  A demand outside the resistance domain has no such plane, and it
ranks first.  With :math:`k` or more of them the selection held no
demand that could be plotted: measured on a section with one verified
demand and five outside it, ``state_*.png`` count **0**, and one line
``SOLVER DID NOT CONVERGE`` per demand.

What is asserted
----------------
1. The geometric primitive (:math:`\mathbf{R} = \mathbf{T}/\eta`) on a
   hull whose exit points are known in closed form.
2. Its refusals: an origin outside the hull, a demand at the origin.
3. The three outcomes of ``export_demand_state_plots`` -- state at the
   demand, state at the boundary, nothing -- each with its files and
   its message, and the ``"none"`` path driven by stubs so that it is
   exercised deliberately and not by luck of a section.
4. End to end through ``gensec.cli``: the original failing configuration
   now writes one ``state_*`` per selected demand.
"""
import os

import numpy as np
import pytest
import yaml

from gensec.io_yaml import load_yaml
from gensec.output.state_plots import export_demand_state_plots
from gensec.output.summary import select_demands_for_fiber_details
from gensec.solver import FiberSolver, NMDiagram
from gensec.solver.check import DomainChecker, VerificationEngine


# ----------------------------------------------------------------------
#  Closed-form hulls
# ----------------------------------------------------------------------

def _box(n_lo, n_hi, mx, my):
    """Corners of the box ``[n_lo, n_hi] x [-mx, mx] x [-my, my]``."""
    pts = [(n, sx * mx, sy * my)
           for n in (n_lo, n_hi) for sx in (-1, 1) for sy in (-1, 1)]
    a = np.array(pts, dtype=float)
    return {"N": a[:, 0], "Mx": a[:, 1], "My": a[:, 2]}


def test_boundary_point_is_the_exit_of_the_ray_3d():
    """
    On a box the exit point of a ray is known: the first bound reached.

    Demand ``(-2000, 50, 25)`` reaches ``N = -1000`` at half its length,
    long before ``Mx`` (25 of 100) or ``My`` (12.5 of 50), so
    ``R = (-1000, 25, 12.5)`` and ``eta = 2``.  The normalisation is a
    diagonal map fixing the origin; if the raw-coordinate relation
    ``R = T / eta`` were wrong for it, this is where it would show.
    """
    dom = DomainChecker(_box(-1000.0, 300.0, 100.0, 50.0))
    bp = dom.boundary_point_along_ray(-2000.0, 50.0, 25.0)
    assert bp["eta"] == pytest.approx(2.0, rel=1e-9)
    assert bp["N"] == pytest.approx(-1000.0, rel=1e-9)
    assert bp["Mx"] == pytest.approx(25.0, rel=1e-9)
    assert bp["My"] == pytest.approx(12.5, rel=1e-9)
    # ... and it is a boundary point: just inside it is inside, just
    # beyond it is outside.
    R = np.array([bp["N"], bp["Mx"], bp["My"]])
    assert dom.is_inside(*(R * (1.0 - 1e-6)))
    assert not dom.is_inside(*(R * (1.0 + 1e-6)))


def test_boundary_point_of_an_inside_demand_lies_beyond_it():
    """A demand inside the hull has ``eta < 1`` and ``R`` beyond it."""
    dom = DomainChecker(_box(-1000.0, 300.0, 100.0, 50.0))
    bp = dom.boundary_point_along_ray(-500.0, 0.0, 0.0)
    assert bp["eta"] == pytest.approx(0.5, rel=1e-9)
    assert bp["N"] == pytest.approx(-1000.0, rel=1e-9)


def test_boundary_point_2d_hull_passes_my_through_unchanged():
    """
    A 2-D hull knows nothing about ``My``; it is returned as given.

    Rescaling it would invent a boundary in a coordinate the domain
    does not describe.
    """
    n = np.array([-1000.0, -1000.0, 300.0, 300.0])
    m = np.array([-100.0, 100.0, -100.0, 100.0])
    dom = DomainChecker({"N": n, "M": m})
    bp = dom.boundary_point_along_ray(-2000.0, 50.0, 7.0)
    assert bp["eta"] == pytest.approx(2.0, rel=1e-9)
    assert bp["My"] == 7.0


def test_origin_outside_the_hull_is_refused():
    """
    With the origin outside, the nearest crossing is not the exit.

    ``_ray_eta`` returns the nearest positive crossing; from outside
    that is the *entry*.  The method must say so, not return it.
    """
    dom = DomainChecker(_box(100.0, 300.0, 100.0, 50.0))
    with pytest.raises(ValueError, match="origin is not inside"):
        dom.boundary_point_along_ray(200.0, 10.0, 5.0)


def test_demand_at_the_origin_is_refused():
    """The direction of the ray is undefined; no point is invented."""
    dom = DomainChecker(_box(-1000.0, 300.0, 100.0, 50.0))
    with pytest.raises(ValueError, match="coincides with the origin"):
        dom.boundary_point_along_ray(0.0, 0.0, 0.0)


# ----------------------------------------------------------------------
#  A small real section (uniaxial mesh: fast)
# ----------------------------------------------------------------------

_DOC = {
    "code": "ec2",
    "materials": {
        "C25": {"type": "concrete_ec2_gen1", "class": "C25/30",
                "ls": "F", "loadtype": "slow", "TypeConc": "R",
                "NA": "French", "time": 28},
        "B450C": {"type": "steel", "fyk": 450.0, "gamma_s": 1.15,
                  "works_in_compression": True},
    },
    "section": {
        "B": 300, "H": 500, "bulk_material": "C25",
        "n_fibers_y": 20, "n_fibers_x": 1,
        "rebars": [
            {"x": 30, "y": 30, "As": 201.06, "material": "B450C",
             "n_bars": 1, "diameter": 8},
            {"x": 270, "y": 30, "As": 201.06, "material": "B450C",
             "n_bars": 1, "diameter": 8},
            {"x": 30, "y": 470, "As": 201.06, "material": "B450C",
             "n_bars": 1, "diameter": 8},
            {"x": 270, "y": 470, "As": 201.06, "material": "B450C",
             "n_bars": 1, "diameter": 8},
        ],
    },
    "output": {
        "generate_moment_curvature": False,
        "generate_polar_ductility": False,
        "generate_3d_moment_curvature": False,
    },
}


def _demands(n_bad):
    """One demand well inside, then ``n_bad`` far outside the domain."""
    out = [{"name": "OK", "N_kN": -500, "Mx_kNm": 20, "My_kNm": 0}]
    out += [{"name": f"BAD{i}", "N_kN": 50,
             "Mx_kNm": 400 + 20 * i, "My_kNm": 0} for i in range(n_bad)]
    return out


def _write_doc(tmp_path, n_bad):
    doc = dict(_DOC)
    doc["demands"] = _demands(n_bad)
    p = tmp_path / "in.yaml"
    p.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    return str(p)


@pytest.fixture(scope="module")
def rig(tmp_path_factory):
    """Section, solver, hull and parsed demands for ``OK`` + 5 ``BAD``."""
    d = tmp_path_factory.mktemp("rig")
    data = load_yaml(_write_doc(d, 5))
    section = data["section"]
    solver = FiberSolver(section)
    gen = NMDiagram(solver)
    nm = gen.generate(n_points=30)
    eng = VerificationEngine(nm, gen, data.get("output_options", {}),
                             n_points=30)
    results = eng.check_demands(data["demands"])
    return section, solver, eng.domain, data["demands"], results


def _files(outdir, prefix):
    return sorted(f for f in os.listdir(outdir) if f.startswith(prefix))


def test_premise_the_bad_demands_have_no_equilibrium_state(rig):
    """
    The premise the whole patch stands on, measured and not assumed.

    ``BAD*`` are outside the hull *and* the solver does not converge on
    them; ``OK`` is inside and converges.  If this ever fails, the
    outcome tests below prove nothing about the defect.
    """
    _, solver, dom, demands, _ = rig
    for d in demands:
        sol = solver.solve_equilibrium(d["N"], d["Mx"], d["My"])
        if d["name"] == "OK":
            assert sol["converged"] and dom.is_inside(d["N"], d["Mx"],
                                                      d["My"])
        else:
            assert (not sol["converged"]
                    and not dom.is_inside(d["N"], d["Mx"], d["My"]))


def test_every_selected_demand_gets_an_outcome_and_an_image(rig, tmp_path):
    """
    The original failing configuration: ``top_k = 5`` is all ``BAD``.

    Selected are the five worst, all without a state at the demand.
    Before: zero ``state_*.png``.  Now: five ``state_*_boundary.png``,
    five records of kind ``"boundary"`` carrying ``eta_ray > 1``.
    """
    section, solver, dom, demands, results = rig
    names = set(select_demands_for_fiber_details(results, top_k=5))
    assert names == {f"BAD{i}" for i in range(5)}, (
        "the fixture no longer reproduces the selection that starved "
        "the plots")
    recs = export_demand_state_plots(section, solver, dom, demands,
                                     names, str(tmp_path))
    assert [r["kind"] for r in recs] == ["boundary"] * 5
    assert all(r["eta_ray"] > 1.0 for r in recs)
    assert len(_files(tmp_path, "state_")) == 5
    assert all(f.endswith("_boundary.png")
               for f in _files(tmp_path, "state_"))
    # the message says why the demand itself was not plotted
    assert all("no equilibrium state at the demand" in r["message"]
               for r in recs)


def test_a_demand_with_a_state_keeps_the_old_names(rig, tmp_path):
    """The verified demand is written exactly as before: no suffix."""
    section, solver, dom, demands, _ = rig
    recs = export_demand_state_plots(section, solver, dom, demands,
                                     {"OK"}, str(tmp_path))
    assert [(r["name"], r["kind"]) for r in recs] == [("OK", "demand")]
    assert _files(tmp_path, "state_") == ["state_OK.png"]
    assert _files(tmp_path, "section_") == ["section_OK.png"]
    assert _files(tmp_path, "fibers_") == ["fibers_OK.csv"]


def test_mixed_selection_yields_both_kinds(rig, tmp_path):
    """One demand at, one beyond: distinct files, distinct kinds."""
    section, solver, dom, demands, _ = rig
    recs = export_demand_state_plots(section, solver, dom, demands,
                                     {"OK", "BAD0"}, str(tmp_path))
    assert {r["name"]: r["kind"] for r in recs} == {
        "OK": "demand", "BAD0": "boundary"}
    assert _files(tmp_path, "state_") == ["state_BAD0_boundary.png",
                                          "state_OK.png"]


class _StubSolver:
    """Solver that never converges, optionally with the pure-axial fields."""

    def __init__(self, **extra):
        self._extra = extra

    def solve_equilibrium(self, N, Mx, My):
        sol = {"converged": False, "iterations": 50}
        sol.update(self._extra)
        return sol


def test_no_state_anywhere_is_reported_not_swallowed(rig, tmp_path):
    """
    Nothing at the demand and nothing at the boundary: kind ``"none"``.

    No file, a message that names both failures, and the solver's own
    ``reason`` / ``refusal`` passed through verbatim.
    """
    section, _, dom, demands, _ = rig
    stub = _StubSolver(reason="axial_state_not_attainable",
                       refusal="N is outside the reach [a, b]")
    recs = export_demand_state_plots(section, stub, dom, demands,
                                     {"BAD0"}, str(tmp_path))
    r, = recs
    assert r["kind"] == "none" and r["files"] == []
    assert r["eta_ray"] is not None and r["eta_ray"] > 1.0
    assert "either" in r["message"]
    assert "axial_state_not_attainable: N is outside the reach" \
        in r["message"]
    assert os.listdir(tmp_path) == []


def test_undefined_boundary_point_is_reported_not_swallowed(rig, tmp_path):
    """The hull refuses (origin outside): the refusal is the message."""
    section, _, _, demands, _ = rig

    class _Refusing:
        def is_inside(self, *a):
            return False

        def boundary_point_along_ray(self, *a):
            raise ValueError("origin is not inside the resistance hull")

    recs = export_demand_state_plots(section, _StubSolver(), _Refusing(),
                                     demands, {"BAD0"}, str(tmp_path))
    r, = recs
    assert r["kind"] == "none" and r["eta_ray"] is None
    assert "boundary point undefined" in r["message"]
    assert "origin is not inside" in r["message"]
    assert os.listdir(tmp_path) == []


# ----------------------------------------------------------------------
#  End to end
# ----------------------------------------------------------------------

def test_cli_writes_a_state_image_for_the_configuration_that_wrote_none(
        tmp_path):
    """
    ``gensec run`` on one verified demand and five outside the domain.

    The configuration measured to produce zero ``state_*.png``.  With
    the default ``fiber_details_top_k = 5`` the selection is the five
    outside demands; each now yields a ``_boundary`` state.
    """
    from gensec import cli
    out = tmp_path / "out"
    cli.main(["run", _write_doc(tmp_path, 5),
              "--output-dir", str(out), "--n-points", "30"])
    states = _files(out, "state_")
    assert len(states) == 5, states
    assert all(s.endswith("_boundary.png") for s in states)
