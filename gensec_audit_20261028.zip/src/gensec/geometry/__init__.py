# ---------------------------------------------------------------------------
# GenSec — Copyright (c) 2026 Andrea Albero
#
# This file is part of GenSec.
#
# GenSec is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the
# Free Software Foundation, either version 3 of the License, or (at your
# option) any later version.
#
# GenSec is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public
# License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with GenSec.  If not, see <https://www.gnu.org/licenses/>.
# ---------------------------------------------------------------------------
"""
Geometry subpackage.

Provides section definition classes: point fibers (:class:`RebarLayer`),
prestressing tendons (:class:`Tendon`) and rectangular section assemblies
(:class:`RectSection`).
"""

from .fiber import RebarLayer, Tendon
from .section import RectSection
from .geometry import GenericSection


from .properties import (
    SectionProperties,
    HomogenizedRebar,
    compute_section_properties,
    compute_inertia_ellipse,
    compute_kern_polygon,
)

__all__ = ["RebarLayer", "Tendon", "RectSection", "GenericSection",
    "SectionProperties",
    "HomogenizedRebar",
    "compute_section_properties",
    "compute_inertia_ellipse",
    "compute_kern_polygon",
    ]